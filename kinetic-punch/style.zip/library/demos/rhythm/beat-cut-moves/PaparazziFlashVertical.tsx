// paparazzi-flash · 竖版 9:16（1080×1920）。
// 保留：三闪 30/52/70、切入回落 1.03→1（6f）+ 半格沉降、白层 0.95→0（4f）、白闪帧 ±2px 快门震、闪前中景慢推 1.16→1.2。
// 竖版：素材 FakeDashboard → FakeDashboardV（2 列卡片），大数字叠在右上卡片（799, 443）；
// 三个定格裁切：全景 → 右上卡片特写（×1.9）→ 数字特写（×3.0，数字 104→120px，放大后约 1000 宽仍在画内）；
// 裁切中心推到安全区中心（y 835）。沉降 -16→-20px 按画宽等比。
// 以下为横版原注释：
// 高光时刻三连白闪，每闪硬切同一素材的不同裁切（全景→卡片特写→数字特写），每闪切入画面带 1.03→1 回落 + 半格沉降
// 像快门余韵，白闪帧加微位移抖动模拟快门震，第三闪后停在数字特写收束。
import React from 'react';
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from 'remotion';
import { G, TitleBlock } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const PAPARAZZI_FLASH_VERTICAL_DURATION = 130;
const F1 = 30;
const F2 = 52;
const F3 = 70;
const SETTLE = 6;
const DECAY = 4;
const FLASHES = [F1, F2, F3];
const hash = (i: number) => {
  const s = Math.sin(i * 127.3) * 43758.5453;
  return (s - Math.floor(s)) * 2 - 1;
};
const NUM = { x: 799, y: 443 };
const Footage: React.FC = () => (
  <div style={{ position: 'absolute', width: 1080, height: 1920 }}>
    <FakeDashboardV variant="A" />
    <div style={{ position: 'absolute', left: NUM.x, top: NUM.y, transform: 'translate(-50%, -50%)' }}>
      <TitleBlock text="84,213" size={120} />
    </div>
  </div>
);
type View = { scale: number; cx: number; cy: number };
const VIEW_WIDE: View = { scale: 1, cx: 540, cy: 960 };
const VIEW_CARD: View = { scale: 1.9, cx: NUM.x, cy: NUM.y };
const VIEW_DIGIT: View = { scale: 3.0, cx: NUM.x, cy: NUM.y };

export const PaparazziFlashVertical: React.FC = () => {
  const frame = useCurrentFrame();
  let seg = -1;
  for (let i = 0; i < FLASHES.length; i++) if (frame >= FLASHES[i]) seg = i;
  let v: View;
  let scale: number;
  let settleScale = 1;
  let settleY = 0;
  if (seg === -1) {
    v = { scale: 1, cx: 520, cy: 900 };
    scale = interpolate(frame, [0, F1], [1.16, 1.2], { extrapolateRight: 'clamp', easing: Easing.inOut(Easing.quad) });
  } else {
    v = [VIEW_WIDE, VIEW_CARD, VIEW_DIGIT][seg];
    scale = v.scale;
    const t = interpolate(frame, [FLASHES[seg], FLASHES[seg] + SETTLE], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) });
    settleScale = 1 + 0.03 * t;
    settleY = -20 * t;
  }
  let flash = 0;
  for (const f of FLASHES) {
    const o = interpolate(frame, [f, f + DECAY], [0.95, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.quad) });
    if (frame >= f && frame < f + DECAY + 1) flash = Math.max(flash, o);
  }
  const inFlash = FLASHES.some((f) => frame >= f && frame < f + DECAY);
  const jx = inFlash ? 2 * hash(frame * 7 + 1) : 0;
  const jy = inFlash ? 2 * hash(frame * 13 + 5) : 0;
  const ty = v.scale === 1 && seg !== -1 ? 0 : SAFE_CY - v.cy;
  return (
    <AbsoluteFill style={{ background: G.ink, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, transform: `translate(${jx}px, ${jy + settleY}px)` }}>
        <div style={{ position: 'absolute', width: 1080, height: 1920, transform: `translate(${540 - v.cx}px, ${ty}px) scale(${scale * settleScale})`, transformOrigin: `${v.cx}px ${v.cy}px` }}>
          <Footage />
        </div>
      </div>
      {flash > 0 && <AbsoluteFill style={{ background: '#ffffff', opacity: flash }} />}
    </AbsoluteFill>
  );
};
