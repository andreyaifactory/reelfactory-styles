// color-block-step-wipe · 竖版 9:16（1080×1920）。
// 保留：全部阶跃帧（A：8/16/24/32/44 尺寸硬跳，徽章 52/58/63；B：84/96/108 对角推进 + 卡片同步跳位），无缓动。
// 竖版：A 的蓝块从安全区中心生长，横条 → 竖向撑满：宽 [200, 600, 1080, 1080, 1080]、高 [96, 96, 480, 1000, 1920]；
// 徽章 170→220 对准安全区中心。B 的灰阶页面改竖排（标题条 + 行 + 两张上下叠卡），红块仍从右下角斜吃，
// 卡片跳位路径按竖画面重算，最后停在安全区内 (380, 640)。
// 以下为横版原注释：
// 纯色矩形按 steps() 离散阶跃吞屏转场。源：notion-ai（蓝块中央阶跃生长）+（红块右下角斜向吃屏，携带页面卡）。
// 核心语法：无缓动、逐帧硬跳的块状生长，像素游戏手感。
import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { G, Card } from '../../_fixtures/Fixtures';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const COLOR_BLOCK_STEP_WIPE_VERTICAL_DURATION = 150;
const BLUE = '#2383e2';
const RED = '#e8503a';
const stepVal = (frame: number, steps: Array<[number, number]>): number => {
  let v = steps[0][1];
  for (const [f, val] of steps) if (frame >= f) v = val;
  return v;
};
const AiBadge: React.FC<{ scale: number; opacity: number }> = ({ scale, opacity }) => (
  <div style={{ position: 'absolute', left: 540 - 110, top: SAFE_CY - 110, width: 220, height: 220, borderRadius: '50%', background: '#fdf6ec', opacity, transform: `scale(${scale})`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 6px 24px rgba(0,0,0,0.18)' }}>
    <svg width={142} height={142} viewBox="0 0 110 110">
      <circle cx={36} cy={44} r={8} fill={G.ink} />
      <circle cx={74} cy={44} r={8} fill={G.ink} />
      <path d="M32 70 Q55 88 78 70" stroke={G.ink} strokeWidth={7} fill="none" strokeLinecap="round" />
      <path d="M24 28 Q34 20 44 26" stroke={G.ink} strokeWidth={6} fill="none" strokeLinecap="round" />
      <path d="M66 26 Q76 20 86 28" stroke={G.ink} strokeWidth={6} fill="none" strokeLinecap="round" />
    </svg>
  </div>
);
const GrayPage: React.FC = () => (
  <AbsoluteFill style={{ background: G.panel, padding: '260px 80px', boxSizing: 'border-box' }}>
    <div style={{ height: 48, width: 620, background: G.bar, borderRadius: 14, marginBottom: 44 }} />
    {[92, 78, 86, 60].map((w, i) => (
      <div key={i} style={{ height: 22, width: `${w}%`, background: G.line, borderRadius: 11, marginBottom: 28 }} />
    ))}
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32, marginTop: 30 }}>
      <Card w={920} h={300} seed={2} />
      <Card w={920} h={300} seed={5} />
    </div>
  </AbsoluteFill>
);

export const ColorBlockStepWipeVertical: React.FC = () => {
  const frame = useCurrentFrame();
  if (frame < 78) {
    const w = stepVal(frame, [[0, 0], [8, 200], [16, 600], [24, 1080], [32, 1080], [44, 1080]]);
    const h = stepVal(frame, [[0, 0], [8, 96], [16, 96], [24, 480], [32, 1000], [44, 1920]]);
    const cy = h >= 1920 ? 960 : SAFE_CY;
    const badgeScale = stepVal(frame, [[0, 0], [52, 0.55], [58, 1.12], [63, 1]]);
    return (
      <AbsoluteFill style={{ background: G.bg }}>
        <div style={{ position: 'absolute', left: 540 - w / 2, top: cy - h / 2, width: w, height: h, background: BLUE }} />
        <AiBadge scale={badgeScale} opacity={frame >= 52 ? 1 : 0} />
      </AbsoluteFill>
    );
  }
  const p = stepVal(frame, [[78, 0], [84, 42], [96, 106], [108, 200]]);
  const cardPos = stepVal(frame, [[78, 0], [84, 1], [96, 2], [108, 3]]);
  const cardXY: Array<[number, number]> = [
    [1300, 2200],
    [880, 1500],
    [620, 1020],
    [380, 640],
  ];
  const [cx, cy] = cardXY[cardPos];
  const clip = p <= 0 ? 'polygon(100% 100%, 100% 100%, 100% 100%)' : `polygon(${100 - p}% 100%, 100% ${100 - p}%, 100% 100%)`;
  return (
    <AbsoluteFill>
      <GrayPage />
      <AbsoluteFill style={{ background: RED, clipPath: clip }} />
      {p > 0 && (
        <div style={{ position: 'absolute', left: cx - 250, top: cy - 175, transform: 'rotate(-4deg)', boxShadow: '0 18px 50px rgba(0,0,0,0.3)', borderRadius: 14 }}>
          <Card w={500} h={350} seed={7} />
        </div>
      )}
    </AbsoluteFill>
  );
};
