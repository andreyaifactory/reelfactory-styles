import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  AbsoluteFill, Img, OffthreadVideo, Sequence, continueRender, delayRender, interpolate, interpolateColors, spring, staticFile,
  useCurrentFrame, useVideoConfig, Easing,
} from 'remotion';

// «Слои»: говорящий эксперт, вокруг него слои. Кадр собирается так:
// видео → слой «за человеком» → вырезанный человек (matte.webm) → слой «перед ним».
// Камера (зум) двигает видео и вырезку вместе, графика стоит в кадре.

// ── часы ────────────────────────────────────────────────
/**
 * Всё в ките считается в кадрах ролика. В фабрике каждый блок отсчитывает
 * кадры заново, поэтому сцена кладёт кадр ролика в `LayerClock`
 * (`<LayerClock frame={useReelFrame()}>`) — и заголовки, видео, запись в
 * телефоне встают на свои места через стыки блоков. Без часов — кадр композиции.
 */
const Clock = createContext<number | null>(null);
export const LayerClock: React.FC<{ frame: number; children: React.ReactNode }> = ({ frame, children }) => (
  <Clock.Provider value={frame}>{children}</Clock.Provider>
);
export const useFrame = () => {
  const local = useCurrentFrame();
  return useContext(Clock) ?? local;
};
/** Сколько кадров ролика прошло до начала текущего блока. */
const useOffset = () => useFrame() - useCurrentFrame();

// ── токены ──────────────────────────────────────────────
export const T = {
  accent: '#4F8DF7',
  accentLight: '#A9C8FF',
  accentDeep: '#2457C5',
  accentShade: '#163a8a',
  text: '#FFFFFF',
  shadow: 'rgba(8,12,24,0.38)',
  head: 'Oswald',
  script: 'Bad Script',
  body: 'Montserrat',
} as const;

const FACES: Array<[string, string, string]> = [
  ['Oswald', 'oswald.ttf', '200 700'],
  ['Bad Script', 'bad-script.ttf', '400'],
  ['Montserrat', 'montserrat.ttf', '100 900'],
];

/** Шрифты пака. В фабрике они лежат в `public/styles/layered-expert/fonts`. */
export const LayerFonts: React.FC<{ base?: string; children: React.ReactNode }> = ({ base = 'styles/layered-expert/fonts', children }) => {
  const [handle] = useState(() => delayRender('Шрифты стиля «Слои»'));
  useEffect(() => {
    Promise.all(FACES.map(([family, file, weight]) =>
      new FontFace(family, `url(${staticFile(`${base}/${file}`)})`, { weight }).load().then((f) => document.fonts.add(f))))
      .then(() => continueRender(handle))
      .catch(() => continueRender(handle));
  }, [base, handle]);
  return <>{children}</>;
};

// ── время ───────────────────────────────────────────────
const apple = Easing.bezier(0.25, 0.1, 0.25, 1);
const clamp = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
export const ramp = (f: number, a: number, b: number) => interpolate(f, [a, b], [0, 1], { ...clamp, easing: apple });

/** Вход с баунсом: 0 → 1 с небольшим перелётом. */
export const pop = (f: number, at: number, fps: number, damping = 11) =>
  spring({ frame: f - at, fps, config: { damping, stiffness: 170, mass: 0.8 } });

/** Окно жизни элемента: появление в `at`, уход к `out` (8 кадров). */
export const life = (f: number, at: number, out: number) =>
  f < at || f >= out ? 0 : 1 - ramp(f, out - 8, out);

// ── камера ──────────────────────────────────────────────
/**
 * План камеры: зум медленно идёт от первого значения ко второму весь план.
 * Смена крупности — только склейкой между планами, и соседние планы заметно
 * отличаются зумом: одинаковый зум с другой точкой фокуса читается как дёрганье.
 * План начинается ровно на склейке дорожки (work/edl.json), а не рядом с ней.
 */
export type Shot = { from: number; zoom: [number, number]; focus?: [number, number] };

/**
 * Склейки чистой дорожки в кадрах ролика — по ним ставятся планы.
 * `import edl from '../work/edl.json'` → `cutsOf(edl, 30)`.
 */
export function cutsOf(edl: { keep: { from: number; to: number }[] }, fps: number): number[] {
  const cuts: number[] = [];
  let passed = 0;
  for (const k of edl.keep.slice(0, -1)) {
    passed += k.to - k.from;
    cuts.push(Math.ceil(passed * fps));
  }
  return cuts;
}

/** Зум по планам: склейка — прыжок между планами, внутри плана плавный наезд. */
export function cameraAt(f: number, shots: Shot[], end: number, bumps: number[] = []) {
  let shot = shots[0];
  let to = end;
  for (let i = 0; i < shots.length; i++) if (f >= shots[i].from) { shot = shots[i]; to = shots[i + 1]?.from ?? end; }
  const k = interpolate(f, [shot.from, to], [0, 1], clamp);
  let zoom = shot.zoom[0] + (shot.zoom[1] - shot.zoom[0]) * k;
  // Толчок на появлении вставки: короткий, почти незаметный.
  for (const b of bumps) {
    const d = f - b;
    if (d >= 0 && d < 14) zoom *= 1 + 0.018 * Math.sin((d / 14) * Math.PI);
  }
  return { zoom, focus: shot.focus ?? [540, 800] };
}

// ── сцена со слоями ─────────────────────────────────────
/**
 * Видео, слой «за человеком», вырезанный человек, слой «перед ним».
 * В фабрике голос несёт видео ядра, поэтому здесь видео без звука (`voice` —
 * только для ролика вне фабрики). Видео и вырезка идут с места текущего блока.
 */
export const Stage: React.FC<{
  video: string; matte?: string; zoom: number; focus: [number, number];
  behind?: React.ReactNode; front?: React.ReactNode; voice?: boolean;
}> = ({ video, matte, zoom, focus, behind, front, voice = false }) => {
  const from = useOffset();
  const cam: React.CSSProperties = {
    transform: `scale(${zoom})`, transformOrigin: `${focus[0]}px ${focus[1]}px`,
  };
  return (
    <AbsoluteFill style={{ backgroundColor: '#0d0f14' }}>
      <AbsoluteFill style={cam}>
        <OffthreadVideo src={staticFile(video)} startFrom={from} muted={!voice} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      </AbsoluteFill>
      <AbsoluteFill>{behind}</AbsoluteFill>
      {matte ? (
        <AbsoluteFill style={cam}>
          <OffthreadVideo src={staticFile(matte)} startFrom={from} transparent muted style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        </AbsoluteFill>
      ) : null}
      <AbsoluteFill>{front}</AbsoluteFill>
    </AbsoluteFill>
  );
};

// ── заголовок ───────────────────────────────────────────
/** Узкий жирный капслок. Строки выезжают снизу из-под маски, по очереди. */
export const Headline: React.FC<{
  lines: string[]; at: number; out: number; x: number; y: number; size?: number; align?: 'left' | 'center' | 'right';
}> = ({ lines, at, out, x, y, size = 118, align = 'center' }) => {
  const f = useFrame();
  const alive = life(f, at, out);
  if (!alive) return null;
  const anchor = align === 'center' ? '-50%' : align === 'right' ? '-100%' : '0';
  return (
    <div style={{
      position: 'absolute', left: x, top: y, transform: `translateX(${anchor}) translateY(${(1 - alive) * -18}px)`,
      opacity: alive, textAlign: align, fontFamily: T.head, fontWeight: 650, fontSize: size, lineHeight: 0.98,
      color: T.text, textTransform: 'uppercase', letterSpacing: '0.005em', whiteSpace: 'nowrap',
      filter: `drop-shadow(0 8px 24px ${T.shadow})`,
    }}>
      {lines.map((line, i) => {
        const k = ramp(f, at + i * 4, at + i * 4 + 12);
        return (
          <div key={i} style={{ overflow: 'hidden', paddingBottom: 4 }}>
            <div style={{ transform: `translateY(${(1 - k) * 105}%)` }}>{line}</div>
          </div>
        );
      })}
    </div>
  );
};

// ── рукопись ────────────────────────────────────────────
/** Тонкий рукописный текст, пишется слева направо как пером; при нём — росчерк-стрелка. */
export const Script: React.FC<{
  text: string; at: number; out: number; x: number; y: number; size?: number; rotate?: number;
  arrow?: { d: string; w: number; h: number; x: number; y: number; stroke?: number }; color?: string;
}> = ({ text, at, out, x, y, size = 66, rotate = -5, arrow, color = T.text }) => {
  const f = useFrame();
  const alive = life(f, at, out);
  if (!alive) return null;
  const dur = Math.max(10, Math.round(text.length * 1.1));
  const k = interpolate(f, [at, at + dur], [0, 1], clamp);
  const a = arrow ? ramp(f, at + dur - 2, at + dur + 10) : 0;
  return (
    <div style={{ position: 'absolute', left: x, top: y, opacity: alive, transform: `rotate(${rotate}deg)`, filter: `drop-shadow(0 3px 10px ${T.shadow})` }}>
      <div style={{
        fontFamily: T.script, fontSize: size, color, whiteSpace: 'pre', lineHeight: 1.05,
        clipPath: `inset(-20% ${(1 - k) * 100}% -20% -5%)`,
      }}>{text}</div>
      {arrow ? (
        <svg width={arrow.w} height={arrow.h} style={{ position: 'absolute', left: arrow.x, top: arrow.y, overflow: 'visible' }}>
          <path d={arrow.d} fill="none" stroke={color} strokeWidth={arrow.stroke ?? 4} strokeLinecap="round" strokeLinejoin="round"
            pathLength={1} strokeDasharray={1} strokeDashoffset={1 - a} />
        </svg>
      ) : null}
    </div>
  );
};

// ── объёмная цифра ──────────────────────────────────────
/**
 * Цифра с толщиной без 3D-движка: стопка сдвинутых слоёв даёт бок, градиент —
 * свет с двух сторон, полоса блика — материал. Медленное покачивание меняет
 * направление бока — цифра будто поворачивается.
 */
export const BigNumber: React.FC<{ n: string; at: number; out: number; x: number; y: number; size?: number }> = ({
  n, at, out, x, y, size = 460,
}) => {
  const f = useFrame();
  const { fps } = useVideoConfig();
  const alive = life(f, at, out);
  if (!alive) return null;
  const s = pop(f, at, fps, 9);
  const t = (f - at) / fps;
  const angle = (125 + 18 * Math.sin(t * 1.3)) * (Math.PI / 180);
  const depth = 34;
  const step = size / 260;
  const glyph: React.CSSProperties = {
    position: 'absolute', left: 0, top: 0, fontFamily: T.head, fontWeight: 700, fontSize: size, lineHeight: 1,
  };
  return (
    <div style={{
      position: 'absolute', left: x, top: y, opacity: alive,
      transform: `scale(${0.35 + 0.65 * s}) rotate(${(1 - s) * -18 + 3 * Math.sin(t)}deg)`, transformOrigin: '50% 60%',
      filter: `drop-shadow(0 34px 38px rgba(6,12,30,0.45))`,
    }}>
      <div style={{ position: 'relative', width: size * 0.62, height: size }}>
        {Array.from({ length: depth }, (_, i) => depth - i).map((i) => (
          <div key={i} style={{
            ...glyph, color: interpolateColor(i / depth),
            transform: `translate(${Math.cos(angle) * i * step}px, ${Math.sin(angle) * i * step}px)`,
          }}>{n}</div>
        ))}
        <div style={{
          ...glyph, backgroundImage: `linear-gradient(160deg, ${T.accentLight} 0%, ${T.accent} 42%, ${T.accentDeep} 100%)`,
          WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent',
          WebkitTextStroke: `${size / 120}px rgba(214,230,255,0.75)`,
        }}>{n}</div>
        <div style={{
          ...glyph, color: 'transparent', WebkitBackgroundClip: 'text', backgroundClip: 'text',
          backgroundImage: `linear-gradient(115deg, transparent 30%, rgba(255,255,255,0.55) ${38 + 8 * Math.sin(t * 0.8)}%, transparent 52%)`,
        }}>{n}</div>
      </div>
    </div>
  );
};

/** Бок цифры: от тени у основания к цвету акцента у лица. */
function interpolateColor(k: number) {
  return interpolateColors(k, [0, 0.15, 1], [T.accent, T.accentDeep, T.accentShade]);
}

// ── вставка ─────────────────────────────────────────────
/** Карточка-фото: вылетает с баунсом, чуть наклонена, мягкая тень. */
export const Card: React.FC<{
  at: number; out: number; x: number; y: number; w: number; h: number; tilt?: number;
  src?: string; children?: React.ReactNode; radius?: number; fit?: 'cover' | 'contain'; bg?: string;
}> = ({ at, out, x, y, w, h, tilt = -5, src, children, radius = 34, fit = 'cover', bg = '#fff' }) => {
  const f = useFrame();
  const { fps } = useVideoConfig();
  const alive = life(f, at, out);
  if (!alive) return null;
  const s = pop(f, at, fps);
  return (
    <div style={{
      position: 'absolute', left: x, top: y, width: w, height: h, opacity: Math.min(1, s * 2) * alive,
      transform: `scale(${(0.55 + 0.45 * s) * (0.92 + 0.08 * alive)}) rotate(${tilt + (1 - s) * -10}deg)`,
      borderRadius: radius, overflow: 'hidden', background: bg,
      boxShadow: `0 26px 50px rgba(6,10,22,0.35), 0 0 0 1px rgba(255,255,255,0.6) inset`,
    }}>
      {src ? <Img src={staticFile(src)} style={{ width: '100%', height: '100%', objectFit: fit }} /> : children}
    </div>
  );
};

// ── телефон ─────────────────────────────────────────────
/**
 * iPhone с записью экрана: въезжает снизу с баунсом, стоит с лёгким наклоном.
 * На экране — запись (`video`) или своё содержимое (`children`), например листаемая страница.
 */
export const Phone: React.FC<{
  at: number; out: number; x: number; y: number; w?: number; tilt?: number; video?: string; children?: React.ReactNode;
}> = ({ at, out, x, y, w = 430, tilt = 5, video, children }) => {
  const f = useFrame();
  const offset = useOffset();
  const { fps } = useVideoConfig();
  const alive = life(f, at, out);
  if (!alive) return null;
  const s = pop(f, at, fps, 13);
  const h = w * 2.06;
  const bezel = w * 0.035;
  return (
    <div style={{
      // Уходит вниз, как въехал: растворение показало бы лицо сквозь экран.
      position: 'absolute', left: x, top: y, width: w, height: h,
      transform: `translateY(${(1 - s) * 900 + (1 - alive) * 1400}px) rotate(${tilt + (1 - s) * 10 + Math.sin((f - at) / 40) * 0.8}deg)`,
      borderRadius: w * 0.16, padding: bezel, background: '#0b0b0d',
      boxShadow: `0 0 0 ${w * 0.009}px #9a9ea6, 0 0 0 ${w * 0.014}px #3c3f45, 0 40px 80px rgba(4,8,20,0.5)`,
    }}>
      <div style={{ position: 'relative', width: '100%', height: '100%', borderRadius: w * 0.13, overflow: 'hidden', background: '#000' }}>
        {/* Запись идёт с момента появления телефона, а не с начала ролика. */}
        {video ? (
          <Sequence from={at - offset}>
            <OffthreadVideo src={staticFile(video)} muted style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </Sequence>
        ) : children}
        <div style={{
          position: 'absolute', top: w * 0.03, left: '50%', width: w * 0.28, height: w * 0.08, transform: 'translateX(-50%)',
          borderRadius: 999, background: '#000',
        }} />
      </div>
    </div>
  );
};

// ── субтитры ────────────────────────────────────────────
export type Word = { text: string; start: number; end: number };

/** Вид субтитров пака: тонкий светлый гротеск, мелко, без плашки, мягкая тень. */
export const SUBS_LOOK: React.CSSProperties = {
  fontFamily: T.body, fontWeight: 500, color: T.text, letterSpacing: '0.01em', textShadow: `0 2px 12px ${T.shadow}`,
};

/**
 * Субтитры для ролика вне фабрики (шоурил): по 1–3 слова, низко.
 * В фабрике их рисует ядро видом `factory/Caption.tsx`.
 */
const SUBS_AREA = () => ({ top: 1480, left: 90, right: 90 });

export const Subs: React.FC<{
  words: Word[]; area?: (f: number) => { top: number; left: number; right: number }; accent?: string[];
}> = ({ words, area = SUBS_AREA, accent = [] }) => {
  const f = useFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  const chunks: Word[][] = [];
  for (const w of words) {
    const last = chunks[chunks.length - 1];
    const prev = last?.[last.length - 1];
    if (!last || last.length >= 3 || /[.,?!:]$/.test(prev!.text) || w.start - prev!.end > 0.35) chunks.push([w]);
    else last.push(w);
  }
  const chunk = chunks.find((c, i) => t >= c[0].start - 0.05 && t < (chunks[i + 1]?.[0].start ?? c[c.length - 1].end + 0.6) - 0.05);
  if (!chunk) return null;
  return (
    <div style={{
      position: 'absolute', ...area(f), textAlign: 'center', fontSize: 46, ...SUBS_LOOK,
    }}>
      {chunk.map((w, i) => (
        <span key={i} style={{ color: accent.includes(w.text.toLowerCase().replace(/[.,?!]/g, '')) ? T.accentLight : T.text }}>
          {w.text.replace(/[.,]$/, '')}{i < chunk.length - 1 ? ' ' : ''}
        </span>
      ))}
    </div>
  );
};
