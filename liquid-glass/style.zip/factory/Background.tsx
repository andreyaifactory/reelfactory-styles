import React from 'react';
import { AbsoluteFill } from 'remotion';
import { C } from '../kit/kit';

/** Подложка кадра — глубокая ночь: тёплая глубина к центру и виньетка. Свет течёт поверх (`Ambient`). */
export const Background: React.FC = () => (
  <AbsoluteFill style={{ background: `radial-gradient(1400px 1600px at 50% 40%, ${C.bg2}, ${C.bg} 70%)` }}>
    <AbsoluteFill style={{ boxShadow: 'inset 0 0 260px rgba(0,0,0,0.65)' }} />
  </AbsoluteFill>
);
