// popup-book-rise · 竖版 9:16（1080×1920）：立起 spring、错峰 7f、场景 75°→68° 回正的参数同横版（160f）。
// 竖版：书页换成竖版假 App 壳（顶栏 160 + 底部 tab 150），纸片卡 2 列 × 3 行，远排先立；
// 场景整体缩到 0.78 并上移 90，让立起的远排卡不出画、卡群落在安全区内。
// 以下为横版原注释：
// popup-book-rise —— 立体书立起
// FakeDashboard(A) 打平躺下（场景 rotateX 75° 透视俯视），6 张卡片是贴在页上的
// 纸片，沿各自底边从平躺错峰立起（rotateX 90°→-5° 过冲→0° 回弹，即立到 95° 再回 90°），
// 根部投影随立起角度收窄变淡。全部立起后整个场景轻微回正（75°→68°）收尾。
// 卡片用独立网格复刻 dashboard A 区布局（Fixtures 内嵌卡无法单独驱动）。
// 收尾 f108 后真静止 ≥52f。帧确定性：全由 frame 派生。
import React from 'react';
import { useCurrentFrame, interpolate, spring, Easing } from 'remotion';
import { G, Card } from '../../_fixtures/Fixtures';
import { FAKE_V, VW, VH } from '../../_fixtures/Vertical';

export const POPUP_BOOK_RISE_VERTICAL_DURATION = 160;

const FPS = 30;
const HOLD = 14; // 开头静置
const STAGGER = 7;
const RISE_DUR = 34; // spring 视觉收敛帧数
const LAST_START = HOLD + 5 * STAGGER; // 49
const SETTLE = LAST_START + RISE_DUR; // 83：全部立起
const REST = SETTLE + 25; // 108：场景回正完成

// 竖版假 App A 区几何：顶栏 160 + padding 36，2 列 × 3 行，gap 28
const AREA_X = FAKE_V.pad;
const AREA_Y = FAKE_V.top + FAKE_V.pad;
const AREA_W = VW - FAKE_V.pad * 2;
const AREA_H = VH - FAKE_V.top - FAKE_V.tab - FAKE_V.pad * 2;
const GAP = 28;
const CELL_W = (AREA_W - GAP) / 2;
const CELL_H = (AREA_H - 2 * GAP) / 3;

const PageCard: React.FC<{ i: number; frame: number }> = ({ i, frame }) => {
  const col = i % 2;
  const row = Math.floor(i / 2);
  // 远排（row 0）先立，近排后立；同排从左到右
  const order = row * 2 + col;
  const start = HOLD + order * STAGGER;

  const s = spring({
    frame: frame - start,
    fps: FPS,
    config: { damping: 11, stiffness: 130, mass: 0.9 },
    durationInFrames: RISE_DUR,
    durationRestThreshold: 0.0001,
  });
  // 平躺（贴页面 = local 0°）→ 立起（垂直页面 = local -90°，顶边朝观众翻起），
  // spring 过冲自然冲过 -90° 到约 -95°（纸的韧性）再回弹。
  const rx = interpolate(s, [0, 1], [0, -90]);

  // 根部投影：躺平时长影（卡片盖在页面上），立起后收成窄条
  const lie = 1 - Math.min(Math.abs(rx) / 90, 1); // 1 = 躺平, 0 = 立直
  const shH = 14 + 90 * Math.max(lie, 0);
  const shAlpha = 0.1 + 0.16 * Math.max(lie, 0);

  return (
    <div
      style={{
        position: 'absolute',
        left: AREA_X + col * (CELL_W + GAP),
        top: AREA_Y + row * (CELL_H + GAP),
        width: CELL_W,
        height: CELL_H,
        transformStyle: 'preserve-3d',
      }}
    >
      {/* 根部投影贴在页面上，不随卡片立起 */}
      <div
        style={{
          position: 'absolute',
          left: 6,
          right: 6,
          bottom: -4,
          height: shH,
          background: `rgba(0,0,0,${shAlpha})`,
          borderRadius: 12,
          filter: 'blur(10px)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          inset: 0,
          transform: `rotateX(${rx}deg)`,
          transformOrigin: '50% 100%',
          backfaceVisibility: 'hidden',
        }}
      >
        <Card w={0} h={0} seed={i + 1} style={{ width: '100%', height: '100%' }} />
      </div>
    </div>
  );
};

export const PopupBookRiseVertical: React.FC = () => {
  const frame = useCurrentFrame();

  // 场景（书页）俯视角：全程 75°，全部立起后轻微回正到 68°
  const sceneRx = interpolate(frame, [SETTLE, REST], [75, 68], {
    easing: Easing.inOut(Easing.cubic),
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div style={{ width: VW, height: VH, background: '#dddddb', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, perspective: 2600, perspectiveOrigin: '50% 20%' }}>
        <div
          style={{
            position: 'absolute',
            inset: 0,
            transform: `translateY(-90px) scale(0.78) rotateX(${sceneRx}deg)`,
            transformOrigin: '50% 55%',
            transformStyle: 'preserve-3d',
          }}
        >
          {/* 书页底板：竖版 App 的壳（顶栏 + 底部 tab + 空白页面） */}
          <div style={{ position: 'absolute', inset: 0, background: G.bg, boxShadow: '0 40px 80px rgba(0,0,0,0.25)' }}>
            <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: FAKE_V.top, background: G.panel, borderBottom: `2px solid ${G.line}`, display: 'flex', alignItems: 'flex-end', padding: '0 40px 30px', gap: 22, boxSizing: 'border-box' }}>
              <div style={{ width: 52, height: 52, borderRadius: 14, background: G.side }} />
              <div style={{ height: 22, width: 260, background: G.bar, borderRadius: 11, marginBottom: 15 }} />
              <div style={{ marginLeft: 'auto', width: 52, height: 52, borderRadius: 26, background: G.mid }} />
            </div>
            <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: FAKE_V.tab, background: G.panel, borderTop: `2px solid ${G.line}`, display: 'flex', justifyContent: 'space-around', alignItems: 'center' }}>
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} style={{ width: 44, height: 44, borderRadius: 12, background: i === 0 ? G.ink : G.bar }} />
              ))}
            </div>
          </div>
          {/* 6 张纸片卡沿底边立起 */}
          {Array.from({ length: 6 }).map((_, i) => (
            <PageCard key={i} i={i} frame={frame} />
          ))}
        </div>
      </div>
    </div>
  );
};
