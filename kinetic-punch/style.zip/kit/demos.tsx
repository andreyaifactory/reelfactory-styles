import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import {
  Arrow,
  Bars,
  Brackets,
  Burst,
  C,
  Captions,
  Cut,
  Echo,
  FIELDS,
  Flash,
  Footage,
  FreezeDuo,
  Graphic,
  HeadCam,
  NumberSlam,
  Plus,
  PunchCam,
  PunchThrough,
  Shutter,
  Slam,
  Slice,
  Smash,
  SpeakerStub,
  SpeedLines,
  SplitTop,
  Stack,
  Stage,
  Starburst,
  Stretch,
  Tag,
  Tape,
  WordHits,
  Zigzag,
  type CapWord,
} from './kit';
import { GZY } from './timeline';

// «Удар»: изолированные демо своих компонентов. Каждое — один приём, 1080×1920, сетка 86.6 BPM.
// «Видео» — вырезки хромовых объектов без текста (public/kinetic/footage); на их месте — любой ролик.
// Демо режима говорящей головы используют плоскую заглушку SpeakerStub — на её месте реальный человек.

const B = (k: number) => Math.round(8 + k * GZY.T);
const beats = (n: number, from = 0, step = 1) => Array.from({ length: n }, (_, i) => B(from + i * step));

const DPunchCam: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <PunchCam f={f} hits={beats(6)}>
        <Footage name="orbA" duo="lime" />
        <Slam f={f} at={B(0)} text="ДОЛЯ" cy={1180} maxSize={300} color={C.white} />
      </PunchCam>
    </Stage>
  );
};

const DWordHits: React.FC = () => {
  const f = useCurrentFrame();
  const W: { text: string; field: keyof typeof FIELDS; from?: 'zoom' | 'left' | 'right' | 'up' | 'down'; accent?: boolean; italic?: boolean }[] = [
    { text: 'ОДНО', field: 'black' },
    { text: 'СЛОВО', field: 'lime', from: 'left' },
    { text: 'НА', field: 'blue', from: 'up' },
    { text: 'ДОЛЮ', field: 'red', from: 'right', italic: true },
    { text: 'БИТА', field: 'white', accent: true },
  ];
  return (
    <Stage>
      <WordHits f={f} words={W.map((w, i) => ({ ...w, at: B(i) }))} />
    </Stage>
  );
};

const DSlam: React.FC = () => {
  const f = useCurrentFrame();
  const froms = ['zoom', 'left', 'right', 'up'] as const;
  const i = Math.min(3, Math.max(0, Math.floor((f - B(0)) / GZY.T)));
  return (
    <Stage bg={C.black}>
      <SpeedLines f={f} at={B(i)} color={C.lime} />
      <Slam f={f} at={B(i)} text="ВРЕЗКА" from={froms[i]} color={C.white} />
    </Stage>
  );
};

const DStack: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage bg={C.blue}>
      <Stack
        f={f}
        lines={[
          { at: B(0), text: 'ТРИ' },
          { at: B(1), text: 'СТРОКИ', color: C.lime, italic: true },
          { at: B(2), text: 'ВО ВСЮ ШИРИНУ' },
        ]}
      />
    </Stage>
  );
};

const DStretch: React.FC = () => {
  const f = useCurrentFrame();
  const sag = f >= B(2.5);
  return (
    <Stage bg={sag ? '#5e5e60' : C.red}>
      {!sag && <Stretch f={f} at={B(0)} text="ГРОМЧЕ" color={C.black} />}
      {sag && <Stretch f={f} at={B(2.5)} text="СКУЧНО" mode="sag" color={C.gray} />}
    </Stage>
  );
};

const DSlice: React.FC = () => {
  const f = useCurrentFrame();
  const after = f >= B(1.5) + 6;
  return (
    <Stage bg={after ? C.lime : C.black}>
      {after && <Slam f={f} at={B(1.5) + 6} text="НОВОЕ" color={C.black} />}
      <Slice f={f} at={B(0)} cut={B(1.5)} text="СТАРОЕ" color={C.white} blade={C.red} />
    </Stage>
  );
};

const DEcho: React.FC = () => {
  const f = useCurrentFrame();
  const k = f >= B(2) ? 1 : 0;
  return (
    <Stage bg={k ? C.lime : C.black}>
      <Echo f={f} at={B(k ? 2 : 0)} text={k ? 'ЕЩЁ РАЗ' : 'ЭХО'} color={k ? C.black : C.white} echo={k ? C.blue : C.lime} />
    </Stage>
  );
};

const DDuotone: React.FC = () => {
  const f = useCurrentFrame();
  const duos = ['ink', 'lime', 'blue', 'red', 'acid', 'hot'] as const;
  const i = Math.min(duos.length - 1, Math.max(0, Math.floor((f - B(0)) / (GZY.T / 2))));
  return (
    <Stage>
      <PunchCam f={f} hits={beats(12, 0, 0.5)} amp={0.04}>
        <Footage name="tilt" duo={duos[i]} zoom={1.05} />
      </PunchCam>
    </Stage>
  );
};

const DCut: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage bg={C.blue}>
      <PunchCam f={f} hits={beats(5, 1)} amp={0.03}>
        <Cut f={f} at={B(0)} x={90} y={420} w={880} h={720} rot={-3} plate={C.lime} hits={beats(4, 1)}>
          <Footage name="orbA" duo="ink" fit="cover" />
        </Cut>
        <Tag f={f} at={B(1)} text="без рамок" x={90} y={1250} rot={-5} size={92} />
        <Arrow f={f} at={B(2)} x={900} y={1290} angle={-150} len={300} color={C.white} hits={beats(2, 3)} />
      </PunchCam>
    </Stage>
  );
};

const DBars: React.FC = () => {
  const f = useCurrentFrame();
  const rows = [
    { duo: 'lime' as const, word: 'ВСЁ', cx: 300, x: 300, color: C.lime, bg: C.black },
    { duo: 'blue' as const, word: 'ПОД', cx: 760, x: -300, color: C.lime, bg: C.blue },
    { duo: 'red' as const, word: 'БИТ', cx: 300, x: 300, color: C.black, bg: C.red },
  ];
  const st = Math.round(GZY.T / 2);
  return (
    <Stage bg={C.black}>
      <Graphic f={f} kind="halftone" a={C.black} b="#262628" />
      <Bars
        f={f}
        at={B(0)}
        stagger={st}
        shift={B(2.5)}
        top={230}
        height={1210}
        items={rows.map((r, i) => (
          <AbsoluteFill key={i} style={{ background: r.bg }}>
            <AbsoluteFill style={{ left: r.x, right: -r.x }}>
              <Footage name={i === 1 ? 'tilt' : 'orbA'} duo={r.duo} />
            </AbsoluteFill>
            <Slam f={f} at={B(0) + i * st + 2} text={r.word} cx={r.cx} cy={202} size={300} color={r.color} from="cut" />
          </AbsoluteFill>
        ))}
      />
    </Stage>
  );
};

const DBurst: React.FC = () => {
  const f = useCurrentFrame();
  const items = [
    <Footage key={0} name="orbA" duo="lime" fit="cover" zoom={1.1} />,
    <Graphic key={1} f={f} kind="rays" a={C.blue} b={C.lime} />,
    <Footage key={2} name="tilt" duo="red" fit="cover" />,
    <Graphic key={3} f={f} kind="halftone" a={C.red} b={C.black} />,
    <Footage key={4} name="trio" duo="blue" fit="cover" zoom={1.3} />,
    <Graphic key={5} f={f} kind="checker" a={C.black} b={C.white} />,
    <Footage key={6} name="orbC" duo="acid" fit="cover" />,
    <Graphic key={7} f={f} kind="circle" a={C.lime} b={C.blue} />,
    <Footage key={8} name="orbA" duo="hot" fit="cover" zoom={1.8} x={60} />,
    <Graphic key={9} f={f} kind="stripes" a={C.black} b={C.lime} />,
  ];
  return (
    <Stage>
      <Burst f={f} at={B(0)} every={4} items={[...items, ...items]} />
      <Slam f={f} at={B(0)} text="КАДР" cy={835} maxSize={360} color={C.white} from="cut" out={B(1)} blend="difference" />
      <Slam f={f} at={B(1)} text="КАДР" cy={835} maxSize={360} color={C.white} italic from="cut" out={B(2)} blend="difference" />
      <Slam f={f} at={B(2)} text="КАДР!" cy={835} maxSize={360} color={C.white} from="zoom" blend="difference" />
    </Stage>
  );
};

const DGraphic: React.FC = () => {
  const f = useCurrentFrame();
  const kinds = ['rays', 'halftone', 'checker', 'stripes', 'circle'] as const;
  const pairs: [string, string][] = [
    [C.blue, C.lime],
    [C.red, C.black],
    [C.black, C.white],
    [C.lime, C.black],
    [C.black, C.red],
  ];
  const i = Math.min(4, Math.max(0, Math.floor((f - B(0)) / GZY.T)));
  return (
    <Stage>
      <Graphic f={f} kind={kinds[i]} a={pairs[i][0]} b={pairs[i][1]} />
    </Stage>
  );
};

const SceneA: React.FC<{ f: number }> = ({ f }) => (
  <AbsoluteFill style={{ background: C.black }}>
    <Footage name="orbA" duo="ink" />
    <Slam f={f} at={0} text="БЫЛО" cy={1200} maxSize={320} color={C.white} from="cut" />
  </AbsoluteFill>
);
const SceneB: React.FC<{ f: number; at: number; bg?: string; fg?: string }> = ({ f, at, bg = C.lime, fg = C.black }) => (
  <AbsoluteFill style={{ background: bg }}>
    <Slam f={f} at={at} text="СТАЛО" maxSize={420} color={fg} />
  </AbsoluteFill>
);

const DSmash: React.FC = () => {
  const f = useCurrentFrame();
  const at = B(1.5);
  return (
    <Stage>
      {f < at + 4 ? <SceneA f={f} /> : <SceneB f={f} at={at + 4} bg={C.blue} fg={C.white} />}
      <Smash f={f} at={at} color={C.lime} />
    </Stage>
  );
};

const DShutter: React.FC = () => {
  const f = useCurrentFrame();
  const at = B(1.5);
  return (
    <Stage>
      {f < at + 5 ? <SceneA f={f} /> : <SceneB f={f} at={at + 6} bg={C.red} fg={C.black} />}
      <Shutter f={f} at={at} color={C.black} />
    </Stage>
  );
};

const DFlash: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <PunchCam f={f} hits={beats(4)}>
        <Footage name="tilt" duo="blue" />
        <Slam f={f} at={B(0)} text="ВСПЫШКА" cy={1250} maxSize={300} color={C.lime} from="cut" />
      </PunchCam>
      <Flash f={f} at={B(0)} len={2} />
      <Flash f={f} at={B(1)} len={3} mode="invert" />
      <Flash f={f} at={B(2)} len={2} color={C.lime} />
      <Flash f={f} at={B(3)} len={3} mode="invert" />
    </Stage>
  );
};

const DPunchThrough: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <PunchThrough
        f={f}
        at={B(1.5)}
        ox={540}
        oy={835}
        a={
          <AbsoluteFill style={{ background: C.red }}>
            <Slam f={f} at={B(0)} text="НАСКВОЗЬ" color={C.black} />
          </AbsoluteFill>
        }
        b={
          <AbsoluteFill style={{ background: C.black }}>
            <Footage name="orbA" duo="lime" />
          </AbsoluteFill>
        }
      />
    </Stage>
  );
};

const DNumber: React.FC = () => {
  const f = useCurrentFrame();
  const flip = f >= B(3);
  return (
    <Stage bg={flip ? C.lime : C.black}>
      <NumberSlam f={f} at={B(0)} lock={B(1)} value="×3" cy={760} color={flip ? C.black : C.white} />
      <Slam f={f} at={B(2)} text="досмотров" cy={1150} size={130} family={'"Udar Text", sans-serif'} color={flip ? C.black : C.lime} from="left" />
      <Zigzag f={f} at={B(2.5)} x={280} y={1230} w={520} color={flip ? C.blue : C.white} />
    </Stage>
  );
};

const DTag: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Footage name="tilt" duo="ink" />
      <Tag f={f} at={B(0)} text="новинка" x={90} y={420} rot={-6} />
      <Tag f={f} at={B(1)} text="−40%" x={990} y={700} rot={5} bg={C.red} fg={C.black} size={96} from="right" anchor="right" />
      <Tag f={f} at={B(2)} text="уже в продаже" x={540} y={1300} rot={-3} bg={C.blue} fg={C.white} from="up" anchor="center" />
    </Stage>
  );
};

const DMarks: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage bg={C.blue}>
      <Starburst f={f} at={B(0)} r={470} color={C.lime} hits={beats(4, 1)} />
      <Slam f={f} at={B(0)} text="ВАУ" maxSize={420} color={C.black} />
      <SpeedLines f={f} at={B(0)} color={C.white} inner={520} />
      <Brackets f={f} at={B(1)} x={150} y={380} w={780} h={900} color={C.white} />
      <Arrow f={f} at={B(2)} x={330} y={1300} angle={-60} len={220} color={C.white} hits={beats(2, 3)} />
      <Zigzag f={f} at={B(2.5)} x={300} y={1080} w={480} color={C.red} />
      <Plus f={f} at={B(1.5)} x={180} y={330} color={C.white} />
      <Plus f={f} at={B(2)} x={900} y={1180} color={C.red} size={70} />
      <Plus f={f} at={B(3)} x={860} y={300} color={C.lime} size={44} />
    </Stage>
  );
};

const DTape: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage bg={C.black}>
      <Footage name="orbC" duo="hot" zoom={1.1} />
      <Tape f={f} at={B(0)} text="НЕ ЛИСТАЙ" y={640} angle={-9} bg={C.lime} fg={C.black} />
      <Tape f={f} at={B(1)} text="СМОТРИ ДО КОНЦА" y={1060} angle={7} bg={C.white} fg={C.black} dir={-1} speed={11} />
    </Stage>
  );
};

// ── Режим «говорящая голова» (заглушка вместо реального человека) ────────────
const say = (list: string, from: number, step: number, keys: string[] = []): CapWord[] =>
  list.split(' ').map((t, i) => ({ text: t, s: from + Math.round(i * step), key: keys.includes(t.replace(/[.,!?]/g, '')) }));

const DCaptions: React.FC = () => {
  const f = useCurrentFrame();
  const words = say('Я покажу как монтировать ролики которые досматривают до конца.', 6, 8, ['монтировать', 'досматривают']);
  return (
    <Stage>
      <SpeakerStub f={f} />
      <Captions f={f} words={words} />
    </Stage>
  );
};

const DHeadCam: React.FC = () => {
  const f = useCurrentFrame();
  const words = say('Первая мысль. Вторая мысль крупнее. А это панчлайн!', 6, 8, ['панчлайн']);
  return (
    <Stage>
      <HeadCam f={f} cuts={[{ at: 0, z: 1 }, { at: 22, z: 1.18, y: 40 }, { at: 54, z: 1.0 }, { at: 70, z: 1.34, y: 60 }]} oy={720}>
        <SpeakerStub f={f} />
      </HeadCam>
      <Flash f={f} at={70} len={2} />
      <Captions f={f} words={words} />
    </Stage>
  );
};

const DSplitTop: React.FC = () => {
  const f = useCurrentFrame();
  const words = say('Вот как это выглядит на деле.', 6, 9, ['деле']);
  return (
    <Stage>
      <SplitTop
        f={f}
        at={B(1)}
        out={B(4.5)}
        panel={
          <AbsoluteFill style={{ background: C.black }}>
            <Footage name="orbA" duo="lime" />
            <Tag f={f} at={B(1.5)} text="пример" x={90} y={330} rot={-5} bg={C.white} />
          </AbsoluteFill>
        }
      >
        <SpeakerStub f={f} />
      </SplitTop>
      <Captions f={f} words={words} />
    </Stage>
  );
};

const DHeadInsert: React.FC = () => {
  const f = useCurrentFrame();
  const words = say('Главное правило одно: удар на каждой доле.', 4, 7, ['удар']);
  const cut0 = 34;
  const cut1 = 58;
  return (
    <Stage>
      <FreezeDuo f={f} at={cut1} out={cut1 + 22} duo="lime">
        <HeadCam f={f} cuts={[{ at: 0, z: 1 }, { at: 20, z: 1.2, y: 40 }]}>
          <SpeakerStub f={f} />
        </HeadCam>
      </FreezeDuo>
      {/* полноэкранная вставка-удар поверх голоса: 0.8 с */}
      {f >= cut0 && f < cut0 + 22 && (
        <AbsoluteFill style={{ background: C.red }}>
          <Echo f={f} at={cut0} text="ОДНО" color={C.black} echo={C.white} />
        </AbsoluteFill>
      )}
      {f >= cut1 && f < cut1 + 22 && <Slam f={f} at={cut1} text="УДАР" cy={640} maxSize={360} color={C.white} />}
      <Tag f={f} at={8} out={cut0} text="правило №1" x={90} y={420} rot={-5} />
      <Flash f={f} at={cut0} len={1} />
      <Captions f={f} words={words} hide={[[cut0, cut0 + 22]]} />
    </Stage>
  );
};

export const PACK_DEMOS: { id: string; dur: number; C: React.FC }[] = [
  { id: 'own-punch-cam', dur: 120, C: DPunchCam },
  { id: 'own-word-hits', dur: 110, C: DWordHits },
  { id: 'own-slam', dur: 100, C: DSlam },
  { id: 'own-stack', dur: 90, C: DStack },
  { id: 'own-stretch', dur: 100, C: DStretch },
  { id: 'own-slice', dur: 90, C: DSlice },
  { id: 'own-echo', dur: 90, C: DEcho },
  { id: 'own-duotone', dur: 80, C: DDuotone },
  { id: 'own-cut', dur: 110, C: DCut },
  { id: 'own-bars', dur: 100, C: DBars },
  { id: 'own-burst', dur: 80, C: DBurst },
  { id: 'own-graphic', dur: 110, C: DGraphic },
  { id: 'own-smash', dur: 80, C: DSmash },
  { id: 'own-shutter', dur: 80, C: DShutter },
  { id: 'own-flash', dur: 90, C: DFlash },
  { id: 'own-punch-through', dur: 80, C: DPunchThrough },
  { id: 'own-number', dur: 100, C: DNumber },
  { id: 'own-tag', dur: 90, C: DTag },
  { id: 'own-marks', dur: 100, C: DMarks },
  { id: 'own-tape', dur: 90, C: DTape },
  { id: 'own-captions', dur: 90, C: DCaptions },
  { id: 'own-head-cam', dur: 100, C: DHeadCam },
  { id: 'own-split-top', dur: 110, C: DSplitTop },
  { id: 'own-head-insert', dur: 100, C: DHeadInsert },
];

