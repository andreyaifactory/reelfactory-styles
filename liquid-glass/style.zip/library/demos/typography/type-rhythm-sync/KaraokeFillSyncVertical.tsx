// karaoke-fill-sync · 竖版 9:16（1080×1920）。
// 词级时间表（SHIP 20–38 / FASTER 42–75 / BREAK 85–103 / NOTHING 107–130）、线性填充、读指下划线全部同横版。
// 竖版：两行四词改为一词一行的竖排，字号 130→150（相对画宽放大），左对齐 x 110，整组对准安全区中心；
// 下划线厚度 8→10、偏移 -14→-16 随字号等比。
// 以下为横版原注释：
// 卡拉OK填色随读（karaoke-fill-sync）——旁白读到哪个词，哪个词就被深色从左到右
// 点亮。每个词双层同文本叠放：底层 G.line 浅灰字，上层 G.ink 深字用 clip-path: inset(0 X% 0 0) 按词内进度线性填充。
// 正在填的词底下有深色下划线跟随填充右缘作读指。0–19f hold；130–149f 真静止。
import React from 'react';
import { useCurrentFrame, interpolate } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { SafeArea } from '../../_fixtures/Vertical';

type Word = { text: string; start: number; end: number };

export const KARAOKE_FILL_SYNC_VERTICAL_DURATION = 150;

const WORDS: Word[] = [
  { text: 'SHIP', start: 20, end: 38 },
  { text: 'FASTER', start: 42, end: 75 },
  { text: 'BREAK', start: 85, end: 103 },
  { text: 'NOTHING', start: 107, end: 130 },
];

const KaraokeWord: React.FC<{ word: Word; frame: number }> = ({ word, frame }) => {
  const p = interpolate(frame, [word.start, word.end], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const active = frame >= word.start && frame < word.end;
  return (
    <span style={{ position: 'relative', display: 'inline-block' }}>
      <span style={{ color: G.line }}>{word.text}</span>
      <span style={{ position: 'absolute', inset: 0, color: G.ink, clipPath: `inset(0 ${(1 - p) * 100}% 0 0)` }}>{word.text}</span>
      {active && <span style={{ position: 'absolute', left: 0, bottom: -16, width: `${p * 100}%`, height: 10, background: G.ink }} />}
    </span>
  );
};

export const KaraokeFillSyncVertical: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, overflow: 'hidden', position: 'relative' }}>
      <SafeArea style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', paddingLeft: 110, boxSizing: 'border-box', fontFamily: 'Helvetica, Arial, sans-serif', fontSize: 150, fontWeight: 800, letterSpacing: 2, lineHeight: 1.3 }}>
        {WORDS.map((w) => (
          <div key={w.text}>
            <KaraokeWord word={w} frame={frame} />
          </div>
        ))}
      </SafeArea>
    </div>
  );
};
