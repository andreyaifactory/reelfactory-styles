// outline-word-fill · 竖版 9:16（1080×1920）。
// 保留：全部时间段（落位 0.05–0.19、圆收缩 0.16–0.76、虚线伸入 0.5–0.72、实心点亮 0.742–0.762、辉光 0.762–0.86）与缓动。
// 竖版：设计坐标 480×270 → 270×480（DesignStage 等比放大 4×）；字号 48→52（占画宽约五成，手机可读），
// 原点下移到安全区中心（y 835 → 设计坐标 208.75）；水平虚线改为竖向从上下边伸向圆（竖画面的长边），圆半径 88→100。
// 以下为横版原注释：
// 空心 "Faster"（细灰描边、中等字重）从约 3.2 倍巨大尺寸急缓收缩落位居中；背后巨大虚线圆随后从画外持续收缩到字周围
// 并缓慢自转，两侧水平虚线从画框边缘向内伸向圆；描边先微微增亮，随即实心白色一帧内瞬间点亮，带一闪即逝的微辉光后定格纯白。
import React from 'react';
import { DesignStage, E, lerp, rand, seg, useT } from '../../_fixtures/Motion';

export const OUTLINE_WORD_FILL_VERTICAL_DURATION = 75;
const CY = 835 / 4; // 安全区中心（设计坐标）
const DUST = Array.from({ length: 18 }, (_, i) => ({
  size: 1 + rand(i * 7 + 2) * 1.2,
  opacity: 0.06 + rand(i + 55) * 0.14,
  left: `${rand(i + 13) * 100}%`,
  top: `${rand(i + 29) * 100}%`,
}));

export const OutlineWordFillVertical: React.FC = () => {
  const t = useT();
  const born = seg(t, 0.05, 0.14, E.outCubic);
  const zoom = seg(t, 0.05, 0.19, E.outCubic);
  const bright = seg(t, 0.66, 0.73, E.outQuad);
  const gv = Math.round(lerp(bright, 86, 145));
  const cin = seg(t, 0.16, 0.3, E.outQuad);
  const shrink = seg(t, 0.16, 0.76, E.outCubic);
  const ext = seg(t, 0.5, 0.72, E.outCubic);
  const pop = seg(t, 0.742, 0.762);
  const flash = pop * (1 - seg(t, 0.762, 0.86, E.outQuad));
  return (
    <DesignStage w={270} h={480} bg="#030303">
      <div style={{ position: 'absolute', inset: 0, background: '#030303', overflow: 'hidden' }}>
        {DUST.map(({ size, opacity, left, top }, i) => (
          <div key={i} style={{ position: 'absolute', width: size, height: size, borderRadius: '50%', background: '#fff', opacity, left, top }} />
        ))}
        <svg viewBox={`-135 ${-CY} 270 480`} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          <g transform={`scale(${lerp(shrink, 2.8, 1)}) rotate(${t * 18})`}>
            <circle cx={0} cy={0} r={100} fill="none" stroke="#7d838e" strokeWidth={1} strokeDasharray="6 8" opacity={cin * 0.85} />
          </g>
          <line x1={0} x2={0} y1={-CY + 57} y2={-CY + 57 + ext * (CY - 57 - 100)} stroke="#7d838e" strokeWidth={1} strokeDasharray="5 7" opacity={ext} />
          <line x1={0} x2={0} y1={360 - CY} y2={360 - CY - ext * (360 - CY - 100)} stroke="#7d838e" strokeWidth={1} strokeDasharray="5 7" opacity={ext} />
        </svg>
        <div
          style={{
            position: 'absolute',
            left: '50%',
            top: CY,
            fontFamily: '-apple-system,"Helvetica Neue",sans-serif',
            fontSize: 52,
            fontWeight: 500,
            letterSpacing: 0.5,
            lineHeight: 1,
            opacity: born,
            transform: `translate(-50%,-53%) scale(${lerp(zoom, 3.2, 1)})`,
          }}
        >
          <div style={{ color: 'transparent', WebkitTextStroke: `1px rgb(${gv - 4},${gv},${gv + 8})`, opacity: 1 - pop }}>Faster</div>
          <div style={{ position: 'absolute', inset: 0, color: '#fff', opacity: pop, textShadow: flash > 0.01 ? `0 0 ${flash * 16}px rgba(255,255,255,${flash * 0.45})` : 'none' }}>Faster</div>
        </div>
      </div>
    </DesignStage>
  );
};
