// before-after-slider-scrub · 竖版 9:16（1080×1920）：快甩 8→76→70% / 停顿 / 慢扫到 40% 的时间轴同横版（150f）。
// 竖版：页面换竖版假 App；杆仍横向扫（拇指手势方向），手柄放大到 110 并对准安全区中心；
// 前/后角标下移进安全区（y 250），右角标右缘 ≤ 940。
// 以下为横版原注释：
// before-after-slider-scrub —— 前后对比拉杆
// FakeDashboard 两版叠放：before = 低对比灰蒙版（"处理前"），after = 正常清晰版。
// 竖分割杆带圆手柄：从左端 8% 快甩到 70%（overshoot 至 76% 回弹），
// 再慢速回扫到 40% 停住。杆经过处 after 揭出（clip-path inset 跟随杆 x）。
// 先快甩后慢扫速度对比是节奏关键。f=110 后全静止（40f）。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const BEFORE_AFTER_SLIDER_SCRUB_VERTICAL_DURATION = 150;

const CL = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;

// 时间轴（杆位置以画面宽度百分比表示）
const T0 = 14; // 前 14f 初始静置，杆停在 8%
const FLING = 26; // 快甩：14→26（12f 冲到 76%）
const BOUNCE = 38; // 回弹：26→38 落到 70%
const HOLD = 56; // 停顿看清
const SCRUB = 104; // 慢扫：56→104（48f 回到 40%）——速度约为快甩的 1/5

const posAt = (f: number): number => {
  if (f < FLING)
    return interpolate(f, [T0, FLING], [8, 76], { easing: Easing.out(Easing.cubic), ...CL });
  if (f < BOUNCE)
    return interpolate(f, [FLING, BOUNCE], [76, 70], { easing: Easing.inOut(Easing.cubic), ...CL });
  if (f < HOLD) return 70;
  return interpolate(f, [HOLD, SCRUB], [70, 40], { easing: Easing.inOut(Easing.quad), ...CL });
};

export const BeforeAfterSliderScrubVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const p = posAt(frame); // 杆位置 %
  const x = (p / 100) * 1080;

  // 手柄挤压：速度差分驱动（快甩期手柄微拉伸，静止归 1）
  const v = Math.abs(posAt(frame) - posAt(frame - 1)); // %/frame
  const squish = 1 + Math.min(v / 8, 1) * 0.18;

  return (
    <div style={{ width: 1080, height: 1920, position: 'relative', overflow: 'hidden', background: G.bg }}>
      {/* before：低对比灰蒙版模拟"处理前" */}
      <div style={{ position: 'absolute', inset: 0, filter: 'contrast(0.55) brightness(1.06) grayscale(1)' }}>
        <FakeDashboardV variant="A" />
      </div>
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(160,160,158,0.35)' }} />

      {/* after：正常清晰版，杆左侧揭出 */}
      <div style={{ position: 'absolute', inset: 0, clipPath: `inset(0 ${1080 - x}px 0 0)` }}>
        <FakeDashboardV variant="A" />
      </div>

      {/* 分割杆 + 圆手柄 */}
      <div
        style={{
          position: 'absolute',
          left: x - 3,
          top: 0,
          width: 7,
          height: 1920,
          background: '#ffffff',
          boxShadow: '0 0 14px rgba(0,0,0,0.35)',
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: x - 55,
          top: SAFE_CY - 55,
          width: 110,
          height: 110,
          borderRadius: 55,
          background: '#ffffff',
          border: `3px solid ${G.border}`,
          boxShadow: '0 6px 24px rgba(0,0,0,0.3)',
          transform: `scaleX(${squish})`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 10,
          boxSizing: 'border-box',
        }}
      >
        {/* 左右箭头示意（灰阶三角） */}
        <div style={{ width: 0, height: 0, borderTop: '10px solid transparent', borderBottom: '10px solid transparent', borderRight: `14px solid ${G.mid}` }} />
        <div style={{ width: 0, height: 0, borderTop: '10px solid transparent', borderBottom: '10px solid transparent', borderLeft: `14px solid ${G.mid}` }} />
      </div>

      {/* 角标：BEFORE / AFTER 灰块标签 */}
      <div style={{ position: 'absolute', left: 60, top: 250, padding: '12px 24px', borderRadius: 10, background: 'rgba(47,47,47,0.85)', display: 'flex', gap: 8 }}>
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} style={{ width: 16, height: 20, borderRadius: 4, background: '#e6e6e4' }} />
        ))}
      </div>
      <div style={{ position: 'absolute', right: 140, top: 250, padding: '12px 24px', borderRadius: 10, background: 'rgba(240,240,238,0.9)', border: `2px solid ${G.border}`, display: 'flex', gap: 8 }}>
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} style={{ width: 16, height: 20, borderRadius: 4, background: G.ink }} />
        ))}
      </div>
    </div>
  );
};
