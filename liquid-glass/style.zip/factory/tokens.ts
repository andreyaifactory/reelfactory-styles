import type { StyleTokens } from '../../../core/style-contract';
import { C, DISPLAY, IRIS, TEXT } from '../kit/kit';

/**
 * «Жидкое стекло» в словаре ядра фабрики. Значения — из `pack.json → tokens`:
 * глубокая ночь, белый текст, перелив циан → фиолетовый → розовый → персик
 * только в свете, кромке, блике, капле и одном слове сцены. Unbounded крупно и
 * мало слов, Manrope — всё мелкое, имена и подписи.
 */
export const tokens: StyleTokens = {
  name: 'Жидкое стекло',

  color: {
    text: C.text,
    textMuted: C.muted,
    textFaint: C.dim,
    bg: C.bg,
    bgTop: C.bg2,
    accent: C.violet,
    accentSoft: 'rgba(143,107,255,0.18)',
    surface: 'rgba(255,255,255,0.10)',
    surfaceBorder: 'rgba(255,255,255,0.24)',
    cyan: C.cyan,
    violet: C.violet,
    pink: C.pink,
    peach: C.peach,
    iris: IRIS,
  },

  type: {
    hero: { size: 104, weight: 600, lh: 1.08, ls: '-0.03em', family: DISPLAY },
    heroTight: { size: 88, weight: 600, lh: 1.08, ls: '-0.03em', family: DISPLAY },
    title: { size: 64, weight: 600, lh: 1.12, ls: '-0.025em', family: DISPLAY },
    stat: { size: 180, weight: 700, lh: 1.0, ls: '-0.05em', family: DISPLAY },
    label: { size: 32, weight: 700, lh: 1.25, ls: '-0.005em', family: TEXT },
    body: { size: 44, weight: 600, lh: 1.3, ls: '-0.01em', family: TEXT },
    pill: { size: 42, weight: 700, lh: 1.1, ls: '-0.01em', family: TEXT },
    glassTitle: { size: 144, weight: 800, lh: 1.0, ls: '-0.035em', family: TEXT },
  },

  /** Стекло толстое и скруглённое: плита 44, капсула 56, пилюля — полукруг. */
  radius: { card: 44, capsule: 56, pill: 999, bar: 999 },

  space: { gap: 22 },

  extra: {
    /** Ореола вокруг текста нет: свет живёт сзади, в кромке и в капле. */
    glow: 'none',
    /** «Жемчуг» — тот же мир днём. Весь ролик, не вперемешку с «Ночью». */
    pearl: { bg: C.pearl, bgTop: C.pearl2, text: C.ink, muted: C.inkMuted, accent: C.violet },
  },
};
