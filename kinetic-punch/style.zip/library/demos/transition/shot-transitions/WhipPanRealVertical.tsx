// whip-pan · 竖版 9:16（1080×1920）。
// 保留：0–35 A hold → 35–43 甩 8f（bezier 0.6,0,0.4,1），blur 包甩动段（200°/20 samples）→ 43–120 B hold。
// 竖版：甩动距离 2880（1.5 屏）→ 1620（竖画宽的 1.5 屏）；页面按原尺寸（1920 宽）放，观察窗对准卡片网格（页面 x≈233 起），
// A 景页面上移 180 → 卡片网格落在安全区上部；B 景取同页底部区块（top −666），网格同样落在安全区。
// 以下为横版原注释：
// E 式基本款 whip-pan——真实整页冻结纹理。世界：projects-full 顶部 section（A 景）与同页底部 section（B 景）横向并排
// ——模拟"功能段之间的区块交棒"，blur 只包甩动段。
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame, Easing } from 'remotion';
import { CameraMotionBlur } from '@remotion/motion-blur';

export const WHIPPAN_VERTICAL_DUR = 120;
const SWING = 1620;
const VIEW_X = -233;

const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const dx = interpolate(frame, [35, 43], [0, SWING], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.bezier(0.6, 0, 0.4, 1) });
  return (
    <AbsoluteFill style={{ backgroundColor: '#f9f6f1', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', transform: `translateX(${-dx}px)` }}>
        <Img src={staticFile('textures/live/projects-full.png')} style={{ position: 'absolute', left: VIEW_X, top: 60, width: 1920 }} />
        <Img src={staticFile('textures/live/projects-full.png')} style={{ position: 'absolute', left: SWING + VIEW_X, top: -420, width: 1920 }} />
      </div>
    </AbsoluteFill>
  );
};

export const WhipPanRealVertical: React.FC = () => (
  <CameraMotionBlur shutterAngle={200} samples={20}>
    <Scene />
  </CameraMotionBlur>
);
