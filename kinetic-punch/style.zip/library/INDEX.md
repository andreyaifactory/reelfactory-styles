# Библиотека приёмов пака «Удар»

Всё нужное для повторения приёмов лежит здесь, интернет и репозиторий не нужны.

- `cards/<имя>.md` — описание приёма: идея, параметры, известные подводные камни. **Читать перед реализацией.** Карточка иногда описывает несколько вариантов приёма; в пак вошли только те, у которых есть файл в колонке «Сцена».
- `demos/<категория>/<имя>/<Сцена>Vertical.tsx` — эталонный код Remotion, кадр 1080×1920. Параметры в коде — проверенная настройка: адаптировать под материал можно, ухудшать параметры из разделов описания «Главное» и «Известные ловушки» нельзя.
- `demos/_fixtures`, `demos/_textures` — общие файлы, на которые ссылается код. Размеры кадра и вертикальная заглушка-приложение — `demos/_fixtures/Vertical.tsx`, правила раскладки — в его начале. `QuadSplitParallelScenes.tsx` рядом с вертикальной версией — её общие части, отдельной сценой не берётся.
- `public/textures/live/` — картинки, которые код берёт через `staticFile()`. **Скопировать содержимое `library/public/` в `public/` своего Remotion-проекта.**

**npm-зависимости всех приёмов:** `@remotion/motion-blur`, `react`, `remotion`

Описания приёмов — на русском. Комментарии в коде могут быть на китайском (оригинал библиотеки video-shotcraft); назначение каждого приёма в этом паке — в `../pack.json`. Код сцен нейтральный, серый: в ролике он перекрашивается в поля, дуотоны и шрифты пака (`kit/kit.tsx`: `FIELDS`, `DUO`, `DISPLAY`, `TEXT`), заглушки меняются на материал ролика.

Раскладка рассчитана на безопасную зону Reels: текст в y 230…1440, справа внизу пусто. Если проект задаёт свою безопасную зону, действует она.

| Приём | Сцена (9:16) | Длина | Доп. зависимости | Суть |
|---|---|---|---|---|
| [cel-flash-stomp](cards/cel-flash-stomp.md) | `demos/typography/cel-flash-stomp/CelFlashStompVertical.tsx` | 145f | — | Штамп с миганием поля: слово стоит, под ним поле мигает двумя цветами — кульминация, «главное» |
| [type-rhythm-sync](cards/type-rhythm-sync.md) | `demos/typography/type-rhythm-sync/FontWeightPumpVertical.tsx` (font-weight-pump) | 140f | — | Пульс жирности: слово «дышит» жирностью на каждую долю — когда слово стоит в кадре дольше доли |
| [pill-slot-cycle](cards/pill-slot-cycle.md) | `demos/typography/pill-slot-cycle/PillSlotCycleVertical.tsx` | 175f | — | Слот в фразе: «Монтаж для ___» — последнее слово сменяется на каждую долю |
| [lead-word-zoom-assemble](cards/lead-word-zoom-assemble.md) | `demos/typography/lead-word-zoom-assemble/LeadWordZoomAssembleVertical.tsx` | 84f | — | Первое слово крупно: хук — первое слово во весь кадр, потом фраза собирается в строку |
| [outline-word-fill](cards/outline-word-fill.md) | `demos/typography/outline-word-fill/OutlineWordFillVertical.tsx` | 75f | — | Контур → заливка: слово врезается контуром и заливается на доле |
| [type-entrance-moves](cards/type-entrance-moves.md) | `demos/typography/type-entrance-moves/LetterDropPhysicsVertical.tsx` (letter-drop-physics) | 150f | — | Буквы падают сверху и отскакивают — весело, «тяжело» |
| [title-demote-to-label](cards/title-demote-to-label.md) | `demos/typography/title-demote-to-label/TitleDemoteToLabelVertical.tsx` | 184f | — | Тема уходит в угол: тема врезается крупно, затем уезжает ярлыком в угол на время блока |
| [beat-cut-moves](cards/beat-cut-moves.md) | `demos/rhythm/beat-cut-moves/BeatCutAccelerandoVertical.tsx` (beat-cut-accelerando) | 130f | — | Ускоряющиеся склейки: склейки вдвое чаще к главному — нарастание |
| [beat-cut-moves](cards/beat-cut-moves.md) | `demos/rhythm/beat-cut-moves/PaparazziFlashVertical.tsx` (paparazzi-flash) | 130f | — | Папарацци: три белые вспышки, каждая — новый кадр того же предмета |
| [beat-step-list-theme-cycle](cards/beat-step-list-theme-cycle.md) | `demos/rhythm/beat-step-list-theme-cycle/BeatStepListThemeCycleVertical.tsx` | 110f | — | Список в такт: слова списка шагают вверх, поле и капсула меняют цвет на каждую долю |
| [montage-rhythm-moves](cards/montage-rhythm-moves.md) | `demos/rhythm/montage-rhythm-moves/DropBlackoutSlamVertical.tsx` (drop-blackout-slam) | 130f | — | Чёрный перед ударом: пауза в чёрное на долю и взрыв на главном |
| [montage-rhythm-moves](cards/montage-rhythm-moves.md) | `demos/rhythm/montage-rhythm-moves/WrightTripleCutVertical.tsx` (wright-triple-cut) | 130f | — | Три щелчка: три сверхкрупных кадра детали подряд |
| [panel-grid-moves](cards/panel-grid-moves.md) | `demos/rhythm/panel-grid-moves/GridFlashMosaicVertical.tsx` (grid-flash-mosaic) | 115f | — | Сетка вспышек: девять клеток вспыхивают кадрами и заполняют экран |
| [quad-split-parallel-scenes](cards/quad-split-parallel-scenes.md) | `demos/rhythm/quad-split-parallel-scenes/QuadSplitParallelScenesVertical.tsx` | 63f | — | Четыре экрана: четыре мини-сцены одновременно, удары со сдвигом |
| [rhythm-interrupt-moves](cards/rhythm-interrupt-moves.md) | `demos/rhythm/rhythm-interrupt-moves/JumpCutPunchInVertical.tsx` (jump-cut-punch-in) | 135f | — | Джамп-кат с наездом: три склейки с наездом на одной фразе говорящего |
| [speed-ramp-freeze](cards/speed-ramp-freeze.md) | `demos/rhythm/speed-ramp-freeze/FreezeAnnotateRealVertical.tsx` (freeze-annotate) | 135f | — | Стоп-кадр с пометкой: кадр замирает, деталь обводится, кадр «отмирает» |
| [speed-ramp-freeze](cards/speed-ramp-freeze.md) | `demos/rhythm/speed-ramp-freeze/SpeedRampRealVertical.tsx` (speed-ramp) | 135f | @remotion/motion-blur | Рывок скорости: быстро → почти стоп → быстро на одном движении |
| [trailer-grammar-moves](cards/trailer-grammar-moves.md) | `demos/rhythm/trailer-grammar-moves/TrailerBumperVertical.tsx` (trailer-bumper) | 140f | — | Хук-нарезка: сверхбыстрая нарезка лучших кадров в первые 1.5 с |
| [trailer-grammar-moves](cards/trailer-grammar-moves.md) | `demos/rhythm/trailer-grammar-moves/CardFootageCadenceVertical.tsx` (card-footage-cadence) | 150f | — | Карточки между фразами: между репликами — слово на цветовом поле |
| [trailer-grammar-moves](cards/trailer-grammar-moves.md) | `demos/rhythm/trailer-grammar-moves/SmashCutVertical.tsx` (smash-cut) | 135f | — | Смэш-кат: тишина → резкая склейка в громкое |
| [crash-zoom-punch](cards/crash-zoom-punch.md) | `demos/camera/crash-zoom-punch/CrashZoomRealVertical.tsx` | 120f | @remotion/motion-blur | Краш-зум: рывок с общего плана в деталь за 6 кадров, стоп с тряской |
| [shot-transitions](cards/shot-transitions.md) | `demos/transition/shot-transitions/FlashCutVertical.tsx` (flash-cut) | 60f | — | Белая вспышка: склейка под одним белым кадром |
| [shot-transitions](cards/shot-transitions.md) | `demos/transition/shot-transitions/WhipPanRealVertical.tsx` (whip-pan) | 120f | @remotion/motion-blur | Свиш-пан: кадр уезжает рывком вбок, из рывка — новая сцена |
| [color-block-step-wipe](cards/color-block-step-wipe.md) | `demos/transition/color-block-step-wipe/ColorBlockStepWipeVertical.tsx` | 150f | — | Цветной блок захватывает кадр 3–5 рывками |
| [bottom-push-stack-wipe](cards/bottom-push-stack-wipe.md) | `demos/transition/bottom-push-stack-wipe/BottomPushStackWipeVertical.tsx` | 140f | — | Выталкивание снизу: новая сцена с полем выталкивает старую вверх — смена главы |
| [transition-hidden-cut](cards/transition-hidden-cut.md) | `demos/transition/transition-hidden-cut/VersusSlamVertical.tsx` (versus-slam) | 120f | — | Лоб в лоб: два кадра сталкиваются с середины, склейка в ударе |
| [transition-travel](cards/transition-travel.md) | `demos/transition/transition-travel/LetterformZoomVertical.tsx` (letterform-zoom) | 140f | — | Сквозь букву: камера влетает в букву слова и выходит в новой сцене |
| [slam-entrance-moves](cards/slam-entrance-moves.md) | `demos/effects/slam-entrance-moves/ScoreSlamVertical.tsx` (score-slam) | 135f | — | Счёт падает: цифра падает сверху с ударом |
| [slam-entrance-moves](cards/slam-entrance-moves.md) | `demos/effects/slam-entrance-moves/ImpactBurstKitVertical.tsx` (impact-burst-kit) | 140f | — | Набор удара: вспышка, кольцо, осколки — главный удар ролика |
| [brand-frame-snap](cards/brand-frame-snap.md) | `demos/effects/brand-frame-snap/BrandFrameSnapVertical.tsx` | 130f | — | Цветная рамка: говорящий или экран в толстой цветной рамке, рамка меняет цвет на доле |
| [impact-feedback](cards/impact-feedback.md) | `demos/effects/impact-feedback/HitCounterVertical.tsx` (hit-counter) | 150f | — | Счётчик комбо: цифры-попадания со стоп-кадром — перечисление «раз, два, три» |
| [before-after-slider-scrub](cards/before-after-slider-scrub.md) | `demos/data/before-after-slider-scrub/BeforeAfterSliderScrubVertical.tsx` | 150f | — | До / после шторкой: шторка резко пролетает и медленно возвращается |
| [counter-confetti](cards/counter-confetti.md) | `demos/data/counter-confetti/CounterConfettiVertical.tsx` | 138f | — | Счётчик с конфетти: большая цифра результата и залп конфетти в цвета пака |
| [text-as-mask](cards/text-as-mask.md) | `demos/opening/text-as-mask/TextAsMaskVertical.tsx` | 150f | — | Видео в буквах: огромное слово, внутри видео; слово раздувается, видео забирает кадр |
| [edit-hook-moves](cards/edit-hook-moves.md) | `demos/outro/edit-hook-moves/LogoStingButtonVertical.tsx` (logo-sting-button) | 142f | — | Бонус после финала: 12 кадров сюрприза и обратно |
