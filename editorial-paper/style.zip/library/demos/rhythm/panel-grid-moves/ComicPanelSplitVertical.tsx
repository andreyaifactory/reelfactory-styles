// comic-panel-split · 竖版 9:16（1080×1920）。
// 节拍同横版（全屏 20f → 三格逐格 2f 弹入 3f scale 1.06→1 + 加深脉冲 → 定格 18f 微推 →
// 第三格 12f out-cubic 扩张吃屏 → 57f 摘罩特写直出，150f）。
// 竖版：分格从“竖向斜条”转成“横向斜带”——缝线 12° 斜（左低右高，左右落差 230），三带上下叠放；
// 三机位：全景 1x / 右上卡特写 1.9x / KPI 数字特写 2.2x（竖幅画宽窄，2.6 会让数字出画）；
// 数字特写焦点在分格期落在 (540,1250)，扩张后落到安全区中心。
import React from 'react';
import { AbsoluteFill, useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const COMIC_PANEL_SPLIT_VERTICAL_DURATION = 150;

const SPLIT = 20;
const POP = 3;
const STAGGER = 2;
const HOLD_END = 45;
const EXPAND_END = 57;
const outCubic = Easing.out(Easing.cubic);

// 缝线：y = yL + (yR - yL)·x/1080；边界1 左 560 / 右 330；边界2 左 1100 / 右 870（缝宽 10）
const B1L = 560, B1R = 330;
const B2L = 1100, B2R = 870;

// KPI 块（页面坐标）：左上卡内
const KPI = { x: 66, y: 300, w: 430, h: 180 };
const KPI_C = { x: KPI.x + KPI.w / 2, y: KPI.y + KPI.h / 2 };
const KPI_S = 2.2;
// 右上卡中心（页面坐标）
const CARD_C = { x: 554 + 245, y: 196 + 247 };

const PageA: React.FC = () => (
  <div style={{ width: 1080, height: 1920, position: 'relative' }}>
    <FakeDashboardV variant="A" />
    <div
      style={{
        position: 'absolute', left: KPI.x, top: KPI.y, width: KPI.w, height: KPI.h,
        background: G.card, borderRadius: 14, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 10,
      }}
    >
      <div style={{ fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 110, color: G.ink, letterSpacing: -2, lineHeight: 1 }}>
        1,284
      </div>
      <div style={{ height: 12, width: 170, background: G.mid, borderRadius: 6 }} />
    </div>
  </div>
);

type PanelSpec = {
  clip: string;
  centroidY: number;
  originX: number; originY: number;
  baseScale: number;
  tx: number; ty: number;
  z: number;
};

const FINAL = { tx: 540 - KPI_C.x, ty: SAFE_CY - KPI_C.y };

export const ComicPanelSplitVertical: React.FC = () => {
  const frame = useCurrentFrame();

  if (frame >= EXPAND_END) {
    return (
      <AbsoluteFill style={{ background: G.bg, overflow: 'hidden' }}>
        <div style={{ width: 1080, height: 1920, transform: `translate(${FINAL.tx}px, ${FINAL.ty}px) scale(${KPI_S})`, transformOrigin: `${KPI_C.x}px ${KPI_C.y}px` }}>
          <PageA />
        </div>
      </AbsoluteFill>
    );
  }

  if (frame < SPLIT) {
    return (
      <AbsoluteFill style={{ background: G.bg }}>
        <PageA />
      </AbsoluteFill>
    );
  }

  const push = interpolate(frame, [SPLIT + 2 * STAGGER + POP, HOLD_END], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const ex = interpolate(frame, [HOLD_END, EXPAND_END], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: outCubic });

  // 第三格上斜边（= 边界2 吃屏轨迹）：左 1105 → -60，右 875 → -290
  const e3L = 1105 + ex * (-60 - 1105);
  const e3R = 875 + ex * (-290 - 875);

  const panels: PanelSpec[] = [
    {
      clip: `polygon(0px 0px, 1080px 0px, 1080px ${B1R - 5}px, 0px ${B1L - 5}px)`,
      centroidY: 220, originX: 540, originY: 960,
      baseScale: 1 + push * 0.03, tx: 0, ty: 0, z: 1,
    },
    {
      clip: `polygon(0px ${B1L + 5}px, 1080px ${B1R + 5}px, 1080px ${B2R - 5}px, 0px ${B2L - 5}px)`,
      centroidY: 715, originX: CARD_C.x, originY: CARD_C.y,
      baseScale: 1.9 + push * 0.055, tx: 540 - CARD_C.x, ty: 715 - CARD_C.y, z: 1,
    },
    {
      clip: `polygon(0px ${e3L}px, 1080px ${e3R}px, 1080px 1920px, 0px 1920px)`,
      centroidY: 1400, originX: KPI_C.x, originY: KPI_C.y,
      baseScale: KPI_S + push * 0.08 * (1 - ex),
      tx: FINAL.tx, ty: 1250 - KPI_C.y + ex * (FINAL.ty - (1250 - KPI_C.y)), z: 3,
    },
  ];

  const seam1O = Math.min(
    interpolate(frame, [SPLIT + STAGGER, SPLIT + STAGGER + 2], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
    interpolate(frame, [HOLD_END, HOLD_END + 3], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
  );
  const seam2O = Math.min(
    interpolate(frame, [SPLIT + 2 * STAGGER, SPLIT + 2 * STAGGER + 2], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
    interpolate(frame, [EXPAND_END - 4, EXPAND_END], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }),
  );
  // 斜线向画外延长 10px 时的 y 偏移
  const k = (B1R - B1L) / 1080;

  return (
    <AbsoluteFill style={{ background: '#ffffff' }}>
      {panels.map((p, i) => {
        const start = SPLIT + i * STAGGER;
        if (frame < start) return null;
        const pop = interpolate(frame, [start, start + POP], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: outCubic });
        const popScale = 1.06 - 0.06 * pop;
        const pulse = 0.3 * (1 - pop);
        return (
          <div key={i} style={{ position: 'absolute', inset: 0, zIndex: p.z, clipPath: p.clip, transform: `scale(${popScale})`, transformOrigin: `540px ${p.centroidY}px` }}>
            <div style={{ width: 1080, height: 1920, transform: `translate(${p.tx}px, ${p.ty}px) scale(${p.baseScale})`, transformOrigin: `${p.originX}px ${p.originY}px` }}>
              <PageA />
            </div>
            {pulse > 0.005 && <div style={{ position: 'absolute', inset: 0, background: `rgba(0,0,0,${pulse})` }} />}
          </div>
        );
      })}
      {(seam1O > 0.005 || seam2O > 0.005) && (
        <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, zIndex: 5, pointerEvents: 'none' }}>
          {seam1O > 0.005 && (
            <g opacity={seam1O}>
              <line x1={-10} y1={B1L - 10 * k} x2={1090} y2={B1R + 10 * k} stroke="#2f2f2f" strokeWidth={16} />
              <line x1={-10} y1={B1L - 10 * k} x2={1090} y2={B1R + 10 * k} stroke="#ffffff" strokeWidth={10} />
            </g>
          )}
          {seam2O > 0.005 && (
            <g opacity={seam2O}>
              <line x1={-10} y1={e3L - 5 - 10 * k} x2={1090} y2={e3R - 5 + 10 * k} stroke="#2f2f2f" strokeWidth={16} />
              <line x1={-10} y1={e3L - 5 - 10 * k} x2={1090} y2={e3R - 5 + 10 * k} stroke="#ffffff" strokeWidth={10} />
            </g>
          )}
        </svg>
      )}
    </AbsoluteFill>
  );
};
