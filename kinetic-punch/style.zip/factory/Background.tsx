import React from 'react';
import { AbsoluteFill } from 'remotion';
import { C } from '../kit/kit';

/** Подложка кадра — чёрное поле «Удара». Плоское: без градиента, виньетки и текстуры. Цветное поле кладёт сцена. */
export const Background: React.FC = () => <AbsoluteFill style={{ background: C.black }} />;
