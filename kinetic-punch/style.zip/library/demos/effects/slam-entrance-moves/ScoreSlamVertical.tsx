// score-slam · 竖版 9:16（1080×1920）。
// 保留：0–8 hold → 8–14 砸落 in(quad)（scale 2.5→0.97、rotate 5→0、y −80→0）→ 14 落点触发环/尘/震 → 14–22 回弹 → 14–28 圆环 → 14–30 尘点 → 14–19 震屏 18px。
// 竖版：KPI 卡 460×260 → 760×420、数字 110→170px，卡心对准安全区中心；圆环直径 60→860 改 60→1300、尘点飞散 160–320 → 220–440（按画宽比例）；
// 下落 y −80→−110。背景 FakeDashboardV B 虚化。副标 "QUARTERLY GROWTH"（宽字距大写）改为常规 "Quarterly growth"。删除 TitleBlock 标签。
// 以下为横版原注释：
// 比分砸落入场——ESPN 比分弹窗 slam。KPI 卡从 scale 2.5 / rotate 5° / y-80 高空加速砸落屏心，落点帧同时触发三件套：
// 冲击波描边圆环扩散消散、8 个尘点小方块 seeded 抛物线飞散、整画面震屏指数衰减。砸落带 3% 压缩过冲回弹落定。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const SCORE_SLAM_VERTICAL_DURATION = 135;
const h = (n: number) => {
  const s = Math.sin(n * 127.3) * 43758.5453;
  return s - Math.floor(s);
};
const IMPACT = 14;
const CX = 540;
const CY = SAFE_CY;
const CARD_W = 760;
const CARD_H = 420;
const cl = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;

export const ScoreSlamVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const slamScale = frame < IMPACT ? interpolate(frame, [8, IMPACT], [2.5, 0.97], { ...cl, easing: Easing.in(Easing.quad) }) : interpolate(frame, [IMPACT, 22], [0.97, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const slamRot = interpolate(frame, [8, IMPACT], [5, 0], { ...cl, easing: Easing.in(Easing.quad) });
  const slamY = interpolate(frame, [8, IMPACT], [-110, 0], { ...cl, easing: Easing.in(Easing.quad) });
  const cardOp = interpolate(frame, [8, 11], [0, 1], cl);
  let shakeX = 0;
  let shakeY = 0;
  if (frame >= IMPACT && frame < IMPACT + 5) {
    const amp = 18 * Math.exp(-(frame - IMPACT) * 0.9);
    shakeX = amp * (h(frame * 7 + 1) * 2 - 1);
    shakeY = amp * (h(frame * 13 + 2) * 2 - 1);
  }
  const ringT = interpolate(frame, [IMPACT, IMPACT + 14], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const ringD = interpolate(ringT, [0, 1], [60, 1300]);
  const ringTLin = interpolate(frame, [IMPACT, IMPACT + 14], [0, 1], cl);
  const ringOp = interpolate(ringTLin, [0, 0.65, 1], [0.75, 0.55, 0]);
  const ringOn = frame >= IMPACT && frame < IMPACT + 14;
  const dustT = interpolate(frame, [IMPACT, IMPACT + 16], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const dustTLin = interpolate(frame, [IMPACT, IMPACT + 16], [0, 1], cl);
  const dustOn = frame >= IMPACT && frame < IMPACT + 16;
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, transform: `translate(${shakeX}px, ${shakeY}px)` }}>
        <div style={{ position: 'absolute', left: 0, top: 0, filter: 'blur(6px)', transform: 'scale(1.05)', transformOrigin: '50% 50%' }}>
          <FakeDashboardV variant="B" />
        </div>
        {dustOn &&
          Array.from({ length: 8 }).map((_, i) => {
            const ang = (i / 8) * Math.PI * 2 + (h(i + 3) - 0.5) * 0.7;
            const dist = 220 + h(i + 11) * 220;
            const size = 24 + h(i + 23) * 16;
            const dx = Math.cos(ang) * dist * dustT;
            const dy = Math.sin(ang) * dist * dustT + 120 * dustT * dustT;
            const s = size * (1 - 0.75 * dustTLin);
            return <div key={i} style={{ position: 'absolute', left: CX + dx - s / 2, top: CY + CARD_H / 2 - 24 + dy - s / 2, width: s, height: s, background: G.ink, opacity: interpolate(dustTLin, [0, 0.75, 1], [0.9, 0.7, 0]), borderRadius: 2 }} />;
          })}
        {ringOn && <div style={{ position: 'absolute', left: CX - ringD / 2, top: CY - ringD / 2, width: ringD, height: ringD, borderRadius: '50%', border: `8px solid ${G.ink}`, opacity: ringOp, boxSizing: 'border-box' }} />}
        {frame >= 8 && (
          <div style={{ position: 'absolute', left: CX - CARD_W / 2, top: CY - CARD_H / 2, width: CARD_W, height: CARD_H, background: G.card, border: `3px solid ${G.border}`, borderRadius: 24, boxShadow: '0 10px 30px rgba(0,0,0,0.18)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, opacity: cardOp, transform: `translateY(${slamY}px) rotate(${slamRot}deg) scale(${slamScale})` }}>
            <div style={{ fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 170, color: G.ink, letterSpacing: -4, lineHeight: 1 }}>+247%</div>
            <div style={{ fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 600, fontSize: 44, color: G.mid }}>Quarterly growth</div>
          </div>
        )}
      </div>
    </div>
  );
};
