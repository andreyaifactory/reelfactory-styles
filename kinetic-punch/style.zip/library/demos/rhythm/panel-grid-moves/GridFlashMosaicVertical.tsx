// grid-flash-mosaic · 竖版 9:16（1080×1920）。
// 保留：f25 起每 2f 一格硬入（顺序 h(i+1) 打乱）、入格 3f scale 1.18→1 + 2f 加深脉冲、填满后停 14f 微呼吸 1.008、中心格 14f in(cubic) 放大吞屏。
// 竖版：格子改竖长 328×583（= 竖版整页的缩小比例 0.3037），3×3 网格 1008×1773 居中；中心格内放整页 FakeDashboardV，
// 放大 3.29（加到 3.36 让描边滑出画外）正好成为满屏竖版页面。其他格是 FakeDashboardV 不同区域的裁切或灰卡。
// 以下为横版原注释：
// 浅底 → f25 起 3×3 网格按十六分音符(每 2f)逐格啪啪硬入，每格 = 页面不同区域裁切片或灰卡；
// 填满后停 14f(整墙微呼吸 1.008) → 中心格放大吞掉全屏成为满屏页面。收尾真静止 ≥40f。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G, Card } from '../../_fixtures/Fixtures';
import { FakeDashboardV } from '../../_fixtures/Vertical';

export const GRID_FLASH_MOSAIC_VERTICAL_DURATION = 115;
const h = (n: number) => {
  const s = Math.sin(n * 127.3) * 43758.5453;
  return s - Math.floor(s);
};
const CELL_W = 328;
const CELL_H = Math.round((1920 * CELL_W) / 1080); // 583
const GAP = 12;
const GRID_X = (1080 - (CELL_W * 3 + GAP * 2)) / 2;
const GRID_Y = (1920 - (CELL_H * 3 + GAP * 2)) / 2;
const FILL_START = 25;
const STEP = 2;
const ORDER = Array.from({ length: 9 }, (_, i) => i).sort((a, b) => h(a + 1) - h(b + 1));
const RANK: number[] = [];
ORDER.forEach((cell, k) => (RANK[cell] = k));
const LAST_IN = FILL_START + 8 * STEP + 3;
const HOLD_END = LAST_IN + 14;
const ZOOM_END = HOLD_END + 14;
const MINI_SCALE = CELL_W / 1080;
const ZOOM_SCALE = 3.36;
const CROPS: Array<{ x: number; y: number; v: 'A' | 'B' } | null> = [
  { x: -20, y: -150, v: 'A' },
  null,
  { x: -560, y: -420, v: 'B' },
  { x: -40, y: -900, v: 'B' },
  null,
  { x: -600, y: -1100, v: 'A' },
  { x: -260, y: -600, v: 'B' },
  null,
  { x: -520, y: -180, v: 'A' },
];
const CellContent: React.FC<{ i: number }> = ({ i }) => {
  if (i === 4)
    return (
      <div style={{ position: 'absolute', left: 0, top: 0, transform: `scale(${MINI_SCALE})`, transformOrigin: 'top left' }}>
        <FakeDashboardV variant="A" />
      </div>
    );
  const crop = CROPS[i];
  if (crop === null)
    return (
      <div style={{ width: '100%', height: '100%', background: G.panel, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Card w={250} h={330} seed={i * 3 + 2} />
      </div>
    );
  return (
    <div style={{ position: 'absolute', left: crop.x, top: crop.y }}>
      <FakeDashboardV variant={crop.v} />
    </div>
  );
};

export const GridFlashMosaicVertical: React.FC = () => {
  const f = useCurrentFrame();
  const breath = f >= LAST_IN && f < HOLD_END ? 1 + 0.008 * Math.sin((Math.PI * (f - LAST_IN)) / 14) : 1;
  const zoom = interpolate(f, [HOLD_END, ZOOM_END], [1, ZOOM_SCALE], { easing: Easing.in(Easing.cubic), extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, transform: `scale(${breath})`, transformOrigin: '540px 960px' }}>
        {Array.from({ length: 9 }).map((_, i) => {
          const start = FILL_START + RANK[i] * STEP;
          if (f < start) return null;
          const row = Math.floor(i / 3);
          const col = i % 3;
          const popScale = interpolate(f, [start, start + 3], [1.18, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
          const darken = interpolate(f, [start, start + 2], [0.45, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
          const isCenter = i === 4;
          return (
            <div key={i} style={{ position: 'absolute', left: GRID_X + col * (CELL_W + GAP), top: GRID_Y + row * (CELL_H + GAP), width: CELL_W, height: CELL_H, overflow: 'hidden', background: G.card, border: `3px solid ${G.ink}`, boxSizing: 'border-box', transform: `scale(${isCenter ? popScale * zoom : popScale})`, transformOrigin: 'center', zIndex: isCenter ? 10 : 1 }}>
              <CellContent i={i} />
              {darken > 0.001 && <div style={{ position: 'absolute', inset: 0, background: '#000', opacity: darken }} />}
            </div>
          );
        })}
      </div>
    </div>
  );
};
