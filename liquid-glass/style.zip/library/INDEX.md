# Библиотека приёмов пака «Жидкое стекло»

Всё нужное для повторения приёмов лежит здесь, интернет и репозиторий не нужны.

- `cards/<имя>.md` — описание приёма: идея, параметры, известные подводные камни. **Читать перед реализацией.** Карточка иногда описывает несколько вариантов приёма; в пак вошли только те, у которых есть файл в колонке «Сцена».
- `demos/<категория>/<имя>/<Сцена>Vertical.tsx` — эталонный код Remotion, кадр 1080×1920. Параметры в коде — проверенная настройка: адаптировать под материал можно, ухудшать параметры из разделов описания «Главное» и «Известные ловушки» нельзя.
- `demos/_fixtures`, `demos/_textures` — общие файлы, на которые ссылается код. Размеры кадра и вертикальная заглушка-приложение — `demos/_fixtures/Vertical.tsx`, правила раскладки — в его начале.
- `public/textures/live/` — картинки, которые код берёт через `staticFile()`. **Скопировать содержимое `library/public/` в `public/` своего Remotion-проекта.**

**npm-зависимости всех приёмов:** `react`, `remotion`

Описания приёмов — на русском. Комментарии в коде могут быть на китайском (оригинал библиотеки video-shotcraft); назначение каждого приёма в этом паке — в `../pack.json`. Код сцен нейтральный, серый: в ролике он перекрашивается в свет и стекло пака (`kit/kit.tsx`), заглушки меняются на материал ролика.

Раскладка рассчитана на безопасную зону Reels: текст в y 230…1440, справа внизу пусто. Если проект задаёт свою безопасную зону, действует она.

| Приём | Сцена (9:16) | Длина | Доп. зависимости | Суть |
|---|---|---|---|---|
| [blur-slide](cards/blur-slide.md) | `demos/typography/blur-slide/BlurSlideVertical.tsx` | 114f | — | Заголовок проступает по словам: подъём, размытие и прозрачность сходятся по одной кривой, шаг ~3.5f |
| [pill-slot-cycle](cards/pill-slot-cycle.md) | `demos/typography/pill-slot-cycle/PillSlotCycleVertical.tsx` | 175f | — | Основа фразы стоит, слово в пилюле в конце прокручивается барабаном каждые ~0.7 с |
| [vertical-word-roll-blur-cycle](cards/vertical-word-roll-blur-cycle.md) | `demos/typography/vertical-word-roll-blur-cycle/VerticalWordRollBlurCycleVertical.tsx` | 150f | — | Последнее слово фразы на вертикальном барабане в тумане: три смены по 0.55 с |
| [gradient-word-sweep](cards/gradient-word-sweep.md) | `demos/typography/gradient-word-sweep/GradientWordSweepVertical.tsx` | 105f | — | Ключевое слово «заряжается»: по нему пробегает волна перелива |
| [type-rhythm-sync](cards/type-rhythm-sync.md) | `demos/typography/type-rhythm-sync/KaraokeFillSyncVertical.tsx` (karaoke-fill-sync) | 150f | — | Слова загораются ровно в момент, когда звучат |
| [lead-word-zoom-assemble](cards/lead-word-zoom-assemble.md) | `demos/typography/lead-word-zoom-assemble/LeadWordZoomAssembleVertical.tsx` | 84f | — | Первое слово крупно в центре, затем одна кривая собирает фразу вокруг него |
| [type-assembly-moves](cards/type-assembly-moves.md) | `demos/typography/type-assembly-moves/TrackingExpandRevealVertical.tsx` (tracking-expand) | 130f | — | Слово проступает из широкой разрядки, буквы сходятся |
| [aurora-bloom-bg-flip](cards/aurora-bloom-bg-flip.md) | `demos/effects/aurora-bloom-bg-flip/AuroraBloomBgFlipVertical.tsx` | 156f | — | Свет поднимается снизу, затем фон проваливается в ночь, пятна сжимаются и переливаются |
| [light-play-moves](cards/light-play-moves.md) | `demos/effects/light-play-moves/SheenSweepRetryVertical.tsx` (sheen-sweep) | 110f | — | Одиночный блик пробегает по стеклянной карточке |
| [light-play-moves](cards/light-play-moves.md) | `demos/effects/light-play-moves/HalationBloomVertical.tsx` (halation-bloom) | 145f | — | Ореол в кадре остановки: свет растекается и гаснет |
| [letterspace-materialize](cards/letterspace-materialize.md) | `demos/opening/letterspace-materialize/LetterspaceMaterializeVertical.tsx` | 110f | — | Знак с широкой разрядкой проступает штрихами и схлопывается в чистый |
| [text-as-mask](cards/text-as-mask.md) | `demos/opening/text-as-mask/TextAsMaskVertical.tsx` | 150f | — | Видео внутри толстых букв; в конце буквы растут и открывают кадр целиком |
| [floating-glossy-label-pills](cards/floating-glossy-label-pills.md) | `demos/ui-entrance/floating-glossy-label-pills/FloatingGlossyLabelPillsVertical.tsx` | 120f | — | Панели интерфейса с глянцевыми пилюлями-ярлыками плывут лентой |
| [glass-pill-dictation-typing](cards/glass-pill-dictation-typing.md) | `demos/interaction/glass-pill-dictation-typing/GlassPillDictationTypingVertical.tsx` | 50f | — | Стеклянная строка ввода выскакивает и мягко садится, внутри набирается запрос |
| [voice-waveform-live](cards/voice-waveform-live.md) | `demos/interaction/voice-waveform-live/VoiceWaveformLiveVertical.tsx` | 150f | — | Живая волна голоса в капсуле записи: полоски растут на речи, на паузе сжимаются в пунктир |
| [morph-from-primitive](cards/morph-from-primitive.md) | `demos/ui-entrance/morph-from-primitive/MorphFromPrimitiveVertical.tsx` | 140f | — | Круг делает вдох и перетекает в контур карточки, содержимое проступает |
| [svg-shape-morph](cards/svg-shape-morph.md) | `demos/ui-entrance/svg-shape-morph/SvgShapeMorphVertical.tsx` | 156f | — | Замкнутая жидкая форма плавно перетекает в другую и обратно |
| [element-body-moves](cards/element-body-moves.md) | `demos/ui-entrance/element-body-moves/ContactShadowLiftVertical.tsx` (contact-shadow-lift) | 160f | — | Плашка отрывается от стекла: тень расходится, элемент приподнимается |
| [trailer-grammar-moves](cards/trailer-grammar-moves.md) | `demos/rhythm/trailer-grammar-moves/CardFootageCadenceVertical.tsx` (card-footage-cadence) | 150f | — | Карточки-реплики вперемешку с кадрами, в ритм |
| [speed-ramp-freeze](cards/speed-ramp-freeze.md) | `demos/rhythm/speed-ramp-freeze/FreezeAnnotateRealVertical.tsx` (freeze-annotate) | 135f | — | Стоп-кадр с пометкой: движение замирает, нужное подписывается |
| [tension-camera-moves](cards/tension-camera-moves.md) | `demos/camera/tension-camera-moves/SlowPushInVertical.tsx` (slow-push-in) | 150f | — | Медленный наезд к главному |
| [tension-camera-moves](cards/tension-camera-moves.md) | `demos/camera/tension-camera-moves/PullBackIsolationVertical.tsx` (pull-back-isolation) | 150f | — | Отъезд в тишину: герой остаётся один в кадре |
| [depth-layer-moves](cards/depth-layer-moves.md) | `demos/camera/depth-layer-moves/MultiplaneRealVertical.tsx` (multiplane) | 135f | — | Три слоя с разной скоростью дают объём |
| [odometer-digit-roll](cards/odometer-digit-roll.md) | `demos/data/odometer-digit-roll/OdometerDigitRollVertical.tsx` | 150f | — | Огромное число: каждый разряд крутится барабаном отдельно |
| [before-after-slider-scrub](cards/before-after-slider-scrub.md) | `demos/data/before-after-slider-scrub/BeforeAfterSliderScrubVertical.tsx` | 150f | — | Шторка «до / после»: граница отлетает и возвращается, проявляя «после» |
| [bubble-swarm-takeover](cards/bubble-swarm-takeover.md) | `demos/transition/bubble-swarm-takeover/BubbleSwarmTakeoverVertical.tsx` | 130f | — | Переход-занавес: перламутровые пузыри вплывают, растут и закрывают кадр |
| [shot-transitions](cards/shot-transitions.md) | `demos/transition/shot-transitions/FocusHandoffTransitionVertical.tsx` (shot-transitions-5) | 120f | — | Перевод фокуса: резкость переходит с одного кадра на другой |
| [shot-transitions](cards/shot-transitions.md) | `demos/transition/shot-transitions/MaskWipeRealVertical.tsx` (mask-wipe) | 120f | — | Окно в стекле: маска раскрывает следующий кадр |
| [transition-travel](cards/transition-travel.md) | `demos/transition/transition-travel/SharedElementMorphVertical.tsx` (shared-element-morph) | 130f | — | Общий элемент перелетает и встаёт на место в новом кадре |
| [white-flash-logo-simplify-cut](cards/white-flash-logo-simplify-cut.md) | `demos/transition/white-flash-logo-simplify-cut/WhiteFlashLogoSimplifyCutVertical.tsx` | 108f | — | Жидкий переливающийся знак засвечивается в белое, проявляется чистая плоская версия |
