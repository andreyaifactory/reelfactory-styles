// Время «Удара»: 30 fps, всё живёт рывками. Движение = смена состояний за 2–4 кадра,
// между ними стоп. Плавных «полётов» нет — есть удар, отдача и тишина до следующей доли.
export const FPS = 30;
export const sf = (sec: number) => Math.round(sec * FPS);

export const lerp = (t: number, a: number, b: number) => a + (b - a) * t;
export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
export const seg = (f: number, f0: number, f1: number, ease: (x: number) => number = (x) => x) =>
  ease(clamp01((f - f0) / Math.max(1e-6, f1 - f0)));

export const E = {
  linear: (t: number) => t,
  outExpo: (t: number) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),
  inExpo: (t: number) => (t <= 0 ? 0 : Math.pow(2, 10 * t - 10)),
  outCubic: (t: number) => 1 - Math.pow(1 - t, 3),
  inCubic: (t: number) => t * t * t,
  // «врезка»: проскок за цель и жёсткий возврат
  outBack: (t: number) => {
    const c = 2.2;
    return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2);
  },
};

/** Импульс удара: 1 в кадр `at`, экспоненциально гаснет за `len` кадров; до `at` — 0. */
export const kick = (f: number, at: number, len = 8) => (f < at ? 0 : Math.exp((-(f - at) * 4.5) / len) * (f - at <= len * 1.5 ? 1 : 0));

/** Сумма импульсов по списку долей (для камеры, вспышек, пульса). */
export const kicks = (f: number, hits: number[], len = 8) => hits.reduce((a, h) => Math.max(a, kick(f, h, len)), 0);

/** Квантование времени: анимация «через N» (на двойках/тройках) — фирменная ступенька стиля. */
export const stepF = (f: number, n = 2) => Math.floor(f / n) * n;

/** Детерминированный шум 0..1 */
export const rnd = (seed: number) => {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

/**
 * Сетка долей трека. t0 — кадр опорной доли (дроп), T — кадров на долю.
 * b(k) — кадр k-й доли относительно опорной (k может быть дробным: 0.5 — восьмая).
 */
export const grid = (t0: number, T: number) => (k: number) => Math.round(t0 + k * T);

// g-eazy-nba-type.mp3 (Arulo, Mixkit): 86.6 BPM, опорная доля дропа на 14.876 с трека.
export const GZY = { bpm: 86.6, dropSec: 14.876, T: (60 / 86.6) * FPS };
