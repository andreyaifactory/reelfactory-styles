import React from 'react';
import { AbsoluteFill } from 'remotion';
import type { TransitionSpec } from '../../../core/transitions';
import type { StyleSeamProps } from '../../../core/style-contract';
import { C, E, lerp, seg } from '../kit/kit';

/**
 * Склейки «Удара» для ядра фабрики.
 *
 * В ките пака переход видит оба кадра сразу. В фабрике блоки не накладываются:
 * уход живёт в последних кадрах старого блока, приход — в первых кадрах нового.
 * Поэтому каждая склейка здесь — один удар, разрезанный по стыку: к последнему
 * кадру ухода старый кадр закрыт целиком (плитой, полосами, белым, блоком), с
 * первого кадра прихода покрытие уходит и открывает новый. Всё — за 2–6 кадров,
 * без растворения и размытия «для мягкости».
 */

const W = 1080;
const H = 1920;
const CX = 540;
const CY = 835;

/** Длины ухода в кадрах — одни и те же для рисунка и для описания склейки. */
const OUT = { smash: 4, shutter: 5, flash: 2, invert: 3, punch: 5, block: 6 } as const;

/**
 * Ядро ведёт уход от t = 0 до t = 1 − 1/n: последний кадр ухода ещё не единица.
 * Растягиваем ход так, чтобы на этом кадре старый кадр был закрыт целиком.
 */
const closing = (t: number, n: number) => Math.min(1, (t * n) / Math.max(1, n - 1));

/**
 * Плита: косой лаймовый блок влетает слева и накрывает кадр, на стыке под ним
 * уже новый, блок вылетает вправо. Одно движение на два блока.
 */
const SmashSeam: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  // −1 — блок за левым краем, 0 — кадр закрыт целиком, 1 — за правым.
  const x = phase === 'out' ? lerp(E.inCubic(closing(t, OUT.smash)), -1, 0) : lerp(E.outExpo(t), 0, 1);
  return (
    <>
      {children}
      <AbsoluteFill style={{ pointerEvents: 'none' }}>
        <div
          style={{
            position: 'absolute',
            left: -1100,
            top: -600,
            width: 3300,
            height: 3100,
            background: C.lime,
            transform: `rotate(-18deg) translateX(${x * 3400}px)`,
          }}
        />
      </AbsoluteFill>
    </>
  );
};

/**
 * Жалюзи: восемь чёрных полос захлопываются через полкадра каждая и закрывают
 * кадр; на приходе раскрываются в другую сторону.
 */
const ShutterSeam: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  const n = 8;
  const u = phase === 'out' ? closing(t, OUT.shutter) : t;
  return (
    <>
      {children}
      <AbsoluteFill style={{ pointerEvents: 'none' }}>
        {Array.from({ length: n }, (_, i) => {
          // Каждая полоса стартует чуть позже соседки, но к концу фазы закрыта/открыта вся.
          const d = (i / n) * 0.4;
          const k = seg(u, d, d + 0.6, phase === 'out' ? E.outExpo : E.inExpo);
          const sx = phase === 'out' ? k : 1 - k;
          const origin = phase === 'out' ? (i % 2 ? '100% 50%' : '0% 50%') : i % 2 ? '0% 50%' : '100% 50%';
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: 0,
                width: W,
                top: (H / n) * i,
                height: H / n + 1,
                background: C.black,
                transform: `scaleX(${sx})`,
                transformOrigin: origin,
              }}
            />
          );
        })}
      </AbsoluteFill>
    </>
  );
};

/** Вспышка: последний кадр ухода и первый прихода — белые. Склейка-выстрел. */
const FlashSeam: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  const white = phase === 'out' ? closing(t, OUT.flash) >= 1 : t < 0.5;
  return (
    <>
      {children}
      {white && <AbsoluteFill style={{ background: C.white, pointerEvents: 'none' }} />}
    </>
  );
};

/**
 * Инверсия: два кадра на стыке выбиваются в негатив, на пике — белым листом.
 * Резче вспышки, ставится на «сбой», «наоборот», «стоп».
 */
const InvertSeam: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  const edge = phase === 'out' ? closing(t, OUT.invert) >= 1 : t < 0.34;
  return (
    <>
      <AbsoluteFill style={{ filter: 'invert(1)' }}>{children}</AbsoluteFill>
      {edge && <AbsoluteFill style={{ background: C.white, pointerEvents: 'none' }} />}
    </>
  );
};

/**
 * Удар насквозь: старый кадр влетает в камеру через центр и тонет в чёрном,
 * новый выбивается из глубины — 0.55 → 1.05 → 1 — с проскоком.
 */
const PunchThroughSeam: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  if (phase === 'out') {
    const u = closing(t, OUT.punch);
    const s = lerp(E.inExpo(u), 1, 9);
    return (
      <>
        <AbsoluteFill style={{ transform: `scale(${s})`, transformOrigin: `${CX}px ${CY}px` }}>{children}</AbsoluteFill>
        <AbsoluteFill style={{ background: C.black, opacity: seg(u, 0.5, 1), pointerEvents: 'none' }} />
      </>
    );
  }
  const s = t < 0.45 ? lerp(seg(t, 0, 0.45, E.outExpo), 0.55, 1.05) : lerp(seg(t, 0.45, 1, E.outCubic), 1.05, 1);
  return (
    <>
      <AbsoluteFill style={{ background: C.black }} />
      <AbsoluteFill style={{ transform: `scale(${s})`, transformOrigin: `${CX}px ${CY}px`, overflow: 'hidden' }}>{children}</AbsoluteFill>
    </>
  );
};

/**
 * Цветной блок ступеньками: синяя полоса в центре за четыре жёстких скачка
 * разрастается на весь кадр; на приходе блок так же ступеньками сходится в
 * полосу и пропадает.
 */
const BlockSeam: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  const steps = [0.06, 0.24, 0.55, 1];
  const i = Math.min(steps.length - 1, Math.floor((phase === 'out' ? closing(t, OUT.block) : t) * steps.length));
  const h = phase === 'out' ? steps[i] : steps[steps.length - 1 - i] * (t >= 0.999 ? 0 : 1);
  return (
    <>
      {children}
      {h > 0 && (
        <div style={{ position: 'absolute', left: 0, width: W, top: CY - (H * 1.2 * h) / 2, height: H * 1.2 * h, background: C.blue, pointerEvents: 'none' }} />
      )}
    </>
  );
};

export const transitions: Record<string, TransitionSpec> = {
  smash: {
    what: 'косая лаймовая плита влетает, накрывает кадр и вылетает, под ней новый',
    character: 'move',
    enter: 5,
    exit: OUT.smash,
    render: SmashSeam,
  },
  shutter: {
    what: 'чёрные полосы-жалюзи захлопываются и раскрываются уже на новом кадре',
    character: 'close',
    enter: 6,
    exit: OUT.shutter,
    render: ShutterSeam,
    sound: 'swipe',
  },
  flash: {
    what: 'кадр белой вспышки на стыке',
    character: 'move',
    enter: 2,
    exit: OUT.flash,
    render: FlashSeam,
    sound: 'snap',
  },
  invert: {
    what: 'стык выбивается в негатив, на пике белый кадр',
    character: 'move',
    enter: 3,
    exit: OUT.invert,
    render: InvertSeam,
    sound: 'snap',
  },
  'punch-through': {
    what: 'старый кадр влетает в камеру, новый выбивается из глубины с проскоком',
    character: 'open',
    enter: 7,
    exit: OUT.punch,
    render: PunchThroughSeam,
    sound: 'rise',
  },
  block: {
    what: 'синий блок ступеньками разрастается на весь кадр и ступеньками сходится',
    character: 'move',
    enter: 5,
    exit: OUT.block,
    render: BlockSeam,
  },
};

/**
 * Очередь «сам подбери»: только удары пака. Растворений, наплывов и смазов
 * здесь нет — в этом мире ничего не тает. Один переход подряд не повторяется:
 * очередь идёт по кругу.
 */
export const autoTransitions = ['smash', 'shutter', 'flash', 'block', 'punch-through', 'invert'];
