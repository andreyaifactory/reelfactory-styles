// logo-sting-button · 竖版 9:16（1080×1920）：收黑 / 黑场 6f / LOGO 入场 10f / 定住 30f / 彩蛋 12f / 定格 60f 同横版（142f）。
// 竖版：LOGO 改上下堆叠（方标在上、字在下）对准安全区中心；彩蛋特写换竖版假 App 的卡底按钮行；
// 彩蛋 tick 点从右下（平台按钮区）挪到安全区左下。
// 以下为横版原注释：
// logo-sting-button —— 收尾按钮镜头（button ending）
// 上一镜收黑 → 黑场 → LOGO 入场定住（观众以为结束）→ 12f UI 特写彩蛋硬切 →
// 硬切回黑底 LOGO 定格。节奏是全部：彩蛋段短促像眨眼。收尾真静止 ≥40f。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { FakeDashboardV, SafeCenter, SAFE, SAFE_CY } from '../../_fixtures/Vertical';

export const LOGO_STING_BUTTON_VERTICAL_DURATION = 142;

// 时间轴（30fps，共 142f）
const T = {
  shotAEnd: 24,     // 0–24f 上一镜（B），f14–24 压暗到纯黑
  darkenStart: 14,
  blackEnd: 30,     // 24–30f 黑场 6f
  logoInEnd: 40,    // 30–40f LOGO 入场 10f
  holdEnd: 70,      // 40–70f 定住 30f（观众以为结束）
  eggEnd: 82,       // 70–82f 彩蛋硬切 12f
  total: 142,       // 82–142f 黑底 LOGO 真静止 60f
};

const LogoLockup: React.FC<{ opacity: number; scale: number }> = ({ opacity, scale }) => (
  <div style={{ width: 1080, height: 1920, background: '#000', position: 'relative' }}>
   <SafeCenter>
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40,
      opacity, transform: `scale(${scale})`,
    }}>
      <div style={{
        width: 170, height: 170, borderRadius: 40, background: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {/* 方块内一个黑色小标记，避免纯白块太空 */}
        <div style={{ width: 62, height: 62, borderRadius: 17, background: '#000' }} />
      </div>
      <div style={{
        fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800,
        fontSize: 130, color: '#fff', letterSpacing: 3,
      }}>
        ACME
      </div>
    </div>
   </SafeCenter>
  </div>
);

export const LogoStingButtonVertical: React.FC = () => {
  const frame = useCurrentFrame();

  // —— 段 1：上一镜（FakeDashboard B）压暗收黑 ——
  if (frame < T.shotAEnd) {
    const dark = interpolate(frame, [T.darkenStart, T.shotAEnd - 1], [0, 1], {
      extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
      easing: Easing.in(Easing.cubic),
    });
    return (
      <div style={{ width: 1080, height: 1920, background: '#000', position: 'relative', overflow: 'hidden' }}>
        <FakeDashboardV variant="B" />
        <div style={{ position: 'absolute', inset: 0, background: '#000', opacity: dark }} />
      </div>
    );
  }

  // —— 段 2：黑场 6f ——
  if (frame < T.blackEnd) {
    return <div style={{ width: 1080, height: 1920, background: '#000' }} />;
  }

  // —— 段 4：彩蛋硬切 12f（variant A 按钮区 2.4x 裁切 + 角落小圆点 tick 闪 2f）——
  if (frame >= T.holdEnd && frame < T.eggEnd) {
    const egg = frame - T.holdEnd; // 0..11
    // tick 圆点：第 4–5f 亮 2f，像眨眼
    const tickOn = egg >= 4 && egg < 6;
    return (
      <div style={{ width: 1080, height: 1920, background: '#ececea', position: 'relative', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', inset: 0,
          // 2.4x 放大：把第 1 张卡片底部"按钮行"（头像圆+文字条）平移到画面中心
          // 原坐标 (839, 531)（第 2 列卡片底部头像圆+文字条）→ 屏幕中心 (960, 540)
          // 选中列卡片可把左侧深色 sidebar 完全推出画面，特写更纯粹
          // 竖版：右列首张卡底部头像圆+文字条 (585, 659) → 安全区中心 (540, 835)
          transform: `translate(${540 - 585 * 2.4}px, ${SAFE_CY - 659 * 2.4}px) scale(2.4)`, transformOrigin: '0 0',
        }}>
          <FakeDashboardV variant="A" />
        </div>
        {tickOn && (
          <div style={{
            position: 'absolute', left: 80, top: SAFE.bottom - 120,
            width: 72, height: 72, borderRadius: 36, background: '#2f2f2f',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <div style={{ width: 20, height: 20, borderRadius: 10, background: '#fff' }} />
          </div>
        )}
      </div>
    );
  }

  // —— 段 3 + 段 5：黑底 LOGO（入场 → 定住 → 彩蛋后定格收尾，真静止）——
  const opacity = interpolate(frame, [T.blackEnd, T.logoInEnd], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const scale = interpolate(frame, [T.blackEnd, T.logoInEnd], [0.96, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  return <LogoLockup opacity={opacity} scale={scale} />;
};
