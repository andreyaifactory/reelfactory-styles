import React from 'react';
import type { StyleCaptionProps } from '../../../core/style-contract';
import { SUBS_LOOK } from '../kit/kit';

/**
 * Субтитры стиля «Слои»: тонкий светлый Montserrat, мелко, без плашки, мягкая
 * тень. Страница встаёт целиком, как сказана, без набора по буквам. Место и
 * размер полосы даёт ядро — она стоит в нижнем резерве по замыслу, поэтому
 * проверка безопасной зоны её не меряет (`data-safezone="free"`).
 */
export const Caption: React.FC<StyleCaptionProps> = ({ page, box }) => (
  <div data-safezone="free" style={{ width: box.width, textAlign: 'center', fontSize: box.fontSize, lineHeight: 1.2, ...SUBS_LOOK }}>
    {page.words.map((w) => w.text.replace(/[.,]$/, '')).join(' ')}
  </div>
);
