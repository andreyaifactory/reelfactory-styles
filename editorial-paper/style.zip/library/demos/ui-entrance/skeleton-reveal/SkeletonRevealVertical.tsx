// skeleton-reveal · 竖版 9:16（1080×1920）：三级显影的全部节拍同横版（涂鸦煮沸 5f → SWAP 32 → 行滚入 6f 错峰 →
// 逐行显影 13f 错峰 / 逐词 2.5f，末词晚 14f，160f）。
// 竖版：桌面聊天窗换成手机聊天屏（无侧栏，860×1150，落在安全区内），涂鸦占位按同一屏重画；
// 字号放大到 34/36，消息自动折行；推近幅度收为 1→1.12，保证推近后字不出安全区。
// 以下为横版原注释：
// skeleton-reveal —— slack-promo 4–15s 合并
// 三级显影：全屏手绘粗笔触涂鸦占位（圆头 blob 线稿，煮沸抖动）→ 一拍内被
// 灰条骨架 UI 窗口替换 → 骨架消息列表滚入，镜头推近时灰条逐行"显影"成
// 头像+文字内容（最后一行末词晚半拍到）。
import React from 'react';
import {
  AbsoluteFill,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  spring,
  Easing,
} from 'remotion';

const mulberry32 = (a: number) => () => {
  let t = (a += 0x6d2b79f5);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const INK = '#2f2f2f';
const PAPER = '#f2f0ea';

// ——— 手绘涂鸦工具：把折线/圆加种子抖动，画粗圆头 stroke ———
const wobbleLine = (
  x1: number, y1: number, x2: number, y2: number,
  seed: number, amp = 7, segs = 8,
) => {
  const rnd = mulberry32(seed);
  const pts: string[] = [];
  for (let i = 0; i <= segs; i++) {
    const t = i / segs;
    const jx = (rnd() - 0.5) * amp * 2;
    const jy = (rnd() - 0.5) * amp * 2;
    pts.push(`${i === 0 ? 'M' : 'L'} ${x1 + (x2 - x1) * t + jx} ${y1 + (y2 - y1) * t + jy}`);
  }
  return pts.join(' ');
};

const wobbleBlobRect = (
  x: number, y: number, w: number, h: number,
  seed: number, amp = 10, r = 70,
) => {
  // 圆头 blob 矩形：四条边中段抖动，四角大圆弧
  const rnd = mulberry32(seed);
  const j = () => (rnd() - 0.5) * amp * 2;
  return [
    `M ${x + r + j()} ${y + j()}`,
    `L ${x + w / 2 + j()} ${y + j()}`, `L ${x + w - r + j()} ${y + j()}`,
    `Q ${x + w + j()} ${y + j()} ${x + w + j()} ${y + r + j()}`,
    `L ${x + w + j()} ${y + h / 2 + j()}`, `L ${x + w + j()} ${y + h - r + j()}`,
    `Q ${x + w + j()} ${y + h + j()} ${x + w - r + j()} ${y + h + j()}`,
    `L ${x + w / 2 + j()} ${y + h + j()}`, `L ${x + r + j()} ${y + h + j()}`,
    `Q ${x + j()} ${y + h + j()} ${x + j()} ${y + h - r + j()}`,
    `L ${x + j()} ${y + h / 2 + j()}`, `L ${x + j()} ${y + r + j()}`,
    `Q ${x + j()} ${y + j()} ${x + r + j()} ${y + j()}`,
  ].join(' ');
};

const wobbleCircle = (cx: number, cy: number, r: number, seed: number, amp = 6) => {
  const rnd = mulberry32(seed);
  const n = 14;
  const pts: string[] = [];
  for (let i = 0; i <= n; i++) {
    const a = (i / n) * Math.PI * 2;
    const rr = r + (rnd() - 0.5) * amp * 2;
    pts.push(`${i === 0 ? 'M' : 'L'} ${cx + Math.cos(a) * rr} ${cy + Math.sin(a) * rr}`);
  }
  return pts.join(' ') + ' Z';
};

const Doodle: React.FC<{ boil: number }> = ({ boil }) => {
  const S = boil * 977; // 每次煮沸换一套抖动种子
  const stroke = {
    fill: 'none' as const,
    stroke: INK,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
  };
  return (
    <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0 }}>
      {/* 手机屏大 blob */}
      <path d={wobbleBlobRect(WX, WY, WW, WH, S + 1)} {...stroke} strokeWidth={14} />
      {/* 顶栏分隔 + 标题短线 */}
      <path d={wobbleLine(WX + 20, WY + 150, WX + WW - 20, WY + 150, S + 2)} {...stroke} strokeWidth={12} />
      <path d={wobbleCircle(WX + 90, WY + 76, 40, S + 3)} {...stroke} strokeWidth={12} />
      <path d={wobbleLine(WX + 160, WY + 76, WX + 440, WY + 76, S + 4)} {...stroke} strokeWidth={11} />
      {/* 消息行：圆头像 blob + 波浪文字线 */}
      {Array.from({ length: 4 }).map((_, i) => {
        const y = WY + 270 + i * 225;
        return (
          <g key={`row${i}`}>
            <path d={wobbleCircle(WX + 100, y, 48, S + 30 + i)} {...stroke} strokeWidth={12} />
            <path d={wobbleLine(WX + 180, y - 32, WX + 430 + ((i * 97) % 160), y - 32, S + 40 + i)} {...stroke} strokeWidth={11} />
            <path d={wobbleLine(WX + 180, y + 24, WX + WW - 60 - ((i * 71) % 200), y + 24, S + 50 + i)} {...stroke} strokeWidth={11} />
            <path d={wobbleLine(WX + 180, y + 72, WX + 520 - ((i * 53) % 140), y + 72, S + 60 + i)} {...stroke} strokeWidth={11} />
          </g>
        );
      })}
    </svg>
  );
};

// ——— 骨架/内容消息行 ———
const NAMES = ['Ana', 'Ben', 'Kai', 'Mia'];
const AVA = ['#5a5a58', '#7a7a78', '#4a4a48', '#8f8f8d'];
const MSGS = [
  'Morning! Kicking off the rebrand today',
  'Logo drafts are ready for review',
  'Nice — shipping the deck this afternoon',
  'Love it. Can we make it pink?',
];

const Row: React.FC<{ i: number; dev: number; wordAt: (w: number, n: number) => number }> = ({
  i, dev, wordAt,
}) => {
  const words = MSGS[i].split(' ');
  return (
    <div style={{ position: 'relative', height: 186 }}>
      {/* 骨架层 */}
      <div style={{ position: 'absolute', inset: 0, display: 'flex', gap: 22, opacity: 1 - dev }}>
        <div style={{ width: 96, height: 96, borderRadius: 22, background: '#d5d5d3', flexShrink: 0 }} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 20, paddingTop: 8 }}>
          <div style={{ height: 26, width: 200 + ((i * 67) % 90), background: '#d5d5d3', borderRadius: 13 }} />
          <div style={{ height: 22, width: `${80 + ((i * 31) % 15)}%`, background: '#e2e2e0', borderRadius: 11 }} />
          <div style={{ height: 22, width: `${40 + ((i * 23) % 25)}%`, background: '#e2e2e0', borderRadius: 11 }} />
        </div>
      </div>
      {/* 内容层（逐词显影） */}
      <div style={{ position: 'absolute', inset: 0, display: 'flex', gap: 22, opacity: dev > 0.02 ? 1 : 0 }}>
        <div
          style={{
            width: 96, height: 96, borderRadius: 22, background: AVA[i], flexShrink: 0,
            color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 44, fontWeight: 800, opacity: dev,
            transform: `scale(${0.7 + 0.3 * dev})`,
          }}
        >
          {NAMES[i][0]}
        </div>
        <div style={{ flex: 1, paddingTop: 2 }}>
          <div style={{ fontSize: 34, fontWeight: 800, color: INK, opacity: dev }}>
            {NAMES[i]}
            <span style={{ fontWeight: 400, fontSize: 26, color: '#9a9a98', marginLeft: 14 }}>9:0{i + 1} AM</span>
          </div>
          <div style={{ fontSize: 36, lineHeight: 1.3, color: '#3c3c3a', marginTop: 10 }}>
            {words.map((w, wi) => {
              const p = wordAt(wi, words.length);
              return (
                <span
                  key={wi}
                  style={{
                    display: 'inline-block',
                    marginRight: 11,
                    opacity: p,
                    transform: `translateY(${(1 - p) * 14}px)`,
                  }}
                >
                  {w}
                </span>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export const SKELETON_REVEAL_VERTICAL_DURATION = 160;

// 手机屏几何（安全区内）
const WX = 110;
const WY = 250;
const WW = 860;
const WH = 1150;

export const SkeletonRevealVertical: React.FC = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();

  const SWAP = 32; // 涂鸦 → 骨架的那一拍

  // 涂鸦：煮沸抖动 + 一拍内被拉回替换（快速缩退 + 淡出，加速离场）
  const boil = Math.floor(f / 5);
  const doodleOut = interpolate(f, [SWAP, SWAP + 8], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
    easing: Easing.in(Easing.cubic),
  });
  const doodleVisible = f < SWAP + 9;

  // 骨架窗口：swap 时弹入
  const winIn = spring({ frame: f - SWAP, fps, config: { damping: 16, stiffness: 160, mass: 0.7 } });

  // 骨架列表滚入（第二拍）
  const rowSlide = (i: number) =>
    interpolate(f, [SWAP + 12 + i * 6, SWAP + 34 + i * 6], [520, 0], {
      extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
      easing: Easing.out(Easing.cubic),
    });

  // 镜头推近
  const zoom = interpolate(f, [66, 142], [1, 1.12], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });

  // 逐行显影
  const devAt = (i: number) =>
    interpolate(f, [80 + i * 13, 92 + i * 13], [0, 1], {
      extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
      easing: Easing.out(Easing.quad),
    });

  // 逐词进场；最后一行最后一个词晚半拍（+14 帧）
  const wordAt = (row: number) => (w: number, n: number) => {
    const isLastWordOfLastRow = row === 3 && w === n - 1;
    const start = 82 + row * 13 + w * 2.5 + (isLastWordOfLastRow ? 14 : 0);
    return interpolate(f, [start, start + 9], [0, 1], {
      extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
      easing: Easing.out(Easing.cubic),
    });
  };

  return (
    <AbsoluteFill style={{ background: PAPER, fontFamily: 'Helvetica, Arial, sans-serif', overflow: 'hidden' }}>
      {/* 第三/二拍：骨架 UI 窗口 */}
      {f >= SWAP && (
        <AbsoluteFill
          style={{
            transform: `scale(${zoom})`,
            transformOrigin: '50% 50%',
          }}
        >
          <div
            style={{
              position: 'absolute', left: WX, top: WY, width: WW, height: WH,
              background: '#ffffff', border: '2px solid #d8d8d6', borderRadius: 40,
              overflow: 'hidden', display: 'flex', flexDirection: 'column',
              boxShadow: '0 12px 40px rgba(0,0,0,0.10)',
              opacity: Math.min(1, winIn * 2),
              transform: `scale(${interpolate(winIn, [0, 1], [1.08, 1])})`,
            }}
          >
            {/* 顶栏 */}
            <div style={{ height: 150, borderBottom: '2px solid #e4e4e2', display: 'flex', alignItems: 'center', gap: 24, padding: '0 50px', flexShrink: 0 }}>
              <div style={{ width: 80, height: 80, borderRadius: 40, background: '#3a3a3a' }} />
              <div style={{ height: 26, width: 280, background: '#d5d5d3', borderRadius: 13 }} />
            </div>
            {/* 消息区 */}
            <div style={{ flex: 1, padding: '40px 50px', display: 'flex', flexDirection: 'column', gap: 36, overflow: 'hidden' }}>
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} style={{ transform: `translateY(${rowSlide(i)}px)`, opacity: rowSlide(i) > 500 ? 0 : 1 }}>
                  <Row i={i} dev={devAt(i)} wordAt={wordAt(i)} />
                </div>
              ))}
            </div>
          </div>
        </AbsoluteFill>
      )}

      {/* 第一拍：手绘涂鸦占位（在骨架之上，一拍内缩退让位） */}
      {doodleVisible && (
        <AbsoluteFill
          style={{
            background: PAPER,
            opacity: 1 - doodleOut,
            transform: `scale(${1 - doodleOut * 0.14})`,
            transformOrigin: '50% 50%',
          }}
        >
          <Doodle boil={boil} />
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};
