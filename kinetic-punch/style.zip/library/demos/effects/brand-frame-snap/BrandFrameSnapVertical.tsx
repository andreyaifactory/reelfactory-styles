// brand-frame-snap · 竖版 9:16（1080×1920）。
// 保留：画框厚度 0→44 前 18f ease-out、窗口帧 14 起 spring（damping 16 / stiffness 110）从下方落位、帧 78 整圈蓝→绿同帧硬翻色 + 窗内布局 A→B、
// 2f 白闪脉冲与画框厚度阻尼弹跳。
// 竖版：窗口 1560×830 → 900×1240，窗心对准安全区中心；窗内为 FakeDashboardV（缩 0.833）；落位起点 y +560 → +900。
// 画框带上的模式角标（宽字距大写，且在 y<230 的平台遮挡区）删除，模式只在窗口标题栏徽标里显示，改常规大小写 "Design" / "Dev mode"。
// 以下为横版原注释：
// 一圈粗品牌色画框先于内容出现包住全屏 → 灰阶"录屏窗口"在框内落位 → 停一拍 → 画框整圈蓝→绿同帧硬翻色，窗口内容同帧换布局。
// 一个 borderColor 完成章节导航/状态提示/品牌露出。
import React from 'react';
import { useCurrentFrame, spring, interpolate } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const BRAND_FRAME_SNAP_VERTICAL_DURATION = 130;
const FIGMA_BLUE = '#3E7BFA';
const DEV_GREEN = '#1BC47D';
const FLIP_FRAME = 78;
const clamp01 = (t: number) => Math.min(1, Math.max(0, t));
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
const WIN_W = 900;
const WIN_H = 1240;

export const BrandFrameSnapVertical: React.FC = () => {
  const f = useCurrentFrame();
  const mode = f < FLIP_FRAME ? 'design' : 'dev';
  const frameColor = mode === 'design' ? FIGMA_BLUE : DEV_GREEN;
  const frameW = 44 * easeOut(clamp01(f / 18));
  const drop = spring({ frame: f - 14, fps: 30, config: { damping: 16, stiffness: 110, mass: 1 } });
  const winY = interpolate(drop, [0, 1], [900, 0]);
  const winS = interpolate(drop, [0, 1], [0.82, 1]);
  const winO = interpolate(drop, [0, 0.25], [0, 1], { extrapolateRight: 'clamp' });
  const since = f - FLIP_FRAME;
  const flash = since >= 0 && since < 3 ? 0.55 - since * 0.18 : 0;
  const pulse = since >= 0 ? Math.exp(-since * 0.22) * Math.cos(since * 0.9) * 10 : 0;
  const bw = frameW + pulse;
  return (
    <div style={{ width: 1080, height: 1920, background: '#161618', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: bw, background: G.bg, overflow: 'hidden', borderRadius: 8 }}>
        <div style={{ position: 'absolute', left: 540 - bw - WIN_W / 2, top: SAFE_CY - bw - WIN_H / 2, width: WIN_W, height: WIN_H, transform: `translateY(${winY}px) scale(${winS})`, opacity: winO, borderRadius: 18, overflow: 'hidden', boxShadow: '0 24px 70px rgba(0,0,0,0.28)', border: `2px solid ${G.border}`, background: G.panel }}>
          <div style={{ height: 64, background: '#e9e9e7', borderBottom: `2px solid ${G.line}`, display: 'flex', alignItems: 'center', gap: 12, padding: '0 24px', boxSizing: 'border-box' }}>
            {[0, 1, 2].map((i) => (
              <div key={i} style={{ width: 18, height: 18, borderRadius: 9, background: G.bar }} />
            ))}
            <div style={{ marginLeft: 18, height: 14, width: 220, background: G.line, borderRadius: 7 }} />
            <div style={{ marginLeft: 'auto', background: frameColor, color: '#fff', fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 28, padding: '8px 20px', borderRadius: 10 }}>{mode === 'design' ? 'Design' : 'Dev mode'}</div>
          </div>
          <div style={{ transform: `scale(${WIN_W / 1080})`, transformOrigin: '0 0', width: 1080, height: 1920 }}>
            <FakeDashboardV variant={mode === 'design' ? 'A' : 'B'} />
          </div>
        </div>
      </div>
      {(
        [
          { left: 0, top: 0, right: 0, height: bw },
          { left: 0, bottom: 0, right: 0, height: bw },
          { left: 0, top: 0, bottom: 0, width: bw },
          { right: 0, top: 0, bottom: 0, width: bw },
        ] as React.CSSProperties[]
      ).map((pos, i) => (
        <div key={i} style={{ position: 'absolute', background: frameColor, ...pos }} />
      ))}
      {flash > 0 && <div style={{ position: 'absolute', inset: 0, background: '#ffffff', opacity: flash }} />}
    </div>
  );
};
