import React from 'react';
import { AbsoluteFill, OffthreadVideo, staticFile, useCurrentFrame } from 'remotion';
import { C, Contents, CutWords, Diorama, VideoBand, Cutout, DOODLE, Doodle, HandCam, LongPage, PageFlip, PaperWipe, Sticker, Strips, Tear, TornWindow, bump, Desk, DropCap, Figure, Highlight, Kicker, MarginNote, Masthead, MockPage, Page, PaperTexture, Press, PullQuote, Rule, Stamp, pressEnd } from './kit';
import { InkCaptions, type Word } from './InkCaptions';

// «Бумажная печать»: изолированные демо своих компонентов. Каждое — один приём, 1080×1920, своя шкала.
const Sheet: React.FC<{ children: (f: number) => React.ReactNode }> = ({ children }) => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <PaperTexture tone={C.paperHi} />
      {children(f)}
    </Desk>
  );
};

// 1. Субтитры по словам
const Wd = (arr: [string, number, number][]): Word[] => arr.map(([t, s, e]) => ({ t, s, e }));
const CHUNKS: Word[][] = [
  Wd([['Каждый', 0.2, 0.55], ['кадр', 0.55, 0.9], ['читается', 0.9, 1.5]]),
  Wd([['как', 1.75, 1.95], ['страница', 1.95, 2.5], ['журнала.', 2.5, 3.1]]),
];
const DCaptions: React.FC = () => (
  <Sheet>
    {(f) => (
      <>
        <div style={{ position: 'absolute', top: 360, left: 90, right: 90 }}>
          <Press f={f} at={4} text="Голос → *чернила*." size={104} align="left" />
        </div>
        <InkCaptions chunks={CHUNKS} />
      </>
    )}
  </Sheet>
);

// 2. Лист: живая бумага + смена сцены
const DStage: React.FC = () => (
  <Desk>
    <Page from={0} to={58} enter="none">
      {(f) => (
        <div style={{ position: 'absolute', top: 620, left: 90, right: 90 }}>
          <Press f={f} at={8} text="Сцена — это *лист*." size={110} align="left" />
        </div>
      )}
    </Page>
    <Page from={58} to={130}>
      {(f) => (
        <div style={{ position: 'absolute', top: 620, left: 90, right: 90 }}>
          <Press f={f} at={70} text="Новый ложится *сверху*." size={110} align="left" />
        </div>
      )}
    </Page>
  </Desk>
);

// 3. Шапка газеты
const DMasthead: React.FC = () => (
  <Sheet>
    {(f) => (
      <>
        <Masthead f={f} at={4} title="Вестник" issue="№ 01" date="8 октября 2026" price="Экстренный выпуск" top={560} size={190} />
        <div style={{ position: 'absolute', top: 1000, left: 60, right: 60 }}>
          <Press f={f} at={50} text="Название как *шапка* газеты" size={84} />
        </div>
      </>
    )}
  </Sheet>
);

// 4. Маркер
const DHighlight: React.FC = () => (
  <Sheet>
    {(f) => (
      <div style={{ position: 'absolute', top: 520, left: 90, right: 90 }}>
        <Rule f={f} at={2} thick={2} style={{ margin: '24px 0 34px' }} />
        <Highlight
          f={f}
          at={30}
          size={52}
          text="Зритель листает ленту за секунды. Поэтому [[одна мысль на кадр]] и крупный шрифт. А главное слово в абзаце [[выделено маркером]], как в распечатке."
        />
      </div>
    )}
  </Sheet>
);

// 5. Штамп
const DStamp: React.FC = () => (
  <Sheet>
    {(f) => (
      <>
        <div style={{ position: 'absolute', top: 560, left: 90, right: 90 }}>
          <Press f={f} at={4} text="Черновик готов к печати." size={96} align="left" />
        </div>
        <div style={{ position: 'absolute', top: 1080, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
          <Stamp f={f} at={40} text="В печать" sub="Отдел выпуска · 08.10" />
        </div>
      </>
    )}
  </Sheet>
);

// 6. Цитата
const DQuote: React.FC = () => <Sheet>{(f) => <PullQuote f={f} at={4} text="Один кадр — *одна* мысль." by="Правило редакции" />}</Sheet>;

// 7. Иллюстрация с подписью и выноской
const DFigure: React.FC = () => (
  <Sheet>
    {(f) => (
      <div style={{ position: 'absolute', top: 380, left: 90 }}>
        <Figure f={f} at={4} n={1} caption="Интерфейс как гравюра в журнале." w={900} h={700} callout={{ x: 660, y: 520, r: 92, label: '1', lx: 820, ly: 300 }}>
          <MockPage w={872} h={672} />
        </Figure>
      </div>
    )}
  </Sheet>
);

// 8. Заметка на полях
const DNote: React.FC = () => (
  <Sheet>
    {(f) => (
      <>
        <div style={{ position: 'absolute', top: 640, left: 90, right: 200 }}>
          <Press f={f} at={4} text="Ролик за десять минут." size={96} align="left" />
        </div>
        <MarginNote f={f} at={36} text={'а раньше —\nцелый день!'} x={560} y={1010} rotate={-5} arrow="M 40 -20 C 10 -70, -40 -100, -110 -110 M -110 -110 L -86 -128 M -110 -110 L -92 -88" />
      </>
    )}
  </Sheet>
);

// 9. Оглавление
const DContents: React.FC = () => (
  <Sheet>
    {(f) => (
      <div style={{ position: 'absolute', top: 480, left: 90, right: 90 }}>
        <Press f={f} at={2} text="В *номере*" size={120} align="left" />
        <Rule f={f} at={14} thick={4} style={{ margin: '34px 0 44px' }} />
        <Contents
          f={f}
          at={22}
          active={2}
          activeAt={70}
          rows={[
            { t: 'Типографика', n: '04' },
            { t: 'Переходы', n: '11' },
            { t: 'Свои компоненты', n: '17' },
            { t: 'Звук и музыка', n: '24' },
          ]}
        />
      </div>
    )}
  </Sheet>
);

// 10. Буквица + колонка
const DDropCap: React.FC = () => (
  <Sheet>
    {(f) => (
      <div style={{ position: 'absolute', top: 420, left: 90, right: 90 }}>
        <Press f={f} at={4} text="Текст как *статья*" size={92} align="left" style={{ marginBottom: 22 }} />
        <Rule f={f} at={pressEnd(4, 'Текст как *статья*')} thick={2} style={{ marginBottom: 34 }} />
        <DropCap
          f={f}
          at={30}
          size={42}
          text="Длинную мысль не дробим на слайды. Ставим буквицу, выравниваем колонку по ширине и даём зрителю прочитать абзац целиком — так, как читают хороший журнал, не торопясь."
        />
      </div>
    )}
  </Sheet>
);

// 11. Длинная полоса: камера читает сверху вниз и в конце отъезжает на весь лист
const DLong: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <LongPage f={f} h={3000} keys={[{ f: 0, cy: 700, s: 1.05 }, { f: 30, cy: 700, s: 1.05 }, { f: 70, cy: 1500 }, { f: 95, cy: 1500 }, { f: 130, cy: 2250 }, { f: 150, cy: 2250 }, { f: 185, cy: 1500, s: 0.6 }]}>
        <div style={{ position: 'absolute', top: 360, left: 80, right: 80 }}>
          <Press f={f} at={6} text="Одна длинная *статья*" size={120} align="left" />
        </div>
        {['Камера не режет —', 'она читает.', 'Сверху вниз,', 'строка за строкой.'].map((t, i) => (
          <div key={i} style={{ position: 'absolute', top: 1200 + i * 120, left: 80 }}>
            <Press f={f} at={60 + i * 6} text={t} size={74} weight={400} align="left" />
          </div>
        ))}
        <div style={{ position: 'absolute', top: 2050, left: 80, right: 80 }}>
          <Rule f={f} at={118} thick={4} />
          <Press f={f} at={124} text="А в конце — *весь* лист." size={96} align="left" style={{ marginTop: 40 }} />
        </div>
      </LongPage>
    </Desk>
  );
};

// 12. Вырезка: реальное видео в бумажной рамке на скотче
const DCutout: React.FC = () => (
  <Sheet>
    {(f) => (
      <>
        <div style={{ position: 'absolute', top: 360, left: 90, right: 90 }}>
          <Press f={f} at={4} text="Видео — это *вырезка*." size={100} align="left" />
        </div>
        <Cutout f={f} at={30} x={60} y={820} w={900} h={300} rotate={-2} edge="torn" seed={8}>
          <VideoBand src={staticFile('editorial/insert-b.mp4')} w={900} h={300} x0={0.08} x1={0.92} y0={0.25} />
        </Cutout>
      </>
    )}
  </Sheet>
);

// 13. Наклейка
const DSticker: React.FC = () => (
  <Sheet>
    {(f) => (
      <>
        <div style={{ position: 'absolute', top: 700, left: 90, right: 90 }}>
          <Press f={f} at={4} text="Новая функция в *этом* выпуске." size={100} align="left" />
        </div>
        <Sticker f={f} at={40} x={820} y={500} text="новое!" d={240} rotate={12} />
        <Sticker f={f} at={58} x={260} y={1200} text="−50% времени" d={200} bg={C.ink} rotate={-10} size={34} />
      </>
    )}
  </Sheet>
);

// 14. Бумажные полоски-подписи поверх видео
const DStrips: React.FC = () => (
  <Desk>
    <Diorama f={useCurrentFrame()} at={0} />
    <Strips f={useCurrentFrame()} at={16} x={90} y={270} lines={['подписи поверх кадра —', 'полоски бумаги,', '*вырезанные вручную*']} size={58} accent={C.amber} />
  </Desk>
);

// 15. Разрыв листа
const DTear: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <AbsoluteFill>
        <PaperTexture tone={C.paperHi} />
        <div style={{ position: 'absolute', top: 760, left: 90, right: 90 }}>
          <Press f={f} at={56} text="Под ним — *следующий*." size={104} align="left" />
        </div>
      </AbsoluteFill>
      <Tear f={f} at={40}>
        <AbsoluteFill>
          <PaperTexture tone={C.paper} />
          <div style={{ position: 'absolute', top: 760, left: 90, right: 90 }}>
            <Press f={f} at={4} text="Старый лист *рвётся*." size={104} align="left" />
          </div>
        </AbsoluteFill>
      </Tear>
    </Desk>
  );
};

// 16. Рисовка от руки поверх видео
const DDoodle: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <Diorama f={f} at={0} />
      <Doodle f={f} at={8} d={DOODLE.circle(750, 620, 250, 240)} len={14} width={8} />
      <Doodle f={f} at={26} d={DOODLE.arrow(200, 260, 340, 520)} len={10} width={8} />
      <Doodle f={f} at={36} d={DOODLE.spark(820, 420, 90)} len={8} width={8} color={C.amber} />
      <Doodle f={f} at={42} d={DOODLE.star(860, 1300, 50)} len={8} width={7} />
      <Doodle f={f} at={48} d={DOODLE.swoosh(120, 1380, 600)} len={10} width={10} color={C.amber} />
    </Desk>
  );
};

// 17. Переход «лист с рваным краем»
const DWipe: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <Diorama f={f} at={0} />
      <PaperWipe f={f} at={30} len={14}>
        <div style={{ position: 'absolute', top: 760, left: 90, right: 90 }}>
          <Press f={f} at={48} text="Лист *накрывает* кадр." size={104} align="left" />
        </div>
      </PaperWipe>
    </Desk>
  );
};

// 18. Переход «перелистывание»
const DFlip: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <AbsoluteFill>
        <PaperTexture tone="#e4d7bd" />
        <CutWords f={f} at={46} words={['Новая', 'страница.']} size={150} y={700} />
      </AbsoluteFill>
      <PageFlip f={f} at={30} len={16}>
        <AbsoluteFill>
          <PaperTexture tone={C.paperHi} />
          <div style={{ position: 'absolute', top: 760, left: 90, right: 90 }}>
            <Press f={f} at={2} text="Страницу *перелистнули*." size={104} align="left" />
          </div>
        </AbsoluteFill>
      </PageFlip>
    </Desk>
  );
};

// 19. Бумага рвётся и открывает видео
const DWindow: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <Diorama f={f} at={0} night />
      <TornWindow f={f} at={30} len={14} from={0} to={0.42} cx={540} cy={820}>
        <div style={{ position: 'absolute', top: 250, left: 90, right: 90 }}>
          <Press f={f} at={2} text="Бумагу *порвали* —" size={96} align="left" />
        </div>
        <div style={{ position: 'absolute', top: 1260, left: 90, right: 90 }}>
          <Press f={f} at={50} text="а под ней — ночь." size={96} align="left" />
        </div>
      </TornWindow>
    </Desk>
  );
};

// 20. Слова-вырезки в ритм + толчок камеры
const DCutWords: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <AbsoluteFill>
        <PaperTexture tone="#e4d7bd" />
      </AbsoluteFill>
      <HandCam f={f} plus={bump(f, [10, 24, 38], 0.03)}>
        <CutWords f={f} at={10} words={['Вырезали.', 'Вклеили.', 'Обвели.']} step={14} size={150} y={560} />
        <Doodle f={f} at={56} d={DOODLE.swoosh(110, 1370, 760)} len={10} width={9} />
      </HandCam>
    </Desk>
  );
};

// 21. Камера в руках: дрейф + наезд + толчок на каждый шлепок
const DHandCam: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <HandCam f={f} push={[0, 90, 1, 1.05]} plus={bump(f, [18, 34, 50], 0.035)}>
        <Diorama f={f} at={0} />
        <Strips f={f} at={18} x={90} y={270} lines={['Камера в руках —', '*толчок на шлепок*']} size={66} accent={C.amber} />
        <Sticker f={f} at={34} x={760} y={1180} text="бум!" d={220} rotate={10} />
        <Sticker f={f} at={50} x={250} y={1260} text="ещё!" d={180} bg={C.ink} rotate={-12} />
      </HandCam>
    </Desk>
  );
};

// 22. Бумажная аппликация: слои встают как в книжке-раскладушке; день → ночь через разрыв
const DDiorama: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Desk>
      <Diorama f={f} at={46} night />
      <TornWindow f={f} at={44} len={14} from={0} to={1.5} cx={750} cy={620}>
        <Diorama f={f} at={0} />
      </TornWindow>
    </Desk>
  );
};

export const PACK_DEMOS: { id: string; dur: number; C: React.FC }[] = [
  { id: 'own-ink-captions', dur: 120, C: DCaptions },
  { id: 'own-paper-stage', dur: 130, C: DStage },
  { id: 'own-masthead', dur: 110, C: DMasthead },
  { id: 'own-highlighter', dur: 110, C: DHighlight },
  { id: 'own-rubber-stamp', dur: 90, C: DStamp },
  { id: 'own-pull-quote', dur: 100, C: DQuote },
  { id: 'own-figure-plate', dur: 110, C: DFigure },
  { id: 'own-margin-note', dur: 100, C: DNote },
  { id: 'own-contents', dur: 100, C: DContents },
  { id: 'own-drop-cap', dur: 90, C: DDropCap },
  { id: 'own-long-page', dur: 215, C: DLong },
  { id: 'own-cutout-video', dur: 110, C: DCutout },
  { id: 'own-sticker', dur: 100, C: DSticker },
  { id: 'own-paper-strips', dur: 90, C: DStrips },
  { id: 'own-paper-tear', dur: 100, C: DTear },
  { id: 'own-doodle', dur: 90, C: DDoodle },
  { id: 'own-paper-wipe', dur: 90, C: DWipe },
  { id: 'own-page-flip', dur: 90, C: DFlip },
  { id: 'own-torn-window', dur: 90, C: DWindow },
  { id: 'own-cut-words', dur: 90, C: DCutWords },
  { id: 'own-hand-cam', dur: 90, C: DHandCam },
  { id: 'own-diorama', dur: 100, C: DDiorama },
];
