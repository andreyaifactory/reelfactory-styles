// cel-flash-stomp · 竖版 9:16（1080×1920）。
// 保留：三词逐拍硬切（0/30/60）、弹落 1.18→0.98→1（6f）、交替 ±2.5° 歪斜、落定帧起背景每 2f 闪切、第三词闪加倍、66–80 底部标签条淡入、80–144 静止。
// 竖版：词居中对准安全区中心（y 835），字号 210→250（相对画宽放大，最长词 FASTER 仍在 960 内）；
// 底部标签条从画面最底移到安全区内（y 1300…1396，宽 880），横排元素不变。删除角标 TitleBlock。
// 以下为横版原注释：
// 底色闪砸字（cel-flash-stomp）——stomp-typography 逐词节拍砸字 × background-cel-flash 纯色底闪的组合变异。
// 三个大词逐拍硬切占满屏，每词像图章一样歪着砸落；词落定帧起背景层每 2f 在 G.bg 与加深灰之间闪切——
// 文字层独立在上纹丝不动，只闪背景是本组合命门（动漫必杀技字卡感）。第三词闪加倍且对比拉大。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const CEL_FLASH_STOMP_VERTICAL_DURATION = 145;

type Word = { text: string; start: number; end: number; rot: number; flashLen: number; flashDark: string };
const LAND = 6;
const WORDS: Word[] = [
  { text: 'SHIP', start: 0, end: 30, rot: 2.5, flashLen: 6, flashDark: '#cfcfca' },
  { text: 'FASTER', start: 30, end: 60, rot: -2.5, flashLen: 6, flashDark: '#cfcfca' },
  { text: 'TODAY', start: 60, end: 9999, rot: 0, flashLen: 8, flashDark: '#c4c4c0' },
];

export const CelFlashStompVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const word = WORDS.find((w) => frame >= w.start && frame < w.end)!;
  const t = frame - word.start;
  const scale =
    t < 4
      ? interpolate(t, [0, 4], [1.18, 0.98], { extrapolateRight: 'clamp', easing: Easing.out(Easing.poly(5)) })
      : interpolate(t, [4, LAND], [0.98, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.quad) });
  const ft = t - LAND;
  const flashing = ft >= 0 && ft < word.flashLen;
  const bg = flashing && Math.floor(ft / 2) % 2 === 0 ? word.flashDark : G.bg;
  const labelOp = interpolate(frame, [66, 80], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.quad) });
  return (
    <div style={{ width: 1080, height: 1920, background: bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE_CY, display: 'flex', justifyContent: 'center', transform: 'translateY(-50%)' }}>
        <div style={{ fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 250, color: G.ink, letterSpacing: -5, transform: `scale(${scale}) rotate(${word.rot}deg)` }}>{word.text}</div>
      </div>
      <div style={{ position: 'absolute', left: 100, width: 880, top: 1300, height: 96, background: G.ink, opacity: labelOp, display: 'flex', alignItems: 'center', gap: 20, padding: '0 40px', boxSizing: 'border-box', borderRadius: 12 }}>
        <div style={{ width: 40, height: 40, borderRadius: 10, background: G.sideBar }} />
        <div style={{ height: 16, width: 300, background: G.mid, borderRadius: 8 }} />
        <div style={{ marginLeft: 'auto', height: 16, width: 140, background: G.sideBar, borderRadius: 8 }} />
      </div>
    </div>
  );
};
