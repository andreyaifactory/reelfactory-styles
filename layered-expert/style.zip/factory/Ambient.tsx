import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';

/**
 * Живой слой стиля «Слои» — едва заметный мягкий свет, медленно гуляющий по
 * подложке. Это воздух под графическим блоком без видео, а не событие: кадр
 * стиля живёт говорящим человеком, зумом камеры и вставками.
 */
export const Ambient: React.FC = () => {
  const f = useCurrentFrame();
  const x = 50 + 18 * Math.sin(f / 90);
  const y = 38 + 10 * Math.cos(f / 110);
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(60% 40% at ${x}% ${y}%, rgba(79,141,247,0.07), transparent 70%)`,
        pointerEvents: 'none',
      }}
    />
  );
};
