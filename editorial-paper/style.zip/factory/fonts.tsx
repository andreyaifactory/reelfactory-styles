import React from 'react';
import { PaperFonts } from '../kit/fonts';

/**
 * Шрифты пака — из его же файлов: при включении стиля `fonts/` раскладывается
 * в `public/styles/editorial-paper/fonts/`.
 */
export const FontLoader: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <PaperFonts base="styles/editorial-paper/fonts">{children}</PaperFonts>
);
