// font-weight-pump · 竖版 9:16（1080×1920）。
// 保留：拍点 30/50/70/90/110、10f 幂衰减 (1-t/10)^0.8、stroke 0→10px、字重 400↔900 离散跳、第 3/5 拍 scaleX +8%、120–139 静止。
// 竖版：一行 "PUMP IT UP" 改为两行 "PUMP" / "IT UP"，字号 150→230（相对画宽放大），整组对准安全区中心；
// stroke 峰值 10→14px 随字号等比；底部节拍点从 y≈950 移到安全区内 y 1300。
// 以下为横版原注释：
// 字重脉冲（font-weight-pump）——标题笔画随节拍变粗又弹回，像文字跟着低音鼓蹦迪。
// 命中瞬间 -webkit-text-stroke 0→10px 跳满，随后 10f 幂衰减弹回 0；fontWeight 在命中窗口 400→900 离散跳变
// （env>0.15）；第 3、5 拍为重音，额外 scaleX 1→1.08 同衰减。底部 5 个节拍点作节拍参照。
import React from 'react';
import { useCurrentFrame } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const FONT_WEIGHT_PUMP_VERTICAL_DURATION = 140;
const BEATS = [30, 50, 70, 90, 110];
const ACCENTS = new Set([2, 4]);
const DECAY = 10;
const envAt = (frame: number, beat: number) => {
  const t = frame - beat;
  if (t < 0 || t >= DECAY) return 0;
  return Math.pow(1 - t / DECAY, 0.8);
};

export const FontWeightPumpVertical: React.FC = () => {
  const frame = useCurrentFrame();
  let env = 0;
  let activeBeat = -1;
  BEATS.forEach((b, i) => {
    const e = envAt(frame, b);
    if (e > env) {
      env = e;
      activeBeat = i;
    }
  });
  const strokeW = 14 * env;
  const weight = env > 0.15 ? 900 : 400;
  const scaleX = activeBeat >= 0 && ACCENTS.has(activeBeat) ? 1 + 0.08 * env : 1;
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, position: 'relative', overflow: 'hidden', fontFamily: 'Helvetica, Arial, sans-serif' }}>
      <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE_CY, transform: 'translateY(-50%)', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        {['PUMP', 'IT UP'].map((l) => (
          <div key={l} style={{ fontSize: 230, lineHeight: 1.02, fontWeight: weight, color: G.ink, letterSpacing: 8, whiteSpace: 'nowrap', WebkitTextStroke: `${strokeW}px ${G.ink}`, transform: `scaleX(${scaleX})` }}>
            {l}
          </div>
        ))}
      </div>
      <div style={{ position: 'absolute', left: 0, top: 1300, width: 1080, display: 'flex', justifyContent: 'center', gap: 60 }}>
        {BEATS.map((b, i) => {
          const e = envAt(frame, b);
          return (
            <div key={i} style={{ width: 32, height: 32, borderRadius: 16, background: G.line, position: 'relative', transform: `scale(${1 + 0.8 * e})` }}>
              <div style={{ position: 'absolute', inset: 0, borderRadius: 16, background: G.ink, opacity: e > 0.02 ? Math.min(1, 0.3 + e * 1.2) : 0 }} />
            </div>
          );
        })}
      </div>
    </div>
  );
};
