// mask-wipe · 竖版 9:16（1080×1920）。
// 节拍（0–40 全景 hold → 40–85 卡放大成窗、窗内新景 0.42→1 反向补偿 → hold）与曲线 bezier(0.5,0,0.2,1) 同横版。
// 竖版：projects 全景按 1.12 放大铺满竖幅，并平移让 card4 落在安全区中心；窗口终点是 1080×1920 全屏；
// 窗内新景取同页右半区块（竖幅 cover）。
// 以下为横版原注释：
// mask-wipe 元素遮罩擦除（轮 D）——真实项目卡（card4-hires）放大成
// 全屏窗口，projects 全景从窗内长出接管："点开一张卡进入它的世界"。
// 节拍：0–40 全景 hold → 40–85 卡放大成窗（窗内新景反向补偿）→ 85–120 hold。
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame, Easing } from 'remotion';
import layout from '../../_textures/live-layout.json';

export const MASKWIPE_VERTICAL_DUR = 120;
const VS = 1.12;
const SAFE_CY = 835;

const C4 = layout.projects.cards[3]; // 页面空间 x=781,y=616,w=357,h=312

export const MaskWipeRealVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const t = interpolate(frame, [40, 85], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
    easing: Easing.bezier(0.5, 0, 0.2, 1),
  });
  // 卡在屏幕空间的初始 geometry（全景视口下）
  // 竖版全景：放大 VS，card4 中心对准 (540, SAFE_CY)
  const bgLeft = 540 - (C4.x + C4.w / 2) * VS;
  const bgTop = SAFE_CY - (C4.y + C4.h / 2) * VS;
  const g0 = { x: bgLeft + C4.x * VS, y: bgTop + C4.y * VS, w: C4.w * VS, h: C4.h * VS, r: 14 };
  const x = interpolate(t, [0, 1], [g0.x, 0]);
  const y = interpolate(t, [0, 1], [g0.y, 0]);
  const w = interpolate(t, [0, 1], [g0.w, 1080]);
  const h = interpolate(t, [0, 1], [g0.h, 1920]);
  const r = interpolate(t, [0, 1], [g0.r, 0]);
  // 窗内新景（detail 视角用 papers 页顶部模拟）：从 0.42 缩放反向长到 1
  const innerScale = interpolate(t, [0, 1], [0.42, 1]);
  return (
    <AbsoluteFill style={{ backgroundColor: '#f9f6f1', overflow: 'hidden' }}>
      {/* 背景：projects 全景 */}
      <Img
        src={staticFile('textures/live/projects-full.png')}
        style={{ position: 'absolute', left: bgLeft, top: bgTop, width: 1920 * VS }}
      />
      {/* 卡片即窗口 */}
      <div
        style={{
          position: 'absolute', left: x, top: y, width: w, height: h,
          borderRadius: r, overflow: 'hidden',
          boxShadow: t > 0 && t < 1 ? '0 16px 56px rgba(31,28,23,0.25)' : 'none',
        }}
      >
        {/* 窗内新景：projects 页深部（detail 语义），反向补偿铺满 */}
        <div
          style={{
            position: 'absolute', width: 1080, height: 1920,
            left: '50%', top: '50%',
            transform: `translate(-50%, -50%) scale(${innerScale})`,
            overflow: 'hidden', background: '#f9f6f1',
          }}
        >
          <Img
            src={staticFile('textures/live/projects-full.png')}
            style={{ position: 'absolute', left: 1080 - 1920 * VS + 40, top: -20, width: 1920 * VS }}
          />
        </div>
        {/* 卡片脸：随放大渐隐露出窗内景 */}
        <Img
          src={staticFile('textures/live/card4-hires.png')}
          style={{
            position: 'absolute', inset: 0, width: '100%', height: '100%',
            opacity: Math.max(0, 1 - t * 2.2),
          }}
        />
      </div>
    </AbsoluteFill>
  );
};
