import React from 'react';

/**
 * Оправа реального скрина — вставка стиля «Слои»: скругление 34, тонкая светлая
 * кромка и мягкая тень под снимком. Движение снимка ведёт ядро; свой вылет с
 * баунсом и наклоном у вставки — `Card` из кита.
 */
export const ScreenFrame: React.FC<{ width: number; height: number; children: React.ReactNode }> = ({ width, height, children }) => (
  <div
    style={{
      width,
      height,
      borderRadius: 34,
      overflow: 'hidden',
      background: '#fff',
      boxShadow: '0 26px 50px rgba(6,10,22,0.35), 0 0 0 1px rgba(255,255,255,0.6) inset',
    }}
  >
    {children}
  </div>
);
