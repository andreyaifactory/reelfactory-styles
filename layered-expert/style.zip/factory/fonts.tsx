import React from 'react';
import { LayerFonts } from '../kit/kit';

/**
 * Шрифты пака — из его же файлов: при включении стиля `fonts/` раскладывается
 * в `public/styles/layered-expert/fonts/`, туда же смотрит кит. Кадры ждут
 * загрузки: Oswald, Bad Script и Montserrat — все с кириллицей.
 */
export const FontLoader: React.FC<{ children: React.ReactNode }> = ({ children }) => <LayerFonts>{children}</LayerFonts>;
