import React from 'react';
import { useCurrentFrame } from 'remotion';
import { C, E, seg } from '../kit/kit';

/**
 * Оправа реального скрина — врезка «Удара»: снимок в жёстком прямоугольнике без
 * рамки и скругления, под ним плоская лаймовая плита со сдвигом 24 px. Плита
 * выезжает из-под снимка за 3 кадра — как у `Cut`. Движение снимка ведёт ядро.
 */
export const ScreenFrame: React.FC<{ width: number; height: number; children: React.ReactNode }> = ({
  width,
  height,
  children,
}) => {
  const frame = useCurrentFrame();
  const shift = 24 * seg(frame, 2, 5, E.outExpo);
  return (
    <div style={{ position: 'relative', width, height }}>
      <div style={{ position: 'absolute', inset: 0, background: C.lime, transform: `translate(${shift}px, ${shift}px)` }} />
      <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: C.black }}>{children}</div>
    </div>
  );
};
