import React from 'react';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import { C, E, IRIS, IrisRim, TEXT, lerp, seg } from './kit';

// Субтитры «Жидкого стекла»: каждая фраза — стеклянная капсула внизу кадра, слова проступают из тумана.
// Сказанное — белое, звучащее — белое + тонкая полоска перелива под словом (растёт 6f), будущее — дымка.
// Шрифт — Manrope 700 (широкий Unbounded в субтитрах не помещается в строку).
// Новая фраза — новая капсула: конденсируется 8f (стекло мутнеет из прозрачного, пружина 0.92→1, подъём 14px).
// Перелив здесь только в полоске под словом: это свет, а не цвет букв.

/** Слово капсулы: времена — в кадрах ролика. */
export type CapsuleWord = { text: string; from: number; to: number };

/**
 * Одна капсула-подпись. Чистая отрисовка: что показывать и когда, решает тот, кто её ставит.
 * from — кадр, с которого капсула в кадре; frame — текущий кадр ролика.
 */
export const CaptionCapsule: React.FC<{
  words: CapsuleWord[];
  from: number;
  frame: number;
  size?: number;
  maxWidth?: number;
}> = ({ words, from, frame, size = 50, maxWidth = 900 }) => {
  const p = seg(frame, from, from + 14);
  const op = seg(frame, from, from + 6);
  const sc = lerp(E.jelly(p), 0.92, 1);
  const r = Math.round(size * 0.95);
  return (
    <div
      style={{
        position: 'relative',
        display: 'inline-block',
        maxWidth,
        borderRadius: r,
        opacity: op,
        transform: `translateY(${lerp(E.glide(p), 14, 0)}px) scale(${sc})`,
        background: 'linear-gradient(155deg, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0.05) 40%, rgba(16,10,40,0.30) 70%, rgba(255,255,255,0.08) 100%), rgba(14,9,34,0.42)',
        backdropFilter: `blur(${26 * E.outCubic(p)}px) saturate(1.6)`,
        WebkitBackdropFilter: `blur(${26 * E.outCubic(p)}px) saturate(1.6)`,
        border: '1.5px solid rgba(255,255,255,0.22)',
        boxShadow: 'inset 0 1.5px 0 rgba(255,255,255,0.55), 0 20px 50px rgba(4,2,20,0.45)',
      }}
    >
      <IrisRim f={frame} r={r} opacity={0.45 * op} />
      <div
        style={{
          position: 'relative',
          padding: `${Math.round(size * 0.3)}px ${Math.round(size * 0.66)}px ${Math.round(size * 0.36)}px`,
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          columnGap: Math.round(size * 0.28),
          rowGap: Math.round(size * 0.1),
          fontFamily: TEXT,
          fontSize: size,
          fontWeight: 700,
          letterSpacing: '-0.01em',
          lineHeight: 1.2,
        }}
      >
        {words.map((w, i) => {
          const active = frame >= w.from && frame < w.to + 2;
          const said = frame >= w.to;
          const c = seg(frame, w.from, w.from + 6, E.glide);
          const u = active ? seg(frame, w.from, w.from + 6, E.outCubic) : 0;
          return (
            <span
              key={i}
              style={{
                position: 'relative',
                color: active || said ? C.text : C.dim,
                filter: active || said ? `blur(${3 * (1 - c)}px)` : 'blur(1.5px)',
                transform: `translateY(${active ? -3 * c : 0}px)`,
              }}
            >
              {w.text}
              <span
                style={{
                  position: 'absolute',
                  left: 0,
                  right: 0,
                  bottom: -Math.round(size * 0.08),
                  height: Math.max(4, Math.round(size * 0.08)),
                  borderRadius: 4,
                  background: IRIS,
                  transform: `scaleX(${u})`,
                  transformOrigin: '0 50%',
                }}
              />
            </span>
          );
        })}
      </div>
    </div>
  );
};

/** Слово из расшифровки: время в секундах. Таймкоды — whisper-cli (-ojf -ml 1 -sow). */
export type Word = { t: string; s: number; e: number };

/**
 * Субтитры ролика целиком: фразы по 2–6 слов (разрыв на . ? ! и на паузе >0.3s). Капсула стоит по
 * центру, верх — top (над нижней безопасной зоной).
 */
export const GlassCaptions: React.FC<{ chunks: Word[][]; top?: number; size?: number; hideFrom?: number }> = ({ chunks, top = 1270, size = 50, hideFrom }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  if (hideFrom !== undefined && f >= hideFrom) return null;
  const idx = chunks.findIndex((c, i) => {
    const start = c[0].s - 0.08;
    const next = chunks[i + 1];
    const end = next ? Math.min(next[0].s - 0.08, c[c.length - 1].e + 0.6) : c[c.length - 1].e + 0.6;
    return t >= start && t < end;
  });
  if (idx < 0) return null;
  const c = chunks[idx];
  const from = Math.round((c[0].s - 0.08) * fps);
  return (
    <div style={{ position: 'absolute', top, left: 60, right: 60, display: 'flex', justifyContent: 'center' }}>
      <CaptionCapsule
        words={c.map((w) => ({ text: w.t, from: Math.round(w.s * fps), to: Math.round(w.e * fps) }))}
        from={from}
        frame={f}
        size={size}
        maxWidth={960}
      />
    </div>
  );
};
