// hatch-depth · 竖版 9:16（1080×1920）：逐条 wipe / 斜纹→实心 morph / wiggle 的进度窗口同横版（132f）。
// 竖版：设计坐标 270×480（×4 放大），条形图整组放进安全区（设计 y 57…360），条更粗（36）；
// 标签改 “Series A” 式写法；全大写状态条（METRICS ● LIVE）改为图下方一行小写状态，不做标题上方的圆点小标。
// 以下为横版原注释：
// hatch-depth — Hatch → Depth Chart 斜纹柱实体化（motion-lab 定稿转原生 Remotion）
// 标签下的斜纹条逐条 wipe 伸长（保持 45° 斜纹占位质感），随后斜纹层淡出、强调色
// 实心层淡入，蜕变为数据横柱条形图——几何无跳变、只换纹理与颜色，讲"占位变真数据"的隐喻。
// 设计坐标 480×270（DesignStage 等比放大），参数表数值以此坐标系标定。
import React from 'react';
import { DesignStage, E, seg, useT } from '../../_fixtures/Motion';

export const HATCH_DEPTH_VERTICAL_DURATION = 132; // 4400ms @30fps

const ACCENT = '#5B8DEF'; // 模板强调色，可按项目替换
const ACCENT_HI = '#8FB2F7'; // 同族高亮（数值文字）

const ROWS = [
  { label: 'Series A', w: 0.85 },
  { label: 'Series B', w: 0.55 },
  { label: 'Group C', w: 0.95 },
  { label: 'Group D', w: 0.4 },
  { label: 'Other E', w: 0.7 },
];

// 头部信息条里的 &nbsp;&nbsp;（连续普通空格在 JSX 会被折叠，须用不换行空格）
const NBSP2 = '  ';

export const HatchDepthVertical: React.FC = () => {
  const t = useT();
  // 头部信息条：下滑入场
  const headIn = seg(t, 0.62, 0.78, E.outCubic);
  return (
    <DesignStage w={270} h={480} bg="#0a0a0c">
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 57,
          height: 303,
          background: '#0a0a0c',
          padding: '0 24px 0 10px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          gap: 16,
          // 原栈 SF Mono 对无头 Chrome 不可见，真实 Chrome 落到 macOS 默认
          // 等宽字体 Courier（衬线打字机形）；显式补 Courier 兜底对齐原片
          fontFamily: '"SF Mono",Courier,monospace',
        }}
      >
        {ROWS.map(({ label, w }, i) => {
          // 逐条 wipe 伸长 → 斜纹淡出/实心淡入 → 末段轻微 wiggle
          const grow = seg(t, 0.06 + i * 0.05, 0.06 + i * 0.05 + 0.22, E.outCubic);
          const morph = seg(t, 0.5 + i * 0.03, 0.5 + i * 0.03 + 0.14);
          const wiggle = 1 + Math.sin(t * 30 + i * 2.1) * 0.02 * seg(t, 0.7, 0.85);
          const wPct = grow * w * 78 * wiggle; // 竖版条区窄，留出柱端数值位
          return (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, height: 36 }}>
              <span
                style={{
                  color: morph > 0.5 ? '#5c626f' : '#8b91a3',
                  fontSize: 11,
                  width: 64,
                  whiteSpace: 'nowrap',
                  flex: 'none',
                  textAlign: 'right',
                }}
              >
                {label}
              </span>
              <div style={{ position: 'relative', height: '100%', flex: 1 }}>
                {/* 斜纹占位层 */}
                <div
                  style={{
                    position: 'absolute',
                    left: 0,
                    top: 0,
                    height: '100%',
                    width: `${wPct}%`,
                    borderRadius: 3,
                    background: 'repeating-linear-gradient(45deg,#565860 0 4px,transparent 4px 9px)',
                    border: '1px solid #565860',
                    // 原渲染无全局 border-box：宽高为内容尺寸，1px 边框外扩
                    // （斜纹相位随元素尺寸变化，box-sizing 不还原相位就对不上）
                    boxSizing: 'content-box',
                    opacity: 1 - morph,
                  }}
                />
                {/* 强调色实心层 */}
                <div
                  style={{
                    position: 'absolute',
                    left: 0,
                    top: 0,
                    height: '100%',
                    width: `${wPct}%`,
                    borderRadius: 3,
                    background: `linear-gradient(90deg,${ACCENT},${ACCENT_HI})`,
                    opacity: morph,
                  }}
                />
                {/* 柱端数值 */}
                <span
                  style={{
                    position: 'absolute',
                    top: '50%',
                    transform: 'translateY(-50%)',
                    color: ACCENT_HI,
                    fontSize: 11,
                    left: `calc(${wPct}% + 6px)`,
                    opacity: morph,
                  }}
                >
                  {Math.round(w * 420 * grow)}K
                </span>
              </div>
            </div>
          );
        })}
        {/* 状态行：图下方，小写，下滑入场 */}
        <div
          style={{
            marginTop: 8,
            paddingLeft: 10,
            fontWeight: 600,
            fontSize: 10,
            whiteSpace: 'nowrap',
            fontFamily: '"SF Mono",Courier,monospace',
            transform: `translateY(${-12 + headIn * 12}px)`,
            opacity: headIn,
          }}
        >
          <span style={{ color: '#67d17c' }}>● live</span>
          {NBSP2}
          <span style={{ color: '#8b91a3' }}>total 875K{NBSP2}avg 1.02M</span>
        </div>
      </div>
    </DesignStage>
  );
};
