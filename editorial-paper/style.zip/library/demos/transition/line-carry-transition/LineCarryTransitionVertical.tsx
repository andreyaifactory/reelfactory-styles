// line-carry-transition · 竖版 9:16（1080×1920）。
// 节拍同横版（0–24f 进度条走满 → 24–34f 冲出 → 34–94f 镜头 inOut(cubic) 平移一屏、线与镜头同速 →
// 94–112f 线收成 B 卡框 → 112–124f 内容淡入 → 真静止 36f，160f）。
// 竖版：世界改为纵向 1080×3840（A 上半 / B 下半），线从进度条末端拐直角向下冲，镜头向下跟；
// 笔头在平移段稳定在画面 y≈1052、x=900（避开右下按钮栏 x>940），B 卡框落在安全区 y 700…1100。
import React from 'react';
import { AbsoluteFill, useCurrentFrame, interpolate, Easing } from 'remotion';
import { G, Card, TitleBlock } from '../../_fixtures/Fixtures';

export const LINE_CARRY_TRANSITION_VERTICAL_DURATION = 160;

// 进度条 140→900 @y752 → 下行到 3020 → 左 140 → 上 2620 → 右 900（闭合 B 框 140,2620–900,3020）
const PATH = 'M 140 752 L 900 752 L 900 3020 L 140 3020 L 140 2620 L 900 2620';
const SEGS: Array<[number, number, number, number, number]> = [
  [140, 752, 900, 752, 760],
  [900, 752, 900, 3020, 2268],
  [900, 3020, 140, 3020, 760],
  [140, 3020, 140, 2620, 400],
  [140, 2620, 900, 2620, 760],
];
const TOTAL = 4948;

const tipAt = (drawn: number): [number, number] => {
  let d = Math.max(0, Math.min(drawn, TOTAL));
  for (const [x1, y1, x2, y2, len] of SEGS) {
    if (d <= len) {
      const t = d / len;
      return [x1 + (x2 - x1) * t, y1 + (y2 - y1) * t];
    }
    d -= len;
  }
  return [900, 2620];
};

export const LineCarryTransitionVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const cam = interpolate(frame, [34, 94], [0, 1920], {
    easing: Easing.inOut(Easing.cubic),
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  let drawn: number;
  if (frame < 24) {
    drawn = interpolate(frame, [0, 24], [0, 760], { easing: Easing.out(Easing.cubic), extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  } else if (frame < 34) {
    drawn = interpolate(frame, [24, 34], [760, 1060], { extrapolateRight: 'clamp' });
  } else if (frame < 94) {
    drawn = 1060 + cam;
  } else {
    drawn = interpolate(frame, [94, 112], [2980, TOTAL], { easing: Easing.out(Easing.cubic), extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  }

  const contentOpacity = interpolate(frame, [112, 124], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const tipMounted = frame < 118;
  const tipOpacity = interpolate(frame, [112, 118], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const [tx, ty] = tipAt(drawn);

  return (
    <AbsoluteFill style={{ background: G.bg, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', width: 1080, height: 3840, transform: `translateY(${-cam}px)` }}>
        <div style={{ position: 'absolute', left: 0, top: 1920, width: 1080, height: 1920, background: G.panel }} />

        <div style={{ position: 'absolute', left: 140, top: 250 }}>
          <TitleBlock text="Scene A" size={72} />
        </div>
        <Card w={760} h={400} seed={2} style={{ position: 'absolute', left: 140, top: 330 }} />
        <div style={{ position: 'absolute', left: 140, top: 749, width: 760, height: 6, borderRadius: 3, background: G.line }} />

        <svg width={1080} height={3840} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
          <path d={PATH} fill="none" stroke={G.ink} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={TOTAL} strokeDashoffset={TOTAL - drawn} />
          {tipMounted && <circle cx={tx} cy={ty} r={13} fill={G.ink} opacity={tipOpacity} />}
        </svg>

        <div
          style={{
            position: 'absolute', left: 140, top: 2620, width: 760, height: 400,
            boxSizing: 'border-box', padding: 34, display: 'flex', flexDirection: 'column', gap: 18,
            opacity: contentOpacity,
          }}
        >
          <div style={{ height: 24, width: '58%', background: G.bar, borderRadius: 12 }} />
          <div style={{ height: 15, width: '86%', background: G.line, borderRadius: 7 }} />
          <div style={{ height: 15, width: '72%', background: G.line, borderRadius: 7 }} />
          <div style={{ height: 15, width: '64%', background: G.line, borderRadius: 7 }} />
          <div style={{ marginTop: 'auto', display: 'flex', gap: 12, alignItems: 'center' }}>
            <div style={{ width: 40, height: 40, borderRadius: 20, background: G.mid }} />
            <div style={{ height: 14, width: 120, background: G.line, borderRadius: 7 }} />
          </div>
        </div>
        <div style={{ position: 'absolute', left: 140, top: 2520, opacity: contentOpacity }}>
          <TitleBlock text="Scene B" size={72} />
        </div>
      </div>
    </AbsoluteFill>
  );
};
