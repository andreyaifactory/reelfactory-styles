// speed-ramp · 竖版 9:16（1080×1920）。
// 保留：帧号 remap 0–40→0–88（快）、40–85→88–97（0.2x 凝视窗）、85–135→97–207（快）；快段 CameraMotionBlur（200°/20），慢段不包。
// 竖版：卡片 460→620 宽（步距 520→690），导轨速度按步距同比 28→37.15px/源帧；导轨对准安全区中心 y 835，
// 慢速窗中点（src≈92.4）时目标卡 k=5 中心落在 x 540。横向导轨保留：竖画面里一次只看清一张卡，"凝视"更集中。
// 以下为横版原注释：
// speed-ramp 变速（轮 C）——真实卡片流帧号 remap：快(斜率2.2) → 0.2x 慢速展示窗 → 快。慢速窗中目标卡（card4-hires）清晰滑过屏中。
// blur 联动速率：快段包 blur、慢段不包，反差即"凝视感"。
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from 'remotion';
import { CameraMotionBlur } from '@remotion/motion-blur';
import layout from '../../_textures/live-layout.json';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const SPEEDRAMP_VERTICAL_DUR = 135;
const CARD_W = 620;
const GAP = 70;
const STEP = CARD_W + GAP;
const SPEED = (28 * STEP) / 520;
const CARD_H = CARD_W * (288 / 357);
const RAIL = layout.projects.cards.slice(0, 9);
const TARGET_I = 5;
const X0 = 540 - CARD_W / 2 - TARGET_I * STEP + 92.4 * SPEED;

const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const src = interpolate(frame, [0, 40, 85, 135], [0, 88, 97, 207], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const dx = src * SPEED;
  return (
    <AbsoluteFill style={{ backgroundColor: '#f9f6f1', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: SAFE_CY - CARD_H / 2, transform: `translateX(${-dx + X0}px)` }}>
        {Array.from({ length: 16 }).map((_, k) => {
          const c = RAIL[k % RAIL.length];
          const isTarget = k === TARGET_I;
          return (
            <Img
              key={k}
              src={staticFile(`textures/live/${isTarget ? 'card4-hires.png' : c.file}`)}
              style={{ position: 'absolute', left: k * STEP, top: isTarget ? -22 : 0, width: CARD_W, borderRadius: 16, boxShadow: isTarget ? '0 10px 32px rgba(31,28,23,0.18)' : '0 4px 16px rgba(31,28,23,0.10)' }}
            />
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

export const SpeedRampRealVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const fast = frame < 42 || frame > 83;
  return fast ? (
    <CameraMotionBlur shutterAngle={200} samples={20}>
      <Scene />
    </CameraMotionBlur>
  ) : (
    <Scene />
  );
};
