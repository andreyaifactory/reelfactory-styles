import React, { useEffect, useState } from 'react';
import { continueRender, delayRender, staticFile } from 'remotion';

// Шрифты пака из его же файлов (fonts/ → public/<base>/). Системным PT Serif не доверяем:
// на Windows его нет, и текст молча уехал бы на Georgia. Кадры ждут, пока шрифты не загрузятся.
const FACES: Array<[family: string, file: string, weight: string, style: string]> = [
  ['PT Serif', 'pt-serif-400.ttf', '400', 'normal'],
  ['PT Serif', 'pt-serif-700.ttf', '700', 'normal'],
  ['PT Serif', 'pt-serif-400-italic.ttf', '400', 'italic'],
  ['PT Serif', 'pt-serif-700-italic.ttf', '700', 'italic'],
  ['PT Mono', 'pt-mono-400.ttf', '400', 'normal'],
];

export const PaperFonts: React.FC<{ base?: string; children: React.ReactNode }> = ({ base = 'fonts', children }) => {
  const [handle] = useState(() => delayRender('Шрифты «Бумажной печати»'));

  useEffect(() => {
    Promise.all(
      FACES.map(([family, file, weight, style]) =>
        new FontFace(family, `url(${staticFile(`${base}/${file}`)})`, { weight, style }).load().then((face) => {
          document.fonts.add(face);
        }),
      ),
    )
      .then(() => continueRender(handle))
      .catch(() => continueRender(handle));
  }, [base, handle]);

  return <>{children}</>;
};
