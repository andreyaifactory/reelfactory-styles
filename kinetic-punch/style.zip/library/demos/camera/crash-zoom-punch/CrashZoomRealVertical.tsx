// crash-zoom-punch · 竖版 9:16（1080×1920）。
// 保留：0–40 全景 hold → 40–46 急推 6f（bezier 0.55,0,0.7,1）→ 46–51 过冲回弹 → 51–120 特写静止；blur 只包 38–48 急推段。
// 竖版：全景 = 整页按画宽缩放（0.62，页面 1190 宽、1083 高，页心对准安全区中心）；
// 急推峰值 2.6 → 2.6、回弹落 2.45（card4 357→875 宽，竖画内满宽特写），卡心推到安全区中心 (540, 835)。
// 以下为横版原注释：
// crash-zoom 急推——真实 projects 页全景一拍推到 card4（高清纹理槽位）。
// 节拍：0–40 全景 hold → 40–46 急推 6f（ease-in，峰值放大 2.6x）→ 46–51 过冲回弹（2.6→2.45）→ 51–120 特写 hold 真静止。
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame, Easing } from 'remotion';
import { CameraMotionBlur } from '@remotion/motion-blur';
import layout from '../../_textures/live-layout.json';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const CRASHZOOM_VERTICAL_DUR = 120;
const C4 = layout.projects.cards[3];
const TARGET = { cx: C4.x + C4.w / 2, cy: C4.y + C4.h / 2 };
const WIDE = { z: 0.62, cx: 960, cy: layout.projects.pageH / 2 };

const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const cl = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
  const zoom = interpolate(frame, [40, 46, 51], [WIDE.z, 2.6, 2.45], { ...cl, easing: Easing.bezier(0.55, 0, 0.7, 1) });
  const cx = interpolate(frame, [40, 46], [WIDE.cx, TARGET.cx], { ...cl, easing: Easing.in(Easing.quad) });
  const cy = interpolate(frame, [40, 46], [WIDE.cy, TARGET.cy], { ...cl, easing: Easing.in(Easing.quad) });
  return (
    <AbsoluteFill style={{ backgroundColor: '#f9f6f1', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', width: 1920, height: layout.projects.pageH, transform: `translate(${540 - cx * zoom}px, ${SAFE_CY - cy * zoom}px) scale(${zoom})`, transformOrigin: '0 0' }}>
        <Img src={staticFile('textures/live/projects-full.png')} style={{ position: 'absolute', width: 1920 }} />
        <Img src={staticFile('textures/live/card4-hires.png')} style={{ position: 'absolute', left: C4.x, top: C4.y, width: C4.w, height: C4.h }} />
      </div>
    </AbsoluteFill>
  );
};

export const CrashZoomRealVertical: React.FC = () => {
  const frame = useCurrentFrame();
  return frame >= 38 && frame <= 48 ? (
    <CameraMotionBlur shutterAngle={200} samples={20}>
      <Scene />
    </CameraMotionBlur>
  ) : (
    <Scene />
  );
};
