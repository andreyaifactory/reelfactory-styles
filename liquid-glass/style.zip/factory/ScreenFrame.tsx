import React from 'react';
import { useCurrentFrame } from 'remotion';
import { IrisRim, Sheen } from '../kit/kit';

/**
 * Оправа реального скрина — толстая стеклянная капсула: кромка стекла вокруг
 * снимка, радужный контур, блик по стеклу в начале, верхний отсвет. Матовость
 * нарисована заливкой, а не размытием фона: ядро ведёт появление прозрачностью,
 * а она гасит `backdrop-filter`. Движение снимка внутри ведёт ядро.
 */
export const ScreenFrame: React.FC<{ width: number; height: number; children: React.ReactNode }> = ({
  width,
  height,
  children,
}) => {
  const frame = useCurrentFrame();
  const rim = 16;
  const r = 44;
  return (
    <div style={{ position: 'relative', width, height }}>
      <div
        style={{
          position: 'absolute',
          inset: -rim,
          borderRadius: r + rim,
          background:
            'linear-gradient(155deg, rgba(255,255,255,0.30) 0%, rgba(206,196,255,0.14) 38%, rgba(40,26,96,0.55) 66%, rgba(255,255,255,0.20) 100%), rgba(22,15,52,0.85)',
          border: '1.5px solid rgba(255,255,255,0.28)',
          boxShadow: 'inset 0 1.5px 0 rgba(255,255,255,0.65), 0 30px 70px rgba(4,2,20,0.55)',
        }}
      >
        <IrisRim f={frame} r={r + rim} opacity={0.65} />
      </div>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          borderRadius: r,
          overflow: 'hidden',
          background: '#000',
          boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.25)',
        }}
      >
        {children}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background:
              'linear-gradient(160deg, rgba(255,255,255,0.16) 0%, rgba(255,255,255,0) 26%, rgba(255,255,255,0) 74%, rgba(255,255,255,0.07) 100%)',
            pointerEvents: 'none',
          }}
        />
        <Sheen f={frame} at={10} dur={22} strength={0.26} />
      </div>
    </div>
  );
};
