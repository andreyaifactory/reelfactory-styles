import React, { createContext, useContext, useEffect, useState } from 'react';
import { AbsoluteFill, continueRender, delayRender, staticFile } from 'remotion';
// Кит пака «Жидкое стекло»: свет течёт, стекло проявляется из тумана, капли сливаются.
// Всё детерминированно (без Math.random/Date.now), кадр 1080×1920.
import { E, beatF, clamp01, lerp, seg, squash } from './timeline';

export { E, beatF, lerp, seg, clamp01 };

// ── Шрифты (OFL, лежат в public/glass/fonts) ────────────────────────────────
// Загрузка — компонентом, а не при импорте модуля: delayRender на уровне модуля
// в многопоточном рендере не снимается и роняет его по таймауту. Stage оборачивает
// себя сам; в чужом проекте корень композиции оборачивается в GlassFonts.
const FACES: Array<[family: string, file: string, weight: string]> = [
  ['Unbounded', 'Unbounded.ttf', '200 900'],
  ['Manrope', 'Manrope.ttf', '200 800'],
];

export const GlassFonts: React.FC<{ base?: string; children: React.ReactNode }> = ({ base = 'glass/fonts', children }) => {
  const [handle] = useState(() => delayRender('Шрифты «Жидкого стекла»'));
  useEffect(() => {
    Promise.all(
      FACES.map(([family, file, weight]) =>
        new FontFace(family, `url(${staticFile(`${base}/${file}`)}) format('truetype')`, { weight }).load().then((face) => {
          document.fonts.add(face);
        }),
      ),
    )
      .then(() => continueRender(handle))
      .catch(() => continueRender(handle));
  }, [base, handle]);
  return <>{children}</>;
};
export const DISPLAY = '"Unbounded", "Manrope", system-ui, sans-serif';
export const TEXT = '"Manrope", system-ui, -apple-system, sans-serif';

// ── Токены ──────────────────────────────────────────────────────────────────
export const C = {
  // «Ночь» — основная тема
  bg: '#07060d',
  bg2: '#110d22',
  text: '#f7f5ff',
  muted: 'rgba(247,245,255,0.64)',
  dim: 'rgba(247,245,255,0.38)',
  cyan: '#46e0ff',
  violet: '#8f6bff',
  pink: '#ff8fd2',
  peach: '#ffbe94',
  // «Жемчуг» — светлая тема
  pearl: '#eceef7',
  pearl2: '#dfe1f0',
  ink: '#15121f',
  inkMuted: 'rgba(21,18,31,0.6)',
};
// Перелив: только свет (фон, кромка, блик) и ОДНО акцентное слово в сцене
export const IRIS = `linear-gradient(100deg, ${C.cyan} 0%, ${C.violet} 38%, ${C.pink} 70%, ${C.peach} 100%)`;
export const IRIS_STOPS = [C.cyan, C.violet, C.pink, C.peach];

// Безопасная зона Reels 1080×1920
export const SAFE = { top: 230, bottom: 1440, left: 60, right: 1020, buttonsX: 940, buttonsY: 1000, cy: 835 } as const;

export type Theme = 'night' | 'pearl';
const ThemeCtx = createContext<Theme>('night');
export const useTheme = () => useContext(ThemeCtx);

export const rnd = (seed: number) => {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

const svgUri = (s: string) => `url("data:image/svg+xml;utf8,${encodeURIComponent(s)}")`;
const GRAIN = svgUri(
  `<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' seed='4' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.5 0'/></filter><rect width='100%' height='100%' filter='url(#n)'/></svg>`,
);
// Конденсат: россыпь капель для запотевшего стекла (статичная текстура)
const DROPLETS = (() => {
  let s = '';
  for (let i = 0; i < 140; i++) {
    const x = rnd(i * 3.1) * 1080;
    const y = rnd(i * 7.7 + 2) * 1920;
    const r = 2 + Math.pow(rnd(i * 1.9 + 5), 3) * 14;
    s += `<circle cx='${x.toFixed(0)}' cy='${y.toFixed(0)}' r='${r.toFixed(1)}' fill='rgba(255,255,255,0.22)'/><circle cx='${(x - r * 0.3).toFixed(0)}' cy='${(y - r * 0.35).toFixed(0)}' r='${(r * 0.32).toFixed(1)}' fill='rgba(255,255,255,0.55)'/>`;
  }
  return svgUri(`<svg xmlns='http://www.w3.org/2000/svg' width='1080' height='1920'>${s}</svg>`);
})();

// ── Сцена и фон ─────────────────────────────────────────────────────────────
/** Корень кадра: тема, шрифт, обрезка. Свет и стекло кладутся внутрь. */
export const Stage: React.FC<{ theme?: Theme; children: React.ReactNode; style?: React.CSSProperties }> = ({ theme = 'night', children, style }) => (
  <GlassFonts>
    <ThemeCtx.Provider value={theme}>
      <AbsoluteFill style={{ background: theme === 'night' ? C.bg : C.pearl, color: theme === 'night' ? C.text : C.ink, fontFamily: TEXT, overflow: 'hidden', WebkitFontSmoothing: 'antialiased', ...style }}>
        {children}
      </AbsoluteFill>
    </ThemeCtx.Provider>
  </GlassFonts>
);

/** Жидкий свет: 4 размытых пятна перелива медленно текут и дышат; зерно и виньетка. Фон без исходников. */
export const Aurora: React.FC<{ f: number; theme?: Theme; hue?: number; energy?: number; flip?: number; beats?: number[]; dim?: number }> = ({ f, theme, hue = 0, energy = 1, flip, beats = [], dim = 1 }) => {
  const pulse = beats.reduce((a, b) => a + breath(f, b), 0);
  const th = useTheme();
  const t = theme ?? th;
  const night = t === 'night';
  // flip: кадр, на котором свет «переливается» в другую гамму (как aurora-bloom-bg-flip)
  const k = flip !== undefined ? seg(f, flip, flip + 14, E.flow) : 0;
  const blobs = [
    { c: C.violet, x: 0.18, y: 0.22, r: 470 },
    { c: C.cyan, x: 0.86, y: 0.42, r: 400 },
    { c: C.pink, x: 0.22, y: 0.74, r: 430 },
    { c: C.peach, x: 0.8, y: 0.95, r: 380 },
  ];
  return (
    <AbsoluteFill style={{ background: night ? `radial-gradient(1400px 1600px at 50% 40%, ${C.bg2}, ${C.bg} 70%)` : `radial-gradient(1400px 1600px at 50% 40%, #f8f8fd, ${C.pearl2} 75%)` }}>
      <AbsoluteFill style={{ filter: `blur(${night ? 120 : 130}px) saturate(${night ? 1.2 : 1.1})`, opacity: (night ? 0.58 : 0.55) * dim * (1 + 0.22 * Math.min(1, pulse)), transform: `rotate(${hue + k * 140}deg) scale(${1.25 + 0.05 * Math.min(1, pulse)})` }}>
        {blobs.map((b, i) => {
          const sp = 0.011 + i * 0.003;
          const x = (b.x + 0.09 * energy * Math.sin(f * sp + i * 1.7)) * 1080;
          const y = (b.y + 0.06 * energy * Math.cos(f * sp * 1.3 + i * 2.3)) * 1920;
          const r = b.r * (1 + 0.12 * Math.sin(f * 0.02 + i));
          return <div key={i} style={{ position: 'absolute', left: x - r, top: y - r, width: r * 2, height: r * 2, borderRadius: '50%', background: b.c }} />;
        })}
      </AbsoluteFill>
      <AbsoluteFill style={{ backgroundImage: GRAIN, opacity: night ? 0.06 : 0.09, mixBlendMode: night ? 'screen' : 'multiply' }} />
      <AbsoluteFill style={{ boxShadow: night ? 'inset 0 0 260px rgba(0,0,0,0.65)' : 'inset 0 0 240px rgba(90,80,150,0.14)' }} />
    </AbsoluteFill>
  );
};

// ── Камера ──────────────────────────────────────────────────────────────────
type Cam = { x: number; y: number; s: number };
const CamCtx = createContext<Cam>({ x: 0, y: 0, s: 1 });

/** Вдох линзы на акценте: подъём 6f, затухание ~18f. */
export const breath = (f: number, at: number) => {
  const t = f - at;
  if (t < 0) return 0;
  if (t < 6) return E.outQuint(t / 6);
  return Math.exp(-(t - 6) / 10);
};

/** Камера-парение: дрейф по воздуху, медленный наезд за сцену, «вдох» на каждом акценте. Слои Layer z дают параллакс. */
export const FloatCam: React.FC<{ f: number; dur: number; from?: number; push?: [number, number]; accents?: number[]; amp?: number; children: React.ReactNode }> = ({ f, dur, from = 0, push = [1, 1.05], accents = [], amp = 1, children }) => {
  const x = amp * (8 * Math.sin(f * 0.021 + 1) + 4 * Math.sin(f * 0.047));
  const y = amp * 10 * Math.sin(f * 0.017 + 2);
  const rot = amp * 0.25 * Math.sin(f * 0.013);
  const s = lerp(seg(f, from, from + dur, E.inOutCubic), push[0], push[1]) + accents.reduce((a, at) => a + 0.026 * breath(f, at), 0);
  return (
    <CamCtx.Provider value={{ x, y, s }}>
      <AbsoluteFill style={{ transform: `translate(${x}px, ${y}px) rotate(${rot}deg) scale(${s})`, transformOrigin: `540px ${SAFE.cy}px` }}>{children}</AbsoluteFill>
    </CamCtx.Provider>
  );
};

/** Слой глубины внутри FloatCam: z>1 ближе (сильнее смещается), z<1 дальше. */
export const Layer: React.FC<{ z: number; children: React.ReactNode }> = ({ z, children }) => {
  const c = useContext(CamCtx);
  return <AbsoluteFill style={{ transform: `translate(${c.x * (z - 1) * 1.6}px, ${c.y * (z - 1) * 1.6}px) scale(${1 + (c.s - 1) * (z - 1) * 0.8})`, transformOrigin: `540px ${SAFE.cy}px` }}>{children}</AbsoluteFill>;
};

// ── Стекло ──────────────────────────────────────────────────────────────────
/** Материал стеклянной плашки (фон, кромка, тень) для темы. */
export const glassSkin = (t: Theme, frost = 1): React.CSSProperties =>
  t === 'night'
    ? {
        background: 'linear-gradient(155deg, rgba(255,255,255,0.17) 0%, rgba(255,255,255,0.05) 38%, rgba(16,10,40,0.16) 66%, rgba(255,255,255,0.09) 100%)',
        backdropFilter: `blur(${28 * frost}px) saturate(${1 + 0.7 * frost})`,
        WebkitBackdropFilter: `blur(${28 * frost}px) saturate(${1 + 0.7 * frost})`,
        border: '1.5px solid rgba(255,255,255,0.24)',
        boxShadow: 'inset 0 1.5px 0 rgba(255,255,255,0.6), inset 0 -14px 34px rgba(255,255,255,0.05), 0 30px 70px rgba(4,2,20,0.45)',
      }
    : {
        background: 'linear-gradient(155deg, rgba(255,255,255,0.72) 0%, rgba(255,255,255,0.38) 45%, rgba(255,255,255,0.28) 70%, rgba(255,255,255,0.5) 100%)',
        backdropFilter: `blur(${26 * frost}px) saturate(${1 + 0.5 * frost})`,
        WebkitBackdropFilter: `blur(${26 * frost}px) saturate(${1 + 0.5 * frost})`,
        border: '1.5px solid rgba(255,255,255,0.85)',
        boxShadow: 'inset 0 1.5px 0 rgba(255,255,255,1), 0 26px 60px rgba(70,60,140,0.18)',
      };

/** Радужная кромка: тонкий переливающийся контур, медленно вращается. */
export const IrisRim: React.FC<{ f: number; r: number; w?: number; opacity?: number }> = ({ f, r, w = 2, opacity = 0.6 }) => (
  <div
    style={{
      position: 'absolute',
      inset: -1.5,
      borderRadius: r,
      padding: w,
      background: `conic-gradient(from ${f * 1.6}deg, ${C.cyan}, ${C.violet}, ${C.pink}, ${C.peach}, rgba(255,255,255,0.1), ${C.cyan})`,
      WebkitMask: 'linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)',
      WebkitMaskComposite: 'xor',
      maskComposite: 'exclude',
      opacity,
      pointerEvents: 'none',
    }}
  />
);

/** Блик: светлая полоса пробегает по стеклу за 18f. */
export const Sheen: React.FC<{ f: number; at: number; dur?: number; strength?: number }> = ({ f, at, dur = 18, strength = 0.38 }) => {
  const p = seg(f, at, at + dur, E.flow);
  if (p <= 0 || p >= 1) return null;
  return (
    <div style={{ position: 'absolute', inset: 0, borderRadius: 'inherit', overflow: 'hidden', pointerEvents: 'none' }}>
      <div style={{ position: 'absolute', top: '-40%', bottom: '-40%', width: '45%', left: `${lerp(p, -60, 120)}%`, transform: 'rotate(18deg)', background: `linear-gradient(90deg, rgba(255,255,255,0), rgba(255,255,255,${strength}), rgba(255,255,255,0))` }} />
    </div>
  );
};

/**
 * Стеклянная плашка. Появление — «конденсация»: стекло мутнеет из прозрачного, капля-пружина 0.9→1;
 * уход (out) — «испарение»: туман тает, плашка поднимается и уменьшается.
 */
export const Glass: React.FC<{
  f: number;
  at?: number;
  out?: number;
  x: number;
  y: number;
  w: number;
  h: number | 'auto';
  r?: number;
  rim?: boolean;
  sheenAt?: number;
  pad?: number | string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ f, at = 0, out, x, y, w, h, r = 44, rim = true, sheenAt, pad = 0, style, children }) => {
  const t = useTheme();
  const p = seg(f, at, at + 20, (v) => v);
  const sc = lerp(E.jelly(p), 0.9, 1);
  const op = seg(f, at, at + 8);
  const q = out !== undefined ? seg(f, out, out + 12, E.inCubic) : 0;
  if (op <= 0 || q >= 1) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        height: h,
        borderRadius: r,
        padding: pad,
        boxSizing: 'border-box',
        ...glassSkin(t, E.outCubic(p)),
        opacity: op * (1 - q),
        transform: `translateY(${-30 * q}px) scale(${sc * (1 - 0.06 * q)})`,
        ...style,
      }}
    >
      {rim && <IrisRim f={f} r={r} opacity={(t === 'night' ? 0.55 : 0.7) * op} />}
      {sheenAt !== undefined && <Sheen f={f} at={sheenAt} />}
      {children}
    </div>
  );
};

// ── Текст ───────────────────────────────────────────────────────────────────
/** Стиль акцентного слова: перелив внутри букв + мягкое свечение. */
export const irisText = (f = 0): React.CSSProperties => ({
  backgroundImage: IRIS,
  backgroundSize: '220% 100%',
  backgroundPosition: `${50 + 40 * Math.sin(f * 0.035)}% 50%`,
  WebkitBackgroundClip: 'text',
  backgroundClip: 'text',
  color: 'transparent',
});

/**
 * Конденсация текста: каждое слово проступает из тумана (blur 14→0, подъём 26px, 1.06→1), шаг stagger.
 * *слово* — акцент переливом; \n — перенос строки. out — испарение слов (blur вверх).
 */
export const Condense: React.FC<{
  f: number;
  at: number;
  text: string;
  size?: number;
  weight?: number;
  font?: 'display' | 'text';
  align?: 'left' | 'center';
  stagger?: number;
  dur?: number;
  out?: number;
  color?: string;
  lh?: number;
  tracking?: string;
  style?: React.CSSProperties;
}> = ({ f, at, text, size = 96, weight, font = 'display', align = 'left', stagger = 3.5, dur = 14, out, color, lh = 1.08, tracking, style }) => {
  const t = useTheme();
  const lines = text.split('\n');
  let idx = 0;
  const q = out !== undefined ? seg(f, out, out + 12, E.inCubic) : 0;
  return (
    <div style={{ fontFamily: font === 'display' ? DISPLAY : TEXT, fontSize: size, fontWeight: weight ?? (font === 'display' ? 600 : 700), lineHeight: lh, letterSpacing: tracking ?? (font === 'display' ? '-0.03em' : '-0.01em'), color: color ?? (t === 'night' ? C.text : C.ink), textAlign: align, ...style }}>
      {lines.map((line, li) => (
        <div key={li} style={{ display: 'flex', flexWrap: 'wrap', justifyContent: align === 'center' ? 'center' : 'flex-start', columnGap: '0.26em' }}>
          {line.split(' ').filter(Boolean).map((raw, wi) => {
            const accent = raw.startsWith('*') && raw.replace(/[.,!?:;»]+$/, '').endsWith('*');
            const word = raw.replace(/\*/g, '');
            const d = at + idx++ * stagger;
            const p = seg(f, d, d + dur, E.glide);
            const blur = 14 * (1 - p) + 12 * q;
            return (
              <span
                key={wi}
                style={{
                  display: 'inline-block',
                  opacity: p * (1 - q),
                  filter: `blur(${blur}px)${accent ? ` drop-shadow(0 0 ${Math.round(size * 0.22)}px rgba(143,107,255,${t === 'night' ? 0.5 : 0.3}))` : ''}`,
                  transform: `translateY(${26 * (1 - p) - 24 * q}px) scale(${1.06 - 0.06 * p})`,
                  ...(accent ? irisText(f) : null),
                  paddingBottom: '0.08em',
                }}
              >
                {word}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

/**
 * Стеклянный заголовок: буквы как толстое светлое стекло — молочно-белая заливка без тёмных зон (белый → лаванда),
 * тонкая светлая кромка, переливающееся свечение вокруг, блик пробегает по буквам. Проступает из тумана с лёгким наклоном.
 */
export const GlassTitle: React.FC<{ f: number; at: number; text: string; size?: number; sheenAt?: number; align?: 'left' | 'center'; font?: 'display' | 'text'; style?: React.CSSProperties }> = ({ f, at, text, size = 150, sheenAt, align = 'center', font = 'text', style }) => {
  const p = seg(f, at, at + 22, E.glide);
  const sh = sheenAt !== undefined ? seg(f, sheenAt, sheenAt + 20, E.flow) : -1;
  const line: React.CSSProperties = {
    display: 'inline-block',
    fontFamily: font === 'text' ? TEXT : DISPLAY,
    fontWeight: 800,
    fontSize: size,
    lineHeight: 1.0,
    letterSpacing: font === 'text' ? '-0.035em' : '-0.04em',
    padding: '0.04em 0.06em 0.14em',
    whiteSpace: 'nowrap',
  };
  const glow = 0.8 + 0.2 * Math.sin(f * 0.06);
  return (
    <div style={{ position: 'relative', textAlign: align, opacity: p, filter: `blur(${16 * (1 - p)}px)`, transform: `perspective(1200px) rotateX(${18 * (1 - p)}deg) translateY(${40 * (1 - p)}px) scale(${1.08 - 0.08 * p})`, ...style }}>
      {text.split('\n').map((ln, i) => (
        <div key={i} style={{ position: 'relative', marginTop: i ? -size * 0.12 : 0 }}>
          {/* свечение-перелив позади букв */}
          <span aria-hidden style={{ ...line, position: 'absolute', left: 0, right: 0, top: 0, textAlign: align, ...irisText(f), filter: `blur(${size * 0.16}px)`, opacity: 0.75 * glow }}>{ln}</span>
          {/* тело стекла */}
          <span
            style={{
              ...line,
              position: 'relative',
              backgroundImage: 'linear-gradient(180deg, rgba(255,255,255,1) 0%, rgba(246,243,255,0.96) 45%, rgba(222,214,255,0.92) 100%)',
              WebkitBackgroundClip: 'text',
              backgroundClip: 'text',
              color: 'transparent',
              WebkitTextStroke: '1.5px rgba(255,255,255,0.85)',
              filter: 'drop-shadow(0 6px 16px rgba(18,8,56,0.45))',
            }}
          >
            {ln}
          </span>
          {sh > 0 && sh < 1 && (
            <span style={{ ...line, position: 'absolute', left: 0, right: 0, top: 0, textAlign: align, backgroundImage: `linear-gradient(105deg, transparent ${lerp(sh, -30, 100)}%, rgba(255,255,255,1) ${lerp(sh, -20, 110)}%, transparent ${lerp(sh, -10, 120)}%)`, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>{ln}</span>
          )}
        </div>
      ))}
    </div>
  );
};

// ── Капли ───────────────────────────────────────────────────────────────────
/**
 * Капля-пилюля: капля падает (7f), расплющивается в стеклянную пилюлю (пружина), текст конденсируется.
 * x — центр по горизонтали, y — верх. out — капля испаряется.
 */
export const Drop: React.FC<{ f: number; at: number; x: number; y: number; w: number; h?: number; label: string; size?: number; icon?: React.ReactNode; accent?: boolean; out?: number }> = ({ f, at, x, y, w, h = 104, label, size, icon, accent, out }) => {
  const t = useTheme();
  const fall = seg(f, at, at + 7, E.inCubic);
  if (f < at) return null;
  const d0 = h * 0.42;
  const spread = seg(f, at + 7, at + 27);
  const wj = E.jelly(spread);
  const width = lerp(wj, d0, w);
  const height = spread > 0 ? lerp(wj, d0, h) : d0;
  const v = spread > 0 ? (1 - spread) * 4 : fall * 6;
  const [sx, sy] = spread > 0 ? [1, 1] : squash(v, 0.05).reverse() as [number, number];
  const top = spread > 0 ? y + (h - height) / 2 : lerp(fall, y - 160, y + (h - d0) / 2);
  const q = out !== undefined ? seg(f, out, out + 12, E.inCubic) : 0;
  const lp = seg(f, at + 12, at + 26, E.glide);
  return (
    <div
      style={{
        position: 'absolute',
        left: x - width / 2,
        top,
        width,
        height,
        borderRadius: height / 2,
        ...glassSkin(t),
        ...(accent ? { background: `linear-gradient(135deg, rgba(70,224,255,0.38), rgba(143,107,255,0.42) 50%, rgba(255,143,210,0.36))` } : null),
        transform: `scale(${sx * (1 - 0.3 * q)}, ${sy * (1 - 0.3 * q)})`,
        opacity: 1 - q,
        filter: q > 0 ? `blur(${10 * q}px)` : undefined,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 18,
        overflow: 'hidden',
        whiteSpace: 'nowrap',
      }}
    >
      <IrisRim f={f} r={height / 2} opacity={0.6} />
      {icon && <span style={{ opacity: lp, display: 'flex' }}>{icon}</span>}
      <span style={{ fontFamily: TEXT, fontWeight: 700, fontSize: size ?? h * 0.4, letterSpacing: '-0.01em', opacity: lp, filter: `blur(${8 * (1 - lp)}px)`, color: t === 'night' ? C.text : C.ink }}>{label}</span>
    </div>
  );
};

/** SVG-фильтр «липкой жидкости»: соседние пятна сливаются как ртуть. Вставить один раз в сцену. */
export const GooDefs: React.FC<{ id?: string; k?: number }> = ({ id = 'lg-goo', k = 16 }) => (
  <svg width={0} height={0} style={{ position: 'absolute' }}>
    <defs>
      <filter id={id} x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur in="SourceGraphic" stdDeviation={k} result="b" />
        <feColorMatrix in="b" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -10" result="g" />
        <feComposite in="SourceGraphic" in2="g" operator="atop" />
      </filter>
    </defs>
  </svg>
);

const blobFill = `radial-gradient(circle at 34% 30%, rgba(255,255,255,0.95) 0%, ${C.pink} 18%, ${C.violet} 52%, #3a2ab0 100%)`;

/**
 * Слияние капель: N капель стекаются в одну (липкая жидкость), капля разливается в стеклянную пилюлю с текстом.
 * Для «итог», «вместе», «всё в одном».
 */
export const Merge: React.FC<{ f: number; at: number; cx: number; cy: number; from: [number, number, number][]; label: string; w?: number; h?: number; size?: number }> = ({ f, at, cx, cy, from, label, w = 640, h = 132, size }) => {
  const flowP = seg(f, at, at + 22, E.flow);
  if (f < at) return null;
  const pill = seg(f, at + 22, at + 42);
  const blobOp = 1 - seg(f, at + 30, at + 40);
  const R = 70 + 30 * E.jelly(seg(f, at + 14, at + 30));
  return (
    <>
      <GooDefs id={`goo-${at}`} />
      <div style={{ position: 'absolute', inset: 0, filter: `url(#goo-${at})`, opacity: blobOp }}>
        {from.map(([x, y, r], i) => {
          const px = lerp(flowP, x, cx);
          const py = lerp(flowP, y, cy);
          const rr = lerp(flowP, r, R * 0.7);
          const wob = 1 + 0.06 * Math.sin(f * 0.4 + i) * (1 - flowP);
          return <div key={i} style={{ position: 'absolute', left: px - rr, top: py - rr, width: rr * 2, height: rr * 2 * wob, borderRadius: '50%', background: blobFill }} />;
        })}
        {flowP > 0.6 && <div style={{ position: 'absolute', left: cx - R, top: cy - R, width: R * 2, height: R * 2, borderRadius: '50%', background: blobFill }} />}
      </div>
      {pill > 0 && (
        <div style={{ position: 'absolute', left: 0, top: 0 }}>
          <Drop f={f} at={at + 15} x={cx} y={cy - h / 2} w={w} h={h} label={label} size={size} accent />
        </div>
      )}
    </>
  );
};

// ── Линза ───────────────────────────────────────────────────────────────────
/**
 * Линза: круг толстого стекла плывёт по кадру и увеличивает то, что под ним (content рисуется второй раз внутри).
 * path — [x, y] в начале и в конце движения.
 */
export const Lens: React.FC<{ f: number; at: number; dur?: number; path: [[number, number], [number, number]]; r?: number; zoom?: number; content: React.ReactNode; out?: number }> = ({ f, at, dur = 30, path, r = 190, zoom = 1.7, content, out }) => {
  const p = seg(f, at, at + 16);
  if (p <= 0) return null;
  const m = seg(f, at + 8, at + 8 + dur, E.flow);
  const q = out !== undefined ? seg(f, out, out + 12, E.inCubic) : 0;
  const s = E.jelly(p) * (1 - q);
  const cx = lerp(m, path[0][0], path[1][0]);
  const cy = lerp(m, path[0][1], path[1][1]);
  const R = r * s;
  if (R < 1) return null;
  return (
    <div style={{ position: 'absolute', left: cx - R, top: cy - R, width: R * 2, height: R * 2, borderRadius: '50%', overflow: 'hidden', boxShadow: '0 30px 70px rgba(4,2,20,0.5)' }}>
      <div style={{ position: 'absolute', left: R - cx * zoom, top: R - cy * zoom, width: 1080, height: 1920, transform: `scale(${zoom})`, transformOrigin: '0 0' }}>{content}</div>
      <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: `radial-gradient(circle, rgba(255,255,255,0) 70%, rgba(70,224,255,0.22) 82%, rgba(255,143,210,0.26) 91%, rgba(255,255,255,0.6) 98%)` }} />
      <div style={{ position: 'absolute', left: '16%', top: '10%', width: '42%', height: '22%', borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(255,255,255,0.55), rgba(255,255,255,0) 70%)', transform: 'rotate(-28deg)' }} />
      <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', boxShadow: 'inset 0 0 0 2.5px rgba(255,255,255,0.55), inset 0 -18px 40px rgba(143,107,255,0.25)' }} />
    </div>
  );
};

// ── Чужое внутри стекла ─────────────────────────────────────────────────────
/**
 * Видео (или любой кадр) в толстой стеклянной капсуле. Появление — капля разливается в прямоугольник.
 * children рисуются в координатах капсулы (w×h).
 */
export const Capsule: React.FC<{ f: number; at: number; x: number; y: number; w: number; h: number; r?: number; rim?: number; sheenAt?: number; out?: number; children: React.ReactNode }> = ({ f, at, x, y, w, h, r = 56, rim = 16, sheenAt, out, children }) => {
  const t = useTheme();
  const p = E.jelly(seg(f, at, at + 24));
  const op = seg(f, at, at + 5);
  const q = out !== undefined ? seg(f, out, out + 14, E.inCubic) : 0;
  if (op <= 0 || q >= 1) return null;
  const d = 80;
  const it = Math.max(0, ((h - d) / 2) * (1 - p));
  const il = Math.max(0, ((w - d) / 2) * (1 - p));
  const rr = lerp(clamp01(p), d / 2, r);
  return (
    <div style={{ position: 'absolute', left: x - rim, top: y - rim, width: w + rim * 2, height: h + rim * 2, opacity: op * (1 - q), transform: `scale(${1 - 0.08 * q})`, filter: q > 0 ? `blur(${12 * q}px)` : undefined, clipPath: `inset(${it}px ${il}px round ${rr + rim}px)` }}>
      <div style={{ position: 'absolute', inset: 0, borderRadius: r + rim, ...glassSkin(t) }}>
        <IrisRim f={f} r={r + rim} opacity={0.65} />
      </div>
      <div style={{ position: 'absolute', left: rim, top: rim, width: w, height: h, borderRadius: r, overflow: 'hidden', boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.25)' }}>
        {children}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(160deg, rgba(255,255,255,0.18) 0%, rgba(255,255,255,0) 28%, rgba(255,255,255,0) 72%, rgba(255,255,255,0.08) 100%)' }} />
        {sheenAt !== undefined && <Sheen f={f} at={sheenAt} strength={0.3} />}
      </div>
    </div>
  );
};

/**
 * Видео в круглой капле поверх графики. Круг дышит как жидкость.
 * expandAt — капля разливается на весь кадр, видео становится главным.
 */
export const Bubble: React.FC<{ f: number; at: number; cx: number; cy: number; d?: number; focus?: [number, number]; zoom?: number; expandAt?: number; out?: number; children: React.ReactNode }> = ({ f, at, cx, cy, d = 300, focus = [540, 830], zoom = 0.62, expandAt, out, children }) => {
  const p = E.jelly(seg(f, at, at + 22));
  const e = expandAt !== undefined ? seg(f, expandAt, expandAt + 20, E.flow) : 0;
  const q = out !== undefined ? seg(f, out, out + 12, E.inCubic) : 0;
  if (p <= 0.001 || q >= 1) return null;
  const big = 2300;
  const R = lerp(e, (d / 2) * p * (1 - q), big / 2);
  const X = lerp(e, cx, 540);
  const Y = lerp(e, cy, 960);
  const wob = (1 - e) * 2.5;
  const br = `${50 + wob * Math.sin(f * 0.11)}% ${50 - wob * Math.sin(f * 0.13 + 1)}% ${50 + wob * Math.cos(f * 0.09)}% ${50 - wob * Math.cos(f * 0.12 + 2)}% / ${50 - wob * Math.sin(f * 0.1 + 3)}% ${50 + wob * Math.sin(f * 0.14)}% ${50 - wob * Math.cos(f * 0.1)}% ${50 + wob * Math.cos(f * 0.08 + 1)}%`;
  return (
    <div style={{ position: 'absolute', left: X - R, top: Y - R, width: R * 2, height: R * 2, borderRadius: br, overflow: 'hidden', boxShadow: e < 1 ? `0 30px 60px rgba(4,2,20,${0.5 * (1 - e)}), inset 0 0 0 ${8 * (1 - e)}px rgba(255,255,255,0.22)` : undefined }}>
      {/* содержимое — в координатах полного кадра; точка focus стоит в центре капли, при разливе кадр встаёт на место */}
      <div style={{ position: 'absolute', left: R - lerp(e, focus[0], 540), top: R - lerp(e, focus[1], 960), width: 1080, height: 1920, transform: `scale(${lerp(e, zoom, 1)})`, transformOrigin: `${lerp(e, focus[0], 540)}px ${lerp(e, focus[1], 960)}px` }}>{children}</div>
      {e < 1 && (
        <>
          <div style={{ position: 'absolute', inset: 0, borderRadius: br, background: `radial-gradient(circle, rgba(255,255,255,0) 72%, rgba(70,224,255,${0.25 * (1 - e)}) 86%, rgba(255,143,210,${0.3 * (1 - e)}) 94%, rgba(255,255,255,${0.55 * (1 - e)}) 99%)` }} />
          <div style={{ position: 'absolute', left: '18%', top: '9%', width: '40%', height: '20%', borderRadius: '50%', background: `radial-gradient(ellipse, rgba(255,255,255,${0.5 * (1 - e)}), rgba(255,255,255,0) 70%)`, transform: 'rotate(-30deg)' }} />
        </>
      )}
    </div>
  );
};

/**
 * Разделение кадра жидкой границей: видео сверху, графика снизу. Граница — мениск, колышется
 * при движении и успокаивается. level: от 1920 (весь кадр — верх) до split.
 */
export const Split: React.FC<{ f: number; at: number; split?: number; backAt?: number; top: React.ReactNode; bottom: React.ReactNode }> = ({ f, at, split = 860, backAt, top, bottom }) => {
  const a = seg(f, at, at + 20, E.flow);
  const b = backAt !== undefined ? seg(f, backAt, backAt + 20, E.flow) : 0;
  const level = lerp(a - b, 1920, split);
  const motion = Math.max(seg(f, at, at + 34) < 1 ? 1 - seg(f, at + 10, at + 40) : 0, backAt !== undefined && f >= backAt ? 1 - seg(f, backAt + 10, backAt + 40) : 0);
  const amp = 6 + 22 * motion;
  const N = 36;
  const ys = Array.from({ length: N + 1 }, (_, i) => level + amp * Math.sin((i / N) * Math.PI * 3 + f * 0.16) + amp * 0.4 * Math.sin((i / N) * Math.PI * 7 - f * 0.11));
  const poly = ys.map((y, i) => `${((i / N) * 1080).toFixed(1)}px ${y.toFixed(1)}px`).join(', ');
  const d = ys.map((y, i) => `${i ? 'L' : 'M'}${((i / N) * 1080).toFixed(1)} ${y.toFixed(1)}`).join(' ');
  return (
    <AbsoluteFill>
      <AbsoluteFill>{bottom}</AbsoluteFill>
      <AbsoluteFill style={{ clipPath: `polygon(0px 0px, 1080px 0px, ${poly.split(', ').reverse().join(', ')}, 0px 0px)` }}>{top}</AbsoluteFill>
      <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <defs>
          <linearGradient id={`men-${at}`} x1="0" x2="1">
            {IRIS_STOPS.map((c, i) => (
              <stop key={i} offset={i / 3} stopColor={c} />
            ))}
          </linearGradient>
        </defs>
        <path d={d} stroke={`url(#men-${at})`} strokeWidth={10} fill="none" opacity={0.35} style={{ filter: 'blur(6px)' }} />
        <path d={d} stroke="rgba(255,255,255,0.85)" strokeWidth={3} fill="none" />
      </svg>
    </AbsoluteFill>
  );
};

/**
 * Запотевание: кадр под стеклом мутнеет и покрывается каплями — на стекле крупно ключевая фраза.
 * clearAt — стекло протирают: туман уходит полосой слева направо.
 */
export const Frost: React.FC<{ f: number; at: number; clearAt?: number; children?: React.ReactNode }> = ({ f, at, clearAt, children }) => {
  const t = useTheme();
  const p = seg(f, at, at + 14, E.glide);
  const c = clearAt !== undefined ? seg(f, clearAt, clearAt + 16, E.flow) : 0;
  if (p <= 0 || c >= 1) return null;
  const edge = lerp(c, -20, 120);
  const mask = c > 0 ? `linear-gradient(100deg, transparent ${edge - 14}%, #000 ${edge}%)` : undefined;
  return (
    <AbsoluteFill style={{ WebkitMaskImage: mask, maskImage: mask }}>
      <AbsoluteFill style={{ backdropFilter: `blur(${30 * p}px) saturate(${1 + 0.4 * p})`, WebkitBackdropFilter: `blur(${30 * p}px) saturate(${1 + 0.4 * p})`, background: t === 'night' ? `rgba(14,9,34,${0.42 * p})` : `rgba(255,255,255,${0.3 * p})` }} />
      <AbsoluteFill style={{ backgroundImage: DROPLETS, opacity: 0.85 * p }} />
      {children}
    </AbsoluteFill>
  );
};

// ── Цифра в стекле ──────────────────────────────────────────────────────────
/** Число в стеклянной трубке: жидкий свет наливается до pct (волна на фронте, пузырьки), число проступает и считает. */
export const LiquidStat: React.FC<{ f: number; at: number; x: number; y: number; w?: number; value: number; pct: number; prefix?: string; suffix?: string; label: string }> = ({ f, at, x, y, w = 900, value, pct, prefix = '', suffix = '', label }) => {
  const t = useTheme();
  const fill = seg(f, at + 10, at + 46, E.glide);
  const front = w * pct * fill;
  const H = 150;
  const N = 24;
  const pts = Array.from({ length: N + 1 }, (_, i) => {
    const yy = (i / N) * H;
    const xx = front + (front > 4 ? 10 * Math.sin(yy / 22 + f * 0.35) + 5 * Math.sin(yy / 9 - f * 0.5) : 0);
    return `${xx.toFixed(1)},${yy.toFixed(1)}`;
  });
  const n = Math.round(value * fill);
  const np = seg(f, at + 6, at + 22, E.glide);
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: w }}>
      <div style={{ fontFamily: DISPLAY, fontWeight: 700, fontSize: 168, letterSpacing: '-0.05em', lineHeight: 1, fontVariantNumeric: 'tabular-nums', opacity: np, filter: `blur(${14 * (1 - np)}px)`, ...irisText(f), paddingBottom: 12 }}>
        {prefix}
        {n}
        {suffix}
      </div>
      <Glass f={f} at={at} x={0} y={210} w={w} h={H} r={H / 2} style={{ overflow: 'hidden' }}>
        <svg width={w} height={H} style={{ position: 'absolute', inset: 0, borderRadius: H / 2 }}>
          <defs>
            <linearGradient id={`liq-${at}`} x1="0" x2="1">
              {IRIS_STOPS.map((c, i) => (
                <stop key={i} offset={i / 3} stopColor={c} stopOpacity={0.85} />
              ))}
            </linearGradient>
          </defs>
          <polygon points={`0,0 ${pts.join(' ')} 0,${H}`} fill={`url(#liq-${at})`} />
          {Array.from({ length: 9 }).map((_, i) => {
            const bx = (rnd(i + at) * 0.9 + 0.05) * front;
            const by = H - ((f * (1.2 + rnd(i * 3) * 1.4) + rnd(i * 7) * H) % H);
            return front > 30 ? <circle key={i} cx={bx} cy={by} r={3 + rnd(i * 5) * 5} fill="rgba(255,255,255,0.55)" /> : null;
          })}
          <rect x={0} y={0} width={w} height={H * 0.38} fill="rgba(255,255,255,0.14)" />
        </svg>
      </Glass>
      <div style={{ position: 'absolute', top: 384, left: 0, right: 0, fontFamily: TEXT, fontWeight: 600, fontSize: 46, color: t === 'night' ? C.muted : C.inkMuted, opacity: seg(f, at + 20, at + 34), filter: `blur(${8 * (1 - seg(f, at + 20, at + 34))}px)` }}>{label}</div>
    </div>
  );
};

// ── Финал ───────────────────────────────────────────────────────────────────
/** Финал: капли со всего кадра стекаются в шар, шар разливается в пилюлю-призыв; подпись конденсируется. */
export const Melt: React.FC<{ f: number; at: number; label: string; sub?: string; cy?: number }> = ({ f, at, label, sub, cy = 760 }) => {
  const from: [number, number, number][] = Array.from({ length: 9 }, (_, i) => [140 + rnd(i * 2.3) * 800, 300 + rnd(i * 5.1) * 1050, 26 + rnd(i * 9.7) * 40]);
  return (
    <>
      <Merge f={f} at={at} cx={540} cy={cy} from={from} label={label} w={800} h={170} size={64} />
      {sub && (
        <div style={{ position: 'absolute', top: cy + 150, left: 90, right: 90 }}>
          <Condense f={f} at={at + 44} text={sub} size={44} font="text" weight={600} align="center" />
        </div>
      )}
    </>
  );
};

// ── Переходы ────────────────────────────────────────────────────────────────
type TrProps = { f: number; at: number; dur?: number; a: React.ReactNode; b: React.ReactNode };

/** Стеклянная шторка: толстое матовое стекло проходит снизу вверх, за ним сцена уже другая. 18f. */
export const GlassWipe: React.FC<TrProps> = ({ f, at, dur = 18, a, b }) => {
  if (f < at) return <AbsoluteFill>{a}</AbsoluteFill>;
  if (f >= at + dur) return <AbsoluteFill>{b}</AbsoluteFill>;
  const p = seg(f, at, at + dur, E.flow);
  const yc = lerp(p, 1920 + 420, -420);
  return (
    <AbsoluteFill>
      <AbsoluteFill>{b}</AbsoluteFill>
      <AbsoluteFill style={{ clipPath: `inset(0 0 ${Math.max(0, 1920 - yc)}px 0)` }}>{a}</AbsoluteFill>
      <div style={{ position: 'absolute', left: -200, width: 1480, top: yc - 300, height: 600, transform: 'rotate(-7deg)', backdropFilter: 'blur(40px) saturate(1.6)', WebkitBackdropFilter: 'blur(40px) saturate(1.6)', background: 'linear-gradient(180deg, rgba(255,255,255,0.22), rgba(255,255,255,0.06) 30%, rgba(255,255,255,0.04) 70%, rgba(255,255,255,0.18))', borderTop: '3px solid rgba(255,255,255,0.75)', borderBottom: '2px solid rgba(255,255,255,0.35)', boxShadow: '0 -20px 60px rgba(143,107,255,0.25), 0 20px 60px rgba(70,224,255,0.2)' }}>
        <div style={{ position: 'absolute', left: 0, right: 0, top: 8, height: 26, background: IRIS, opacity: 0.35, filter: 'blur(10px)' }} />
      </div>
    </AbsoluteFill>
  );
};

/** Капля: капля падает в точку и разливается волнистым кругом, внутри — следующая сцена. 20f. */
export const DropReveal: React.FC<TrProps & { x?: number; y?: number }> = ({ f, at, dur = 20, a, b, x = 540, y = 835 }) => {
  if (f < at) return <AbsoluteFill>{a}</AbsoluteFill>;
  if (f >= at + dur) return <AbsoluteFill>{b}</AbsoluteFill>;
  const fall = seg(f, at, at + 6, E.inCubic);
  const p = seg(f, at + 5, at + dur, E.flow);
  const R = lerp(p, 30, 2250);
  const pts = Array.from({ length: 72 }, (_, i) => {
    const th = (i / 72) * Math.PI * 2;
    const r = R * (1 + 0.035 * (1 - p) * Math.sin(5 * th + f * 0.6) + 0.015 * (1 - p) * Math.sin(9 * th - f * 0.4));
    return `${(x + r * Math.cos(th)).toFixed(1)}px ${(y + r * Math.sin(th)).toFixed(1)}px`;
  }).join(', ');
  return (
    <AbsoluteFill>
      <AbsoluteFill>{a}</AbsoluteFill>
      {p > 0 && <AbsoluteFill style={{ clipPath: `polygon(${pts})`, transform: `scale(${lerp(p, 1.08, 1)})`, transformOrigin: `${x}px ${y}px` }}>{b}</AbsoluteFill>}
      {p === 0 && <div style={{ position: 'absolute', left: x - 28, top: lerp(fall, y - 420, y) - 34, width: 56, height: 68, borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%', background: blobFill, boxShadow: '0 0 30px rgba(143,107,255,0.6)' }} />}
      {p > 0 && p < 1 && (
        <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0 }}>
          <circle cx={x} cy={y} r={R} fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth={4} opacity={1 - p} />
          <circle cx={x} cy={y} r={R + 18} fill="none" stroke={C.violet} strokeWidth={16} opacity={0.4 * (1 - p)} style={{ filter: 'blur(8px)' }} />
        </svg>
      )}
    </AbsoluteFill>
  );
};

/** Жидкая волна: кадр плывёт как отражение в воде, на гребне сцена меняется. 22f. */
export const Ripple: React.FC<TrProps> = ({ f, at, dur = 22, a, b }) => {
  if (f < at) return <AbsoluteFill>{a}</AbsoluteFill>;
  if (f >= at + dur) return <AbsoluteFill>{b}</AbsoluteFill>;
  const p = seg(f, at, at + dur);
  const s = Math.sin(Math.PI * p);
  const q = seg(p, 0.38, 0.62, E.inOutCubic);
  const id = `rip-${at}`;
  return (
    <AbsoluteFill>
      <svg width={0} height={0} style={{ position: 'absolute' }}>
        <filter id={id} x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency={`${0.004 + 0.002 * p} ${0.014 + 0.006 * p}`} numOctaves={2} seed={3} result="t" />
          <feDisplacementMap in="SourceGraphic" in2="t" scale={95 * s} xChannelSelector="R" yChannelSelector="G" />
        </filter>
      </svg>
      <AbsoluteFill style={{ filter: `url(#${id}) blur(${4 * s}px)`, transform: `scale(${1 + 0.1 * s})` }}>
        <AbsoluteFill style={{ opacity: 1 - q }}>{a}</AbsoluteFill>
        <AbsoluteFill style={{ opacity: q }}>{b}</AbsoluteFill>
      </AbsoluteFill>
      <AbsoluteFill style={{ background: `linear-gradient(180deg, rgba(70,224,255,${0.08 * s}), rgba(143,107,255,${0.12 * s}))`, mixBlendMode: 'screen' }} />
    </AbsoluteFill>
  );
};

/** Нырок в линзу: в кадре появляется линза со следующей сценой внутри, камера проходит сквозь неё. 22f. */
export const LensDive: React.FC<TrProps & { x?: number; y?: number }> = ({ f, at, dur = 22, a, b, x = 540, y = 835 }) => {
  if (f < at) return <AbsoluteFill>{a}</AbsoluteFill>;
  if (f >= at + dur) return <AbsoluteFill>{b}</AbsoluteFill>;
  const open = E.jelly(seg(f, at, at + 9));
  const dive = seg(f, at + 8, at + dur, E.inOutCubic);
  const R = lerp(dive, 170 * open, 2300);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ transform: `scale(${1 + 0.4 * dive})`, transformOrigin: `${x}px ${y}px`, filter: `blur(${10 * dive}px)` }}>{a}</AbsoluteFill>
      <div style={{ position: 'absolute', left: x - R, top: y - R, width: R * 2, height: R * 2, borderRadius: '50%', overflow: 'hidden', boxShadow: `0 30px 70px rgba(4,2,20,${0.5 * (1 - dive)})` }}>
        <div style={{ position: 'absolute', left: R - 540, top: R - 835, width: 1080, height: 1920, transform: `scale(${lerp(dive, 0.7, 1)})`, transformOrigin: '540px 835px' }}>{b}</div>
        <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: `radial-gradient(circle, rgba(255,255,255,0) 70%, rgba(70,224,255,${0.3 * (1 - dive)}) 84%, rgba(255,143,210,${0.3 * (1 - dive)}) 93%, rgba(255,255,255,${0.65 * (1 - dive)}) 99%)` }} />
      </div>
    </AbsoluteFill>
  );
};

/** Расфокус-вспышка: кадр уходит в мягкий свет, из света проступает следующий. 16f. */
export const Defocus: React.FC<TrProps> = ({ f, at, dur = 16, a, b }) => {
  if (f < at) return <AbsoluteFill>{a}</AbsoluteFill>;
  if (f >= at + dur) return <AbsoluteFill>{b}</AbsoluteFill>;
  const p = seg(f, at, at + dur);
  const s = Math.sin(Math.PI * p);
  const first = p < 0.5;
  const k = first ? E.inCubic(p * 2) : 1 - E.outCubic((p - 0.5) * 2);
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ filter: `blur(${36 * k}px) brightness(${1 + 0.6 * k})`, transform: `scale(${1 + 0.06 * k})` }}>{first ? a : b}</AbsoluteFill>
      <AbsoluteFill style={{ background: `radial-gradient(900px 1100px at 50% 44%, rgba(255,255,255,${0.32 * s}), rgba(143,107,255,${0.18 * s}) 45%, rgba(0,0,0,0) 75%)`, mixBlendMode: 'screen' }} />
    </AbsoluteFill>
  );
};

// ── Кинетика ────────────────────────────────────────────────────────────────
/** Плавная замкнутая кривая через точки (середины отрезков + квадратичные сплайны). */
const smoothClosed = (pts: [number, number][]) => {
  const m = (a: [number, number], b: [number, number]) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
  const n = pts.length;
  const s0 = m(pts[n - 1], pts[0]);
  let d = `M${s0[0].toFixed(1)} ${s0[1].toFixed(1)}`;
  for (let i = 0; i < n; i++) {
    const p = pts[i];
    const q = m(p, pts[(i + 1) % n]);
    d += ` Q${p[0].toFixed(1)} ${p[1].toFixed(1)} ${q[0].toFixed(1)} ${q[1].toFixed(1)}`;
  }
  return d + 'Z';
};

/**
 * Жидкая капля-морф: большая переливающаяся капля всё время перетекает, на каждой доле (beats) вздрагивает волной.
 * Объём даёт свет: ядро перелива, блик сверху слева, тёплая каустика снизу, тонкая светлая кромка. children — поверх по центру.
 */
export const LiquidBlob: React.FC<{ f: number; at: number; cx?: number; cy?: number; r?: number; beats?: number[]; seed?: number; out?: number; children?: React.ReactNode }> = ({ f, at, cx = 540, cy = SAFE.cy, r = 330, beats = [], seed = 1, out, children }) => {
  const p = E.jelly(seg(f, at, at + 26));
  const q = out !== undefined ? seg(f, out, out + 14, E.inCubic) : 0;
  if (p <= 0.001 || q >= 1) return null;
  const R = r * p * (1 - 0.3 * q);
  const N = 72;
  const pts: [number, number][] = Array.from({ length: N }, (_, i) => {
    const th = (i / N) * Math.PI * 2;
    let k = 1 + 0.07 * Math.sin(3 * th + f * 0.031 + seed) + 0.045 * Math.cos(5 * th - f * 0.023 + seed * 2) + 0.05 * Math.sin(2 * th + f * 0.017);
    for (const b of beats) if (f >= b && f < b + 30) k += 0.07 * Math.exp(-(f - b) / 7) * Math.sin(4 * th + b * 0.7 + (f - b) * 0.5);
    return [cx + Math.cos(th) * R * k, cy + Math.sin(th) * R * k * 1.04];
  });
  const d = smoothClosed(pts);
  const id = `lb-${at}-${seed}`;
  return (
    <AbsoluteFill style={{ opacity: 1 - q, filter: q > 0 ? `blur(${14 * q}px)` : undefined }}>
      <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <defs>
          <radialGradient id={`${id}-core`} cx={cx - R * 0.25} cy={cy - R * 0.3} r={R * 1.35} gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#ffffff" />
            <stop offset="0.16" stopColor={C.pink} />
            <stop offset="0.48" stopColor={C.violet} />
            <stop offset="0.8" stopColor="#2b1d8f" />
            <stop offset="1" stopColor="#120a3d" />
          </radialGradient>
          <linearGradient id={`${id}-iris`} x1={cx - R} y1={cy + R} x2={cx + R} y2={cy - R} gradientUnits="userSpaceOnUse" gradientTransform={`rotate(${f * 0.6} ${cx} ${cy})`}>
            <stop offset="0" stopColor={C.cyan} />
            <stop offset="0.45" stopColor={C.violet} stopOpacity="0" />
            <stop offset="0.75" stopColor={C.pink} stopOpacity="0.4" />
            <stop offset="1" stopColor={C.peach} />
          </linearGradient>
          <radialGradient id={`${id}-caus`} cx={cx + R * 0.35} cy={cy + R * 0.55} r={R * 0.6} gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor={C.peach} stopOpacity="0.85" />
            <stop offset="1" stopColor={C.peach} stopOpacity="0" />
          </radialGradient>
          <clipPath id={`${id}-clip`}>
            <path d={d} />
          </clipPath>
        </defs>
        <path d={d} fill={C.violet} opacity={0.55} style={{ filter: 'blur(60px)' }} />
        <path d={d} fill={`url(#${id}-core)`} />
        <g clipPath={`url(#${id}-clip)`}>
          <path d={d} fill={`url(#${id}-iris)`} opacity={0.75} style={{ mixBlendMode: 'screen' }} />
          <circle cx={cx + R * 0.35} cy={cy + R * 0.55} r={R * 0.6} fill={`url(#${id}-caus)`} style={{ mixBlendMode: 'screen' }} />
          <path d={d} fill="none" stroke="#0b0628" strokeWidth={R * 0.12} opacity={0.45} style={{ filter: `blur(${R * 0.05}px)` }} />
          <ellipse cx={cx - R * 0.32} cy={cy - R * 0.45} rx={R * 0.42} ry={R * 0.2} fill="#fff" opacity={0.42} transform={`rotate(-28 ${cx - R * 0.32} ${cy - R * 0.45})`} style={{ filter: `blur(${R * 0.06}px)` }} />
          <ellipse cx={cx - R * 0.42} cy={cy - R * 0.52} rx={R * 0.12} ry={R * 0.05} fill="#fff" opacity={0.9} transform={`rotate(-28 ${cx - R * 0.42} ${cy - R * 0.52})`} />
        </g>
        <path d={d} fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth={2} />
      </svg>
      {children && <div style={{ position: 'absolute', left: cx - 500, width: 1000, top: cy, transform: 'translateY(-50%)', display: 'flex', justifyContent: 'center' }}>{children}</div>}
    </AbsoluteFill>
  );
};

/**
 * Слова в бит на стеклянной плите: толстая плита стекла висит в 3D и на каждой доле поворачивается в другую сторону,
 * старое слово испаряется, новое конденсируется за 7f; за стеклом размыто светится то же слово крупнее — глубина.
 * beats[i] — кадр появления words[i]; *слово* — перелив.
 */
export const BeatWords: React.FC<{ f: number; beats: number[]; words: string[]; cy?: number; w?: number; h?: number; out?: number }> = ({ f, beats, words, cy = SAFE.cy, w = 920, h = 600, out }) => {
  const t = useTheme();
  if (f < beats[0]) return null;
  let i = 0;
  while (i + 1 < beats.length && f >= beats[i + 1]) i++;
  const b = beats[i];
  const swing = (k: number) => (k % 2 ? 1 : -1);
  const turn = seg(f, b, b + 12, E.flow);
  const tilt = lerp(turn, i > 0 ? 15 * swing(i - 1) : 0, 15 * swing(i));
  const shift = lerp(turn, i > 0 ? 34 * swing(i - 1) : 0, 34 * swing(i));
  const q = out !== undefined ? seg(f, out, out + 12, E.inCubic) : 0;
  const word = (k: number) => words[k].replace(/\*/g, '');
  const accent = (k: number) => words[k].startsWith('*');
  const size = (k: number) => Math.min(170, 1500 / Math.max(4, word(k).length));
  const pin = seg(f, b, b + 7, E.glide);
  const prev = i > 0 && f < b + 6 ? i - 1 : -1;
  const pout = seg(f, b, b + 6, E.inCubic);
  const Word: React.FC<{ k: number; p: number; o: number; ghost?: boolean }> = ({ k, p, o, ghost }) => (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: '50%',
        textAlign: 'center',
        fontFamily: DISPLAY,
        fontWeight: 700,
        fontSize: size(k) * (ghost ? 1.7 : 1),
        letterSpacing: '-0.04em',
        lineHeight: 1,
        whiteSpace: 'nowrap',
        color: t === 'night' ? C.text : C.ink,
        ...(accent(k) || ghost ? irisText(f) : null),
        opacity: (ghost ? 0.32 : 1) * p * (1 - o),
        filter: `blur(${(ghost ? 44 : 0) + 18 * (1 - p) + 14 * o}px)`,
        transform: `translateY(-50%) translateY(${20 * (1 - p) - 34 * o}px) scale(${1.15 - 0.15 * p})`,
      }}
    >
      {word(k)}
    </div>
  );
  return (
    <AbsoluteFill style={{ opacity: 1 - q }}>
      {/* слово за стеклом: крупно, размыто, переливом */}
      <AbsoluteFill style={{ top: cy - 960 }}>
        <Word k={i} p={pin} o={0} ghost />
      </AbsoluteFill>
      <div style={{ position: 'absolute', left: (1080 - w) / 2 + shift, top: cy - h / 2, width: w, height: h, transform: `perspective(1600px) rotateY(${tilt}deg) rotateX(5deg) scale(${(1 - 0.06 * q) * (1 + 0.025 * breath(f, b))})` }}>
        <Glass f={f} at={beats[0] - 4} x={0} y={0} w={w} h={h} r={64} sheenAt={b + 2} style={{ overflow: 'hidden' }}>
          {prev >= 0 && <Word k={prev} p={1} o={pout} />}
          <Word k={i} p={pin} o={0} />
        </Glass>
      </div>
    </AbsoluteFill>
  );
};

/**
 * Стопка стекла в 3D: листы толстого стекла лежат друг над другом в изометрии и парят; на fanAt стопка раскрывается веером.
 * cards[0] — верхний лист (например, экран или видео в капсуле), остальные — подложки.
 */
export const GlassStack: React.FC<{ f: number; at: number; fanAt?: number; cards: React.ReactNode[]; cx?: number; cy?: number; w?: number; h?: number; out?: number }> = ({ f, at, fanAt, cards, cx = 540, cy = SAFE.cy, w = 720, h = 900, out }) => {
  const t = useTheme();
  const n = cards.length;
  const fan = fanAt !== undefined ? E.jelly(seg(f, fanAt, fanAt + 22)) : 0;
  const q = out !== undefined ? seg(f, out, out + 14, E.inCubic) : 0;
  const rz = -24 + 5 * Math.sin(f * 0.02);
  const rx = 48 + 4 * Math.sin(f * 0.015 + 1);
  return (
    <AbsoluteFill style={{ opacity: 1 - q }}>
      {cards
        .map((c, i) => {
          const k = n - 1 - i; // 0 — нижний
          const p = E.jelly(seg(f, at + k * 4, at + k * 4 + 24));
          if (p <= 0.001) return null;
          const gap = lerp(fan, 70, 165);
          const lift = (k - (n - 1) / 2) * gap + 10 * Math.sin(f * 0.04 + k);
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: cx - w / 2,
                top: cy - h / 2,
                width: w,
                height: h,
                borderRadius: 56,
                overflow: 'hidden',
                ...glassSkin(t),
                opacity: Math.min(1, p),
                transform: `perspective(2200px) translateY(${-lift * 1.05}px) rotateX(${rx}deg) rotateZ(${rz}deg) scale(${lerp(p, 0.8, 1)})`,
                boxShadow: `0 ${30 + k * 6}px 80px rgba(4,2,20,0.5), inset 0 1.5px 0 rgba(255,255,255,0.6)`,
              }}
            >
              <IrisRim f={f + k * 30} r={56} opacity={0.7} />
              {c}
            </div>
          );
        })
        .reverse()}
    </AbsoluteFill>
  );
};

/** Световой штрих: анаморфный блик пролетает через кадр по горизонтали (на дроп, на смену главы). 16f. */
export const Streak: React.FC<{ f: number; at: number; y?: number; dur?: number }> = ({ f, at, y = SAFE.cy, dur = 16 }) => {
  const p = seg(f, at, at + dur);
  if (p <= 0 || p >= 1) return null;
  const s = Math.sin(Math.PI * p);
  const x = lerp(E.flow(p), -600, 1680);
  return (
    <AbsoluteFill style={{ mixBlendMode: 'screen', pointerEvents: 'none' }}>
      <div style={{ position: 'absolute', left: x - 900, top: y - 3, width: 1800, height: 6, background: `linear-gradient(90deg, transparent, ${C.cyan} 30%, #fff 50%, ${C.pink} 70%, transparent)`, opacity: s, filter: 'blur(1px)' }} />
      <div style={{ position: 'absolute', left: x - 900, top: y - 40, width: 1800, height: 80, background: `linear-gradient(90deg, transparent, ${C.violet} 40%, ${C.pink} 60%, transparent)`, opacity: 0.45 * s, filter: 'blur(24px)' }} />
      <div style={{ position: 'absolute', left: x - 160, top: y - 160, width: 320, height: 320, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,0.8), rgba(143,107,255,0.25) 40%, transparent 70%)', opacity: s }} />
    </AbsoluteFill>
  );
};
