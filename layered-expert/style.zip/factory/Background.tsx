import React from 'react';
import { AbsoluteFill } from 'remotion';

/** Подложка стиля «Слои» — тёмная, без текстуры. Почти всегда её закрывает видео сцены. */
export const Background: React.FC = () => (
  <AbsoluteFill style={{ background: 'linear-gradient(180deg, #14171e 0%, #0d0f14 100%)' }} />
);
