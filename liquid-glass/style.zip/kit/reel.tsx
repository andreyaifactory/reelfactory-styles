import React from 'react';
import { AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame } from 'remotion';
import {
  Aurora, BeatWords, C, Condense, DISPLAY, E, FloatCam, GlassStack, GlassTitle, IRIS, IRIS_STOPS, IrisRim, LensDive,
  GooDefs, LiquidBlob, Merge, Drop, SAFE, Stage, Streak, TEXT, beatF, breath, glassSkin, irisText, lerp, rnd, seg,
} from './kit';

// Шоурил «Жидкое стекло» (~19 с, 1080×1920): чистая моушн-графика, каждое событие стоит на доле трека.
// Музыка — house-vibez с 59.08 с: 8 долей затишья без баса (нарастание) → дроп на доле 8 → полная энергия.
//
// Один герой ведёт весь ролик — капля. Сцены не сменяют друг друга целиком, а перетекают через неё:
// капля падает → слова проступают по одному на долю → капля поднимается и на дроп разрастается в каплю-морф
// со стеклянным заголовком → капля застывает стеклянной плитой, слова в бит → плита стекает обратно в каплю,
// та рассыпается каплями-пилюлями → пилюли сливаются в одну → пилюля разворачивается стопкой стекла →
// нырок в линзу → капли стекаются в финальную пилюлю.
//
// Переход — один лаконичный элемент: на доле, где герой меняет форму, от него расходится волна света
// (как круги от капли на воде). Камера вдыхает на каждой доле после дропа, свет пульсирует на каждой доле
// и на смене главы переливается в другую гамму.

export const REEL_DURATION = 575;
const MUSIC_FROM = 59.08; // сек в house-vibez.mp3: начало такта перед дропом (бас возвращается на 63.01)
const B = (n: number) => beatF(n); // 122 BPM, доля ≈ 14.75f
const A = (n: string) => staticFile(`glass/${n}.mp3`);
const range = (a: number, b: number) => Array.from({ length: b - a }, (_, i) => B(a + i));

/** Главы ролика — доли, на которых герой меняет форму. */
const T = { land: B(1), drop: B(8), plate: B(12), melt: B(20), merge: B(24), stack: B(27), lens: B(33) } as const;

/** Жидкость героя: светлое ядро, перелив, глубина к краю. */
const LIQ = `radial-gradient(circle at 34% 30%, #ffffff 0%, ${C.pink} 16%, ${C.violet} 48%, #2b1d8f 80%, #120a3d 100%)`;

// ── Волна света: лаконичный переход между главами ────────────────────────────
/** От героя расходятся два кольца перелива, сплющенные перспективой, как круги на воде. 30f. */
const Wave: React.FC<{ f: number; at: number; cx?: number; cy?: number; r0?: number }> = ({ f, at, cx = 540, cy = SAFE.cy, r0 = 120 }) => {
  if (f < at || f > at + 40) return null;
  const id = `wave-${at}`;
  return (
    <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, overflow: 'visible', pointerEvents: 'none' }}>
      <defs>
        <linearGradient id={id} x1="0" x2="1">
          {IRIS_STOPS.map((c, i) => (
            <stop key={i} offset={i / 3} stopColor={c} />
          ))}
        </linearGradient>
      </defs>
      {[0, 8].map((d) => {
        const p = seg(f, at + d, at + d + 32, E.outCubic);
        if (p <= 0 || p >= 1) return null;
        // Волна рождается у края героя и уходит наружу — по содержимому не проходит.
        const rx = lerp(p, r0, r0 + 640);
        return (
          <g key={d} opacity={(1 - p) * (d ? 0.6 : 1)}>
            <ellipse cx={cx} cy={cy} rx={rx} ry={rx * 0.36} fill="none" stroke={`url(#${id})`} strokeWidth={lerp(p, 14, 3)} style={{ filter: 'blur(6px)' }} />
            <ellipse cx={cx} cy={cy} rx={rx} ry={rx * 0.36} fill="none" stroke="rgba(255,255,255,0.85)" strokeWidth={lerp(p, 3, 1)} />
          </g>
        );
      })}
    </svg>
  );
};

// ── Герой меняет форму ───────────────────────────────────────────────────────
type Shape = { cx: number; cy: number; w: number; h: number; r: number; liquid: number; tilt?: number };

/**
 * Перетекание героя из одной формы в другую: положение — плавно (flow), размер и скругление — с упругостью
 * капли (jelly, лёгкий перелёт на прибытии), жидкость переходит в стекло и обратно. Показ — окно [show).
 */
const Morph: React.FC<{ f: number; at: number; dur: number; from: Shape; to: Shape; show: [number, number]; fade?: number }> = ({ f, at, dur, from, to, show, fade = 5 }) => {
  if (f < show[0] || f >= show[1]) return null;
  const p = seg(f, at, at + dur, E.flow);
  const j = E.jelly(seg(f, at, at + dur + 8));
  const cx = lerp(p, from.cx, to.cx);
  const cy = lerp(p, from.cy, to.cy);
  const w = lerp(j, from.w, to.w);
  const h = lerp(j, from.h, to.h);
  const r = Math.min(lerp(p, from.r, to.r), Math.min(w, h) / 2);
  const liquid = lerp(p, from.liquid, to.liquid);
  const tilt = lerp(p, from.tilt ?? 0, to.tilt ?? 0);
  const op = Math.min(1, (f - show[0] + 1) / 3) * (1 - seg(f, show[1] - fade, show[1]));
  return (
    <div
      style={{
        position: 'absolute',
        left: cx - w / 2,
        top: cy - h / 2,
        width: w,
        height: h,
        borderRadius: r,
        opacity: op,
        transform: `perspective(1600px) rotateY(${tilt}deg) rotateX(${Math.abs(tilt) / 3}deg)`,
        ...glassSkin('night'),
      }}
    >
      <div style={{ position: 'absolute', inset: 0, borderRadius: r, background: LIQ, opacity: liquid }} />
      <IrisRim f={f} r={r} opacity={0.7} />
    </div>
  );
};

// ── 1. Нарастание (доли 0–8): капля падает, слова проступают по одному на долю, капля поднимается ────
const LAND_Y = 1150;
const Build: React.FC<{ f: number }> = ({ f }) => {
  if (f >= T.drop + 4) return null;
  const fall = seg(f, 0, T.land, E.inCubic);
  // Жемчужина после падения: дышит на долях, поднимается к центру и набухает перед дропом.
  const rise = seg(f, B(6), B(7) + 6, E.flow);
  const swell = seg(f, B(7) + 6, T.drop, E.inCubic);
  const pulse = range(2, 8).reduce((a, b) => a + breath(f, b), 0);
  const d = (36 + 14 * Math.min(1, pulse)) * lerp(swell, 1, 3.2);
  const y = f < T.land ? lerp(fall, -60, LAND_Y) : lerp(rise, LAND_Y, SAFE.cy + 10);
  const pearlOp = 1 - seg(f, T.drop - 2, T.drop + 3);
  const words = ['Свет', 'течёт', 'сквозь', '*стекло*'];
  return (
    <AbsoluteFill>
      {f >= T.land && <Wave f={f} at={T.land} cy={LAND_Y} />}
      <div
        style={{
          position: 'absolute',
          left: 540 - d / 2,
          top: y - d * 0.55,
          width: d,
          height: f < T.land ? d * 1.25 : d,
          borderRadius: f < T.land ? '50% 50% 50% 50% / 60% 60% 40% 40%' : '50%',
          background: LIQ,
          opacity: pearlOp,
          boxShadow: `0 0 ${30 + 40 * swell}px rgba(170,140,255,0.9)`,
        }}
      />
      <div style={{ position: 'absolute', top: 300, left: 90, right: 90 }}>
        {words.map((w, i) => (
          <Condense key={i} f={f} at={B(2 + i)} out={B(6) + i * 2} text={w} size={128} align="center" dur={12} lh={1.12} />
        ))}
      </div>
      <Streak f={f} at={B(7) + 3} y={SAFE.cy} dur={14} />
    </AbsoluteFill>
  );
};

// ── 2. Дроп (доли 8–12): жемчужина разрастается в каплю-морф, на ней стеклянный заголовок ────────
const Title: React.FC<{ f: number }> = ({ f }) => {
  if (f < T.drop - 6 || f >= T.plate + 6) return null;
  const q = seg(f, T.plate - 8, T.plate - 2, E.inCubic);
  return (
    <AbsoluteFill>
      {/* Капля не тает рядом с плитой: на кадре, где начинается перетекание, её сменяет герой той же формы. */}
      {f < T.plate - 7 && <LiquidBlob f={f} at={T.drop - 6} r={440} beats={range(8, 13)} cy={SAFE.cy + 10} />}
      <div style={{ position: 'absolute', top: SAFE.cy - 140, left: 40, right: 40, opacity: 1 - q, filter: q > 0 ? `blur(${14 * q}px)` : undefined }}>
        <GlassTitle f={f} at={T.drop} sheenAt={B(10)} text={'ЖИДКОЕ\nСТЕКЛО'} size={150} />
      </div>
    </AbsoluteFill>
  );
};

/** Вспышка дропа: свет на миг заливает кадр и уходит в каплю. */
const DropFlash: React.FC<{ f: number }> = ({ f }) => {
  const p = seg(f, T.drop - 3, T.drop + 12);
  if (p <= 0 || p >= 1) return null;
  const s = Math.sin(Math.PI * Math.pow(p, 0.6));
  return <AbsoluteFill style={{ background: `radial-gradient(900px 1100px at 50% 44%, rgba(255,255,255,${0.75 * s}), rgba(143,107,255,${0.35 * s}) 45%, rgba(0,0,0,0) 75%)`, mixBlendMode: 'screen', pointerEvents: 'none' }} />;
};

// ── 3. Слова в бит (доли 12–20): капля застыла стеклянной плитой, плита поворачивается на каждую долю ──
const WORDS = ['свет', '*стекло*', 'капля', 'блик', '*туман*', 'глубина', 'поток', '*перелив*'];
const Words: React.FC<{ f: number }> = ({ f }) => {
  if (f < T.plate - 4 || f >= T.melt - 8) return null;
  return <BeatWords f={f} beats={range(12, 20)} words={WORDS} />;
};

// ── 4. Капли (доли 20–27): плита стекает в каплю, капли-пилюли падают на доли и сливаются ───────
const PILL_H = 170;
const PILLS: [string, number, number, number][] = [
  ['легко', 520, 440, B(21)],
  ['чисто', 400, 740, B(22)],
  ['глубоко', 620, 1040, B(23)],
];
const pillW = (s: string) => 170 + s.length * 52;
const Drops: React.FC<{ f: number }> = ({ f }) => {
  if (f < T.melt || f >= T.stack - 6) return null;
  return (
    <AbsoluteFill>
      {PILLS.map(([s, x, y, at]) => (
        <Drop key={s} f={f} at={at} out={T.merge - 4} x={x} y={y} w={pillW(s)} h={PILL_H} label={s} size={74} />
      ))}
      <Merge f={f} at={T.merge} cx={540} cy={SAFE.cy} from={PILLS.map(([, x, y]) => [x, y + PILL_H / 2, 48] as [number, number, number])} label="одно целое" w={760} h={180} size={72} />
    </AbsoluteFill>
  );
};

// ── 5. Стопка стекла (доли 27–33): пилюля разворачивается листом, листы раскрываются веером ─────
const CardDepth: React.FC<{ f: number }> = ({ f }) => (
  <AbsoluteFill style={{ padding: 70, justifyContent: 'center' }}>
    <div style={{ fontFamily: DISPLAY, fontWeight: 700, fontSize: 92, letterSpacing: '-0.05em', lineHeight: 1, paddingBottom: 10, ...irisText(f) }}>глубина</div>
    <div style={{ fontFamily: TEXT, fontWeight: 700, fontSize: 46, color: C.muted, marginTop: 24 }}>свет · кадр · стекло</div>
  </AbsoluteFill>
);
/** Столбики подпрыгивают на каждой доле, каждый со своим откликом. */
const CardBars: React.FC<{ f: number }> = ({ f }) => {
  const kick = range(27, 38).reduce((a, b) => a + breath(f, b), 0);
  return (
    <AbsoluteFill style={{ padding: 70, display: 'flex', flexDirection: 'row', alignItems: 'flex-end', gap: 26 }}>
      {[0.35, 0.55, 0.45, 0.8, 0.65, 1].map((h, i) => (
        <div key={i} style={{ flex: 1, height: `${h * 70 * (0.62 + 0.38 * Math.min(1, kick) * (0.6 + 0.4 * Math.sin(i * 1.7 + 1)))}%`, borderRadius: 26, background: IRIS, backgroundSize: '600% 100%', backgroundPosition: `${i * 20}% 0`, opacity: 0.85 }} />
      ))}
    </AbsoluteFill>
  );
};
const CardGlow: React.FC = () => <AbsoluteFill style={{ background: `radial-gradient(circle at 30% 30%, ${C.pink}, transparent 55%), radial-gradient(circle at 75% 70%, ${C.cyan}, transparent 55%)`, opacity: 0.55 }} />;
const Stack: React.FC<{ f: number }> = ({ f }) => {
  if (f < T.stack) return null;
  return (
    <AbsoluteFill>
      <GlassStack f={f} at={T.stack} fanAt={B(29)} cx={500} cy={SAFE.cy + 70} w={620} h={780} cards={[<CardDepth key="a" f={f} />, <CardBars key="b" f={f} />, <CardGlow key="c" />]} />
      <div style={{ position: 'absolute', top: 300, left: 90, right: 90 }}>
        <Condense f={f} at={B(28)} text="каждый слой — *стекло*" size={70} align="center" />
      </div>
    </AbsoluteFill>
  );
};

/** Герой в переходах между главами: капля → плита, плита → капля, пилюля → лист стекла. */
const Hero: React.FC<{ f: number }> = ({ f }) => {
  const d0 = PILL_H * 0.42;
  const [, x1, y1] = PILLS[0];
  return (
    <>
      <Morph
        f={f}
        at={T.plate - 8}
        dur={10}
        show={[T.plate - 8, T.plate + 6]}
        from={{ cx: 540, cy: SAFE.cy + 10, w: 880, h: 915, r: 440, liquid: 1 }}
        to={{ cx: 540, cy: SAFE.cy, w: 920, h: 600, r: 64, liquid: 0 }}
      />
      <Morph
        f={f}
        at={T.melt - 8}
        dur={10}
        show={[T.melt - 8, B(21) + 1]}
        fade={1}
        from={{ cx: 540 + 34, cy: SAFE.cy, w: 920, h: 600, r: 64, liquid: 0, tilt: 15 }}
        to={{ cx: x1, cy: y1 - 160 + d0 / 2, w: d0, h: d0, r: d0 / 2, liquid: 1 }}
      />
      <Morph
        f={f}
        at={T.stack - 6}
        dur={12}
        show={[T.stack - 6, T.stack + 14]}
        fade={7}
        from={{ cx: 540, cy: SAFE.cy, w: 760, h: 180, r: 90, liquid: 0.45 }}
        to={{ cx: 500, cy: SAFE.cy + 70, w: 620, h: 780, r: 56, liquid: 0 }}
      />
    </>
  );
};

/** Свет за стеклом: пульс на каждой доле, на смене главы переливается в другую гамму, гаснет с музыкой. */
const Light: React.FC<{ f: number }> = ({ f }) => {
  const hue = [T.plate, T.melt, T.stack].reduce((a, at, i) => a + (i % 2 ? -60 : 70) * seg(f, at - 4, at + 14, E.flow), 0);
  const dim = f < T.drop ? lerp(seg(f, T.land, B(7), E.inOutCubic), 0.15, 0.85) : 1;
  return <Aurora f={f} hue={hue} dim={dim} beats={[T.land, ...range(8, 33)]} />;
};

const World: React.FC<{ f: number }> = ({ f }) => (
  <AbsoluteFill>
    <Light f={f} />
    <FloatCam f={f} dur={T.lens} push={[1, 1.03]} accents={[T.land, ...range(8, 33)]}>
      {/* Волны — за героем: стекло их преломляет, а не они перечёркивают стекло. */}
      <Wave f={f} at={T.drop} cy={SAFE.cy + 10} r0={260} />
      <Wave f={f} at={T.plate} r0={480} />
      <Wave f={f} at={T.melt + 2} cx={PILLS[0][1]} cy={PILLS[0][2] - 160} r0={40} />
      <Wave f={f} at={T.stack} cy={SAFE.cy + 70} r0={420} />
      <Build f={f} />
      <Title f={f} />
      <Words f={f} />
      <Drops f={f} />
      <Stack f={f} />
      <Hero f={f} />
    </FloatCam>
    <DropFlash f={f} />
  </AbsoluteFill>
);

// ── 6. Финал (доли 33–): нырок в линзу, капли со всего кадра стекаются в пилюлю ─────────────────
/**
 * Капли со всего кадра стекаются в шар (липкая жидкость), и этот же шар растягивается в пилюлю-плашку:
 * жидкость застывает стеклом, внутри проступает название. Плашка не кладётся поверх шара — шар ею становится.
 */
const FINAL_CY = SAFE.cy - 120;
const FINAL_DROPS: [number, number, number][] = Array.from({ length: 9 }, (_, i) => [140 + rnd(i * 2.3) * 800, 300 + rnd(i * 5.1) * 1050, 26 + rnd(i * 9.7) * 40]);
const FinaleMelt: React.FC<{ f: number; at: number }> = ({ f, at }) => {
  if (f < at) return null;
  const flowP = seg(f, at, at + 22, E.flow);
  const R = 70 + 30 * E.jelly(seg(f, at + 14, at + 30));
  const ball = at + 24; // с этого кадра шар — уже герой, без фильтра слипания
  const stretch = at + 30; // шар вытягивается в плашку
  const W = 800;
  const H = 170;
  const label = seg(f, stretch + 8, stretch + 22, E.glide);
  return (
    <>
      {f < ball + 2 && (
        <>
          <GooDefs id="goo-final" />
          <div style={{ position: 'absolute', inset: 0, filter: 'url(#goo-final)' }}>
            {FINAL_DROPS.map(([x, y, r], i) => {
              const px = lerp(flowP, x, 540);
              const py = lerp(flowP, y, FINAL_CY);
              const rr = lerp(flowP, r, R * 0.7);
              return <div key={i} style={{ position: 'absolute', left: px - rr, top: py - rr, width: rr * 2, height: rr * 2, borderRadius: '50%', background: LIQ }} />;
            })}
            {flowP > 0.6 && <div style={{ position: 'absolute', left: 540 - R, top: FINAL_CY - R, width: R * 2, height: R * 2, borderRadius: '50%', background: LIQ }} />}
          </div>
        </>
      )}
      <Morph
        f={f}
        at={stretch}
        dur={14}
        show={[ball, REEL_DURATION + 1]}
        from={{ cx: 540, cy: FINAL_CY, w: 2 * R, h: 2 * R, r: R, liquid: 1 }}
        to={{ cx: 540, cy: FINAL_CY, w: W, h: H, r: H / 2, liquid: 0.35 }}
      />
      <div
        style={{
          position: 'absolute',
          left: 540 - W / 2,
          width: W,
          top: FINAL_CY - H / 2,
          height: H,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: TEXT,
          fontWeight: 700,
          fontSize: 66,
          letterSpacing: '-0.01em',
          color: C.text,
          opacity: label,
          filter: `blur(${10 * (1 - label)}px)`,
          transform: `translateY(${14 * (1 - label)}px)`,
        }}
      >
        Жидкое стекло
      </div>
      <div style={{ position: 'absolute', top: FINAL_CY + 130, left: 90, right: 90 }}>
        <Condense f={f} at={stretch + 20} text="стиль-пак для рилсов" size={44} font="text" weight={600} align="center" />
      </div>
    </>
  );
};

const Finale: React.FC<{ f: number }> = ({ f }) => (
  <FloatCam f={f} from={T.lens} dur={REEL_DURATION - T.lens} push={[1.05, 1]} accents={range(33, 38)}>
    <Aurora f={f} hue={-30} beats={range(33, 38)} dim={lerp(seg(f, REEL_DURATION - 30, REEL_DURATION), 1, 0.4)} />
    <FinaleMelt f={f} at={T.lens + 6} />
  </FloatCam>
);

type Sfx = { at: number; src: string; v: number; dur?: number };
const SFX: Sfx[] = [
  { at: T.land - 2, src: 'water-drop-cave', v: 0.35, dur: 40 },
  { at: B(7) - 6, src: 'light-sweep-magic', v: 0.18, dur: 26 },
  { at: T.drop - 2, src: 'transition-soft', v: 0.3 },
  { at: T.drop + 4, src: 'chime-crystal', v: 0.12, dur: 30 },
  { at: T.plate - 4, src: 'glass-plate-slide', v: 0.5 },
  { at: B(16), src: 'wind-swoosh-short', v: 0.12 },
  { at: T.melt - 6, src: 'whoosh-swirl', v: 0.14 },
  { at: B(21) + 6, src: 'water-bubble', v: 0.25 },
  { at: B(22) + 6, src: 'water-bubble', v: 0.25 },
  { at: B(23) + 6, src: 'water-bubble', v: 0.25 },
  { at: T.merge, src: 'whoosh-swirl', v: 0.15 },
  { at: T.stack - 4, src: 'glass-plate-slide', v: 0.45 },
  { at: B(29), src: 'wind-swoosh-short', v: 0.15 },
  { at: T.lens - 11, src: 'air-zoom-vacuum', v: 0.22 },
  { at: T.lens + 20, src: 'whoosh-swirl', v: 0.12 },
  { at: T.lens + 50, src: 'ui-success-soft', v: 0.22 },
  { at: B(36), src: 'chime-crystal', v: 0.16, dur: 34 },
];

export const LiquidReel: React.FC<{ bgm?: boolean }> = ({ bgm = true }) => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <LensDive f={f} at={T.lens - 11} x={540} y={SAFE.cy + 70} a={<World f={f} />} b={<Finale f={f} />} />
      {bgm && (
        <Audio
          src={staticFile('glass/house-vibez.mp3')}
          startFrom={Math.round(MUSIC_FROM * 30)}
          volume={(fr) => interpolate(fr, [0, 6, REEL_DURATION - 40, REEL_DURATION], [0, 0.9, 0.9, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}
        />
      )}
      {SFX.map((s, i) => (
        <Sequence key={i} from={s.at} durationInFrames={s.dur ?? 45}>
          <Audio src={A(s.src)} volume={s.v} />
        </Sequence>
      ))}
    </Stage>
  );
};
