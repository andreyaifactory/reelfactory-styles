import type { StylePack, StyleSound } from '../../../core/style-contract';
import { SERIF } from '../kit/kit';
import { tokens } from './tokens';
import { Background } from './Background';
import { Ambient } from './Ambient';
import { FontLoader } from './fonts';
import { transitions, autoTransitions } from './transitions';
import { Caption } from './Caption';
import { ScreenFrame } from './ScreenFrame';
import bank from './sfx.json';

/**
 * ПЕРЕХОДНИК «Бумажной печати» для фабрики роликов.
 *
 * Сам пак — идиома, компоненты, библиотека, звуки — лежит уровнем выше и не
 * знает о фабрике. Здесь он отдаёт ядру то, что ядро умеет брать от стиля:
 * токены, фон, живой слой, шрифты, бумажные склейки, субтитры-полоски, оправу
 * скрина и банк звуков (`sfx.json` собирается при включении стиля).
 */
const pack: StylePack = {
  tokens,
  Background,
  Ambient,
  FontLoader,
  transitions,
  autoTransitions,
  Caption,
  captionStep: { size: 54, weight: 700, lh: 1.18, ls: '-0.01em', family: SERIF },
  ScreenFrame,
  sfx: bank as { sounds: StyleSound[] },
};

export default pack;
export { tokens };
