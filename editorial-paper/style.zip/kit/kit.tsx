import React from 'react';
import { AbsoluteFill, OffthreadVideo, useCurrentFrame } from 'remotion';
// Кит пака «Бумажная печать»: бумага, оттиск, линейки, маркер, штамп, правка на полях.
// Всё детерминированно (без Math.random/Date.now), 1080×1920 по умолчанию.
import { E, clamp01, lerp, seg } from './timeline';

export { E, lerp, seg };

// ── Токены ──────────────────────────────────────────────────────────────────
export const C = {
  paper: '#f2eee6', // поле кадра (Ink Press)
  paperHi: '#f9f6f1', // лист
  desk: '#d8cfbf', // стол под листами (видно только в момент смены листа)
  ink: '#13110f',
  inkSoft: '#3a3632',
  muted: '#65635f',
  pencil: '#b8b0a3', // ещё не сказанное / вспомогательное
  amber: '#955905', // типографский акцент: курсив, линейка, номер
  amberDeep: '#ae6700',
  red: '#a8321f', // рука редактора: штамп, обводка, заметка на полях (≤2 раз на ролик)
  hl: 'rgba(236,184,64,0.55)', // текстовыделитель
};
export const SERIF = '"PT Serif", "New York", Georgia, "Times New Roman", serif';
export const MONO = '"PT Mono", ui-monospace, Menlo, monospace';

export const rnd = (seed: number) => {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

// Зерно бумаги (feTurbulence в data-URI, статичное)
const svgUri = (s: string) => `url("data:image/svg+xml;utf8,${encodeURIComponent(s)}")`;
export const GRAIN = svgUri(
  `<svg xmlns='http://www.w3.org/2000/svg' width='400' height='400'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' seed='7' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.35  0 0 0 0 0.29  0 0 0 0 0.22  0 0 0 0.55 0'/></filter><rect width='100%' height='100%' filter='url(#n)'/></svg>`,
);
const FIBERS = svgUri(
  `<svg xmlns='http://www.w3.org/2000/svg' width='900' height='900'><filter id='f'><feTurbulence type='fractalNoise' baseFrequency='0.012 0.09' numOctaves='2' seed='3'/><feColorMatrix values='0 0 0 0 0.45  0 0 0 0 0.38  0 0 0 0 0.3  0 0 0 0.22 -0.04'/></filter><rect width='100%' height='100%' filter='url(#f)'/></svg>`,
);
// Маска «неровная краска» для штампа и оттисков
export const INK_MASK = svgUri(
  `<svg xmlns='http://www.w3.org/2000/svg' width='600' height='600'><filter id='m'><feTurbulence type='fractalNoise' baseFrequency='0.7' numOctaves='3' seed='11'/><feColorMatrix values='0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  3.2 0 0 0 -0.55'/></filter><rect width='100%' height='100%' filter='url(#m)'/></svg>`,
);

// ── Бумага ──────────────────────────────────────────────────────────────────
export const PaperTexture: React.FC<{ tone?: string; strength?: number }> = ({ tone = C.paper, strength = 1 }) => (
  <AbsoluteFill style={{ background: tone }}>
    <AbsoluteFill style={{ background: 'radial-gradient(900px 1100px at 50% 40%, rgba(255,253,248,0.75), rgba(255,253,248,0) 70%)' }} />
    <AbsoluteFill style={{ backgroundImage: FIBERS, opacity: 0.9 * strength }} />
    <AbsoluteFill style={{ backgroundImage: GRAIN, opacity: 0.55 * strength, mixBlendMode: 'multiply' }} />
    <AbsoluteFill style={{ boxShadow: 'inset 0 0 220px rgba(70,52,30,0.16)' }} />
  </AbsoluteFill>
);

/** Корень кадра: стол + шрифты. Все сцены — листы поверх (Page). */
export const Desk: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <AbsoluteFill style={{ background: C.desk, fontFamily: SERIF, color: C.ink, overflow: 'hidden', WebkitFontSmoothing: 'antialiased' }}>
    <AbsoluteFill style={{ backgroundImage: GRAIN, opacity: 0.7, mixBlendMode: 'multiply' }} />
    {children}
  </AbsoluteFill>
);

/**
 * Лист — единица сцены. Новый лист въезжает справа с лёгким поворотом и тенью (18f, outQuint),
 * старый остаётся под ним, сдвигается влево и темнеет — пустого кадра не бывает.
 * Внутри лист медленно «дышит»: наезд 1.00→1.035 за жизнь листа и дрейф ±0.25°.
 */
export const PAGE_IN = 18;
export const Page: React.FC<{
  from: number;
  to: number;
  enter?: 'slide' | 'none' | 'drop';
  tone?: string;
  children: (f: number, local: number) => React.ReactNode;
}> = ({ from, to, enter = 'slide', tone = C.paperHi, children }) => {
  const f = useCurrentFrame();
  const end = to + PAGE_IN + 2; // лежит под следующим листом, пока тот въезжает
  if (f < from || f >= end) return null;
  const pin = enter === 'none' ? 1 : seg(f, from, from + PAGE_IN, E.outQuint);
  const under = seg(f, to, to + PAGE_IN, E.outCubic);
  const life = seg(f, from, end);
  const x = enter === 'slide' ? lerp(pin, 1180, 0) : 0;
  const y = enter === 'drop' ? lerp(pin, -80, 0) : 0;
  const rot = enter === 'slide' ? lerp(pin, 4, 0) : 0;
  const sc = enter === 'drop' ? lerp(pin, 1.06, 1) : 1;
  return (
    <AbsoluteFill
      style={{
        transform: `translate(${x - under * 90}px, ${y}px) rotate(${rot + Math.sin(f * 0.021) * 0.25}deg) scale(${sc})`,
        transformOrigin: '50% 100%',
        boxShadow: `0 0 ${lerp(pin, 120, 40)}px rgba(40,28,14,${lerp(pin, 0.45, 0.22)})`,
        opacity: enter === 'drop' ? pin : 1,
      }}
    >
      <PaperTexture tone={tone} />
      <AbsoluteFill style={{ transform: `scale(${lerp(life, 1, 1.035)})`, transformOrigin: '50% 45%' }}>{children(f, f - from)}</AbsoluteFill>
      <AbsoluteFill style={{ background: '#2a1e10', opacity: under * 0.28, pointerEvents: 'none' }} />
    </AbsoluteFill>
  );
};

// ── Типографика ─────────────────────────────────────────────────────────────
export type W = { t: string; a?: boolean };
/** «Ролики, которые *читают*.» → слова; *слово* = акцент (курсив, янтарь). */
export const words = (s: string): W[] =>
  s.split(/\s+/).filter(Boolean).map((w) => {
    const m = w.match(/^\*(.+)\*([^*]*)$/);
    return m ? { t: m[1] + m[2], a: true } : { t: w };
  });

/** Оттиск по словам (Ink Press): scale 1.28→1, blur 7→0, 9f на слово, шаг 4f. */
export const Press: React.FC<{
  f: number;
  at: number;
  text: string;
  size?: number;
  step?: number;
  weight?: number;
  color?: string;
  align?: 'left' | 'center';
  lh?: number;
  italic?: boolean;
  style?: React.CSSProperties;
}> = ({ f, at, text, size = 112, step = 4, weight = 700, color = C.ink, align = 'center', lh = 1.08, italic, style }) => (
  <div
    style={{
      fontFamily: SERIF,
      fontSize: size,
      fontWeight: weight,
      lineHeight: lh,
      letterSpacing: '-0.015em',
      color,
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: align === 'center' ? 'center' : 'flex-start',
      columnGap: '0.24em',
      fontStyle: italic ? 'italic' : 'normal',
      ...style,
    }}
  >
    {words(text).map((w, i) => {
      const t = seg(f, at + i * step, at + i * step + 9, E.press);
      return (
        <span
          key={i}
          style={{
            display: 'inline-block',
            opacity: t,
            transform: `scale(${1.28 - 0.28 * t})`,
            filter: `blur(${(1 - t) * 7}px)`,
            fontStyle: w.a || italic ? 'italic' : 'normal',
            color: w.a ? C.amber : undefined,
          }}
        >
          {w.t}
        </span>
      );
    })}
  </div>
);
export const pressEnd = (at: number, text: string, step = 4) => at + (words(text).length - 1) * step + 9;

/** Линейка: рисуется слева направо (18f). double — газетная двойная линейка. */
export const Rule: React.FC<{ f: number; at: number; w?: number | string; thick?: number; color?: string; len?: number; double?: boolean; center?: boolean; style?: React.CSSProperties }> = ({
  f, at, w = '100%', thick = 3, color = C.ink, len = 18, double, center, style,
}) => {
  const p = seg(f, at, at + len, E.rule);
  const line = (h: number) => <div style={{ height: h, background: color, transform: `scaleX(${p})`, transformOrigin: center ? '50% 50%' : '0 50%' }} />;
  return (
    <div style={{ width: w, margin: center ? '0 auto' : undefined, ...style }}>
      {line(thick)}
      {double ? <div style={{ height: thick + 3 }} /> : null}
      {double ? line(Math.max(1, thick / 3)) : null}
    </div>
  );
};

/** Служебная строка (дата в шапке, подпись под цитатой). НЕ надзаголовок: рубрики над заголовком в стиле запрещены. */
export const Kicker: React.FC<{ f: number; at: number; children: React.ReactNode; size?: number; color?: string; square?: boolean; style?: React.CSSProperties }> = ({
  f, at, children, size = 26, color = C.muted, square = false, style,
}) => {
  const p = seg(f, at, at + 8, E.outCubic);
  return (
    <div
      style={{
        fontFamily: MONO,
        fontSize: size,
        letterSpacing: '0.16em',
        textTransform: 'uppercase',
        color,
        display: 'flex',
        alignItems: 'center',
        gap: 16,
        opacity: p,
        transform: `translateY(${(1 - p) * 8}px)`,
        ...style,
      }}
    >
      {square ? <span style={{ width: 11, height: 11, background: C.amber, display: 'inline-block', flex: 'none' }} /> : null}
      <span>{children}</span>
    </div>
  );
};

// ── Шапка газеты ────────────────────────────────────────────────────────────
/** Масthead: линейки рисуются → название набирается по буквам (шаг 2f) → строка выпуска. */
export const Masthead: React.FC<{ f: number; at: number; title: string; issue: string; date: string; price: string; top?: number; size?: number }> = ({
  f, at, title, issue, date, price, top = 150, size = 150,
}) => {
  const letters = [...title];
  return (
    <div style={{ position: 'absolute', top, left: 60, right: 60 }}>
      <Rule f={f} at={at} thick={6} double />
      <div style={{ display: 'flex', justifyContent: 'center', margin: '34px 0 26px', fontFamily: SERIF, fontWeight: 700, fontSize: size, letterSpacing: '-0.02em', lineHeight: 1 }}>
        {letters.map((ch, i) => {
          const t = seg(f, at + 10 + i * 2, at + 19 + i * 2, E.press);
          return (
            <span key={i} style={{ display: 'inline-block', whiteSpace: 'pre', opacity: t, transform: `scale(${1.3 - 0.3 * t})`, filter: `blur(${(1 - t) * 6}px)` }}>
              {ch}
            </span>
          );
        })}
      </div>
      <Rule f={f} at={at + 8} thick={2} />
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '16px 2px' }}>
        <Kicker f={f} at={at + 22 + letters.length * 2} size={24} square={false}>{issue}</Kicker>
        <Kicker f={f} at={at + 26 + letters.length * 2} size={24}>{date}</Kicker>
        <Kicker f={f} at={at + 30 + letters.length * 2} size={24} square={false}>{price}</Kicker>
      </div>
      <Rule f={f} at={at + 14} thick={6} double />
    </div>
  );
};

// ── Маркер-выделитель ───────────────────────────────────────────────────────
/** Абзац текста; фрагменты в [[двойных скобках]] выделяются маркером слева направо (14f, по очереди). */
export const Highlight: React.FC<{ f: number; at: number; text: string; size?: number; gap?: number; color?: string; style?: React.CSSProperties }> = ({
  f, at, text, size = 46, gap = 16, color = C.hl, style,
}) => {
  const parts = text.split(/(\[\[.+?\]\])/);
  let k = -1;
  return (
    <div style={{ fontFamily: SERIF, fontSize: size, lineHeight: 1.42, color: C.inkSoft, ...style }}>
      {parts.map((p, i) => {
        const m = p.match(/^\[\[(.+)\]\]$/);
        if (!m) return <span key={i}>{p}</span>;
        k += 1;
        const t = seg(f, at + k * gap, at + k * gap + 14, E.inOutCubic);
        return (
          <span
            key={i}
            style={{
              color: C.ink,
              backgroundImage: `linear-gradient(100deg, rgba(0,0,0,0) 0.4%, ${color} 1.2%, ${color} 98%, rgba(0,0,0,0) 99.5%)`,
              backgroundRepeat: 'no-repeat',
              backgroundSize: `${t * 100}% 72%`,
              backgroundPosition: '0 62%',
              WebkitBoxDecorationBreak: 'clone',
              boxDecorationBreak: 'clone',
              padding: '0 6px',
              margin: '0 -6px',
            }}
          >
            {m[1]}
          </span>
        );
      })}
    </div>
  );
};

// ── Штамп ───────────────────────────────────────────────────────────────────
/** Штамп падает 5f (inCubic), прижим-сплющивание 6f, неровная краска (маска шума). Один на ролик. */
export const Stamp: React.FC<{ f: number; at: number; text: string; sub?: string; color?: string; rotate?: number; size?: number; style?: React.CSSProperties }> = ({
  f, at, text, sub, color = C.red, rotate = -9, size = 92, style,
}) => {
  if (f < at) return null;
  const drop = seg(f, at, at + 5, E.inCubic);
  const squash = f >= at + 5 ? Math.sin(seg(f, at + 5, at + 11) * Math.PI) * 0.04 : 0;
  const s = lerp(drop, 1.7, 1) - squash;
  return (
    <div
      style={{
        display: 'inline-flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 6,
        padding: '18px 34px 16px',
        border: `7px solid ${color}`,
        outline: `2px solid ${color}`,
        outlineOffset: 6,
        borderRadius: 10,
        color,
        fontFamily: SERIF,
        fontWeight: 700,
        fontSize: size,
        letterSpacing: '0.06em',
        textTransform: 'uppercase',
        lineHeight: 1,
        opacity: lerp(drop, 0, 0.92),
        transform: `rotate(${rotate}deg) scale(${s})`,
        WebkitMaskImage: INK_MASK,
        maskImage: INK_MASK,
        mixBlendMode: 'multiply',
        ...style,
      }}
    >
      <span style={{ whiteSpace: 'nowrap' }}>{text}</span>
      {sub ? <span style={{ fontFamily: MONO, fontWeight: 400, fontSize: size * 0.28, letterSpacing: '0.2em' }}>{sub}</span> : null}
    </div>
  );
};

// ── Цитата ──────────────────────────────────────────────────────────────────
/** Огромные кавычки-ёлочки оттиском → цитата по словам → линейка → подпись. */
export const PullQuote: React.FC<{ f: number; at: number; text: string; by: string; size?: number; top?: number }> = ({ f, at, text, by, size = 92, top = 520 }) => {
  const q = seg(f, at, at + 10, E.press);
  const tEnd = pressEnd(at + 8, text, 4);
  return (
    <div style={{ position: 'absolute', top, left: 90, right: 90 }}>
      <div style={{ fontFamily: SERIF, fontWeight: 700, fontSize: 360, lineHeight: 1, height: 280, marginTop: -40, color: C.amber, opacity: q, transform: `scale(${1.3 - 0.3 * q})`, transformOrigin: '0 0', filter: `blur(${(1 - q) * 8}px)` }}>«</div>
      <Press f={f} at={at + 8} text={text} size={size} align="left" lh={1.12} />
      <Rule f={f} at={tEnd + 4} w={160} thick={4} color={C.amber} style={{ marginTop: 54 }} />
      <Kicker f={f} at={tEnd + 10} square={false} style={{ marginTop: 26 }}>
        — {by}
      </Kicker>
    </div>
  );
};

// ── Иллюстрация с подписью ──────────────────────────────────────────────────
/**
 * Рисунок: рамка рисуется, содержимое «печатается» сверху вниз (clip, 20f),
 * затем подпись «Рис. N.» и выноска — обводка от руки + линия-лидер к номеру.
 */
export const Figure: React.FC<{
  f: number;
  at: number;
  n: number | string;
  caption: string;
  w: number;
  h: number;
  callout?: { x: number; y: number; r: number; label: string; lx: number; ly: number };
  children: React.ReactNode;
}> = ({ f, at, n, caption, w, h, callout, children }) => {
  const frame = seg(f, at, at + 14, E.rule);
  const print = seg(f, at + 6, at + 26, E.outCubic);
  const cap = seg(f, at + 24, at + 32, E.outCubic);
  return (
    <div style={{ width: w, position: 'relative' }}>
      <div style={{ position: 'relative', width: w, height: h, padding: 14, boxSizing: 'border-box' }}>
        <svg width={w} height={h} style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
          <rect x={1} y={1} width={w - 2} height={h - 2} fill="none" stroke={C.ink} strokeWidth={2} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - frame} />
        </svg>
        <div style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden', clipPath: `inset(0 0 ${(1 - print) * 100}% 0)` }}>{children}</div>
        {callout ? <Callout f={f} at={at + 34} {...callout} /> : null}
      </div>
      <div style={{ marginTop: 22, fontFamily: SERIF, fontSize: 36, lineHeight: 1.3, color: C.inkSoft, opacity: cap, transform: `translateY(${(1 - cap) * 8}px)` }}>
        <b style={{ color: C.ink }}>Рис. {n}.</b> <i>{caption}</i>
      </div>
    </div>
  );
};

/** Обводка от руки (красный карандаш) + лидер к номеру. Линия «кипит» каждые 3f. */
export const Callout: React.FC<{ f: number; at: number; x: number; y: number; r: number; label: string; lx: number; ly: number; color?: string }> = ({
  f, at, x, y, r, label, lx, ly, color = C.red,
}) => {
  const ring = seg(f, at, at + 16, E.inOutCubic);
  const lead = seg(f, at + 12, at + 22, E.outCubic);
  const lab = seg(f, at + 20, at + 28, E.press);
  const b = Math.floor(f / 3);
  const j = (k: number) => (rnd(b * 7 + k) - 0.5) * 2.2;
  // чуть несомкнутый эллипс — как рукой
  const d = `M ${x + r + j(1)} ${y + j(2)} C ${x + r + j(3)} ${y - r * 1.05}, ${x - r * 1.1} ${y - r + j(4)}, ${x - r + j(5)} ${y + j(6)} C ${x - r * 1.05} ${y + r * 1.1}, ${x + r * 1.15} ${y + r + j(7)}, ${x + r * 1.08} ${y - r * 0.22}`;
  const ang = Math.atan2(ly - y, lx - x);
  const sx = x + Math.cos(ang) * r * 1.1;
  const sy = y + Math.sin(ang) * r * 1.1;
  return (
    <svg style={{ position: 'absolute', inset: 0, overflow: 'visible', pointerEvents: 'none' }} width="100%" height="100%">
      <path d={d} fill="none" stroke={color} strokeWidth={5} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ring} opacity={0.9} />
      <line x1={sx} y1={sy} x2={lerp(lead, sx, lx)} y2={lerp(lead, sy, ly)} stroke={color} strokeWidth={3} strokeLinecap="round" opacity={lead > 0 ? 0.9 : 0} />
      <g opacity={lab} transform={`translate(${lx} ${ly}) scale(${1.3 - 0.3 * lab})`}>
        <circle r={30} fill={C.paperHi} stroke={color} strokeWidth={3} />
        <text textAnchor="middle" dy={11} fontFamily={SERIF} fontWeight={700} fontSize={32} fill={color}>
          {label}
        </text>
      </g>
    </svg>
  );
};

// ── Заметка на полях ────────────────────────────────────────────────────────
/** Рукописная правка: курсив красным карандашом пишется слева направо, стрелка дорисовывается. */
export const MarginNote: React.FC<{ f: number; at: number; text: string; x: number; y: number; rotate?: number; arrow?: string; size?: number; color?: string }> = ({
  f, at, text, x, y, rotate = -4, arrow, size = 46, color = C.red,
}) => {
  const lines = text.split('\n');
  const per = 12;
  const a = seg(f, at + lines.length * per, at + lines.length * per + 14, E.inOutCubic);
  return (
    <div style={{ position: 'absolute', left: x, top: y, transform: `rotate(${rotate}deg)`, transformOrigin: '0 0' }}>
      {lines.map((l, i) => {
        const p = seg(f, at + i * per, at + (i + 1) * per + 2, (t) => t);
        return (
          <div key={i} style={{ fontFamily: SERIF, fontStyle: 'italic', fontSize: size, lineHeight: 1.15, color, whiteSpace: 'pre', clipPath: `inset(-20% ${(1 - p) * 100}% -20% 0)` }}>
            {l}
          </div>
        );
      })}
      {arrow ? (
        <svg style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible' }} width={10} height={10}>
          <path d={arrow} fill="none" stroke={color} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - a} />
        </svg>
      ) : null}
    </div>
  );
};

// ── Оглавление ──────────────────────────────────────────────────────────────
/** «В номере»: строки ложатся по очереди (шаг 6f), точки-лидеры дорисовываются, active — янтарный номер. */
export const Contents: React.FC<{ f: number; at: number; rows: { t: string; n: string }[]; active?: number; activeAt?: number; size?: number; style?: React.CSSProperties }> = ({
  f, at, rows, active, activeAt = 0, size = 52, style,
}) => (
  <div style={{ display: 'flex', flexDirection: 'column', gap: 30, ...style }}>
    {rows.map((r, i) => {
      const p = seg(f, at + i * 6, at + i * 6 + 10, E.press);
      const dots = seg(f, at + i * 6 + 4, at + i * 6 + 18, E.outCubic);
      const on = active === i ? seg(f, activeAt, activeAt + 8, E.outCubic) : 0;
      return (
        <div key={i} style={{ display: 'flex', alignItems: 'baseline', gap: 18, fontFamily: SERIF, fontSize: size, opacity: p, transform: `translateY(${(1 - p) * 14}px)` }}>
          <span style={{ fontStyle: on > 0.5 ? 'italic' : 'normal', color: on > 0.5 ? C.amber : C.ink }}>{r.t}</span>
          <span style={{ flex: 1, height: 2, transform: `translateY(-8px) scaleX(${dots})`, transformOrigin: '0 50%', backgroundImage: `radial-gradient(circle, ${C.muted} 2.2px, rgba(0,0,0,0) 2.6px)`, backgroundSize: '16px 4px', backgroundRepeat: 'repeat-x', minHeight: 4 }} />
          <span style={{ fontFamily: MONO, fontSize: size * 0.7, color: on > 0.5 ? C.amber : C.muted, fontWeight: on > 0.5 ? 700 : 400 }}>{r.n}</span>
        </div>
      );
    })}
  </div>
);

// ── Колонка текста ──────────────────────────────────────────────────────────
/** Абзац с буквицей: буквица оттиском, строки текста проявляются построчно (шаг 3f). */
export const DropCap: React.FC<{ f: number; at: number; text: string; size?: number; lines?: number }> = ({ f, at, text, size = 40, lines = 3 }) => {
  const cap = seg(f, at, at + 10, E.press);
  const body = seg(f, at + 6, at + 24, E.outCubic);
  return (
    <div style={{ fontFamily: SERIF, fontSize: size, lineHeight: 1.45, color: C.inkSoft, textAlign: 'justify', hyphens: 'auto' }} lang="ru">
      <span style={{ float: 'left', fontSize: size * 1.45 * lines * 0.92, lineHeight: 0.82, fontWeight: 700, color: C.amber, margin: '8px 14px 0 0', opacity: cap, transform: `scale(${1.3 - 0.3 * cap})`, display: 'inline-block', transformOrigin: '0 0' }}>
        {text[0]}
      </span>
      <span style={{ opacity: body }}>{text.slice(1)}</span>
    </div>
  );
};

// ── Заглушка «скриншота» в гравюрной манере (для демо) ──────────────────────
export const hatch = (c = C.ink, a = 0.55, gap = 9) =>
  `repeating-linear-gradient(-45deg, ${c} 0 1.5px, rgba(0,0,0,0) 1.5px ${gap}px)`;
export const MockPage: React.FC<{ w: number; h: number }> = ({ w, h }) => (
  <div style={{ width: w, height: h, background: C.paper, position: 'relative', fontFamily: SERIF }}>
    <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 56, borderBottom: `2px solid ${C.ink}`, display: 'flex', alignItems: 'center', gap: 14, padding: '0 22px' }}>
      <span style={{ width: 16, height: 16, borderRadius: 8, border: `2px solid ${C.ink}` }} />
      <span style={{ fontFamily: MONO, fontSize: 18, letterSpacing: '0.12em', color: C.muted }}>SHORTCRAFT / РЕДАКТОР</span>
    </div>
    <div style={{ position: 'absolute', left: 26, top: 84, width: w * 0.5, height: h * 0.42, border: `2px solid ${C.ink}`, backgroundImage: hatch(C.inkSoft, 0.5, 10), opacity: 0.85 }} />
    {[0, 1, 2, 3].map((i) => (
      <div key={i} style={{ position: 'absolute', left: w * 0.5 + 54, top: 92 + i * 44, width: w * (i === 0 ? 0.36 : 0.3 - i * 0.03), height: i === 0 ? 24 : 12, background: i === 0 ? C.ink : C.pencil }} />
    ))}
    {[0, 1, 2, 3, 4].map((i) => (
      <div key={i} style={{ position: 'absolute', left: 26 + i * ((w - 52) / 5), bottom: 34, width: (w - 52) / 5 - 18, height: [70, 120, 92, 160, 132][i], background: i === 3 ? C.amber : 'transparent', border: `2px solid ${C.ink}`, backgroundImage: i === 3 ? undefined : hatch(C.inkSoft, 0.4, 8) }} />
    ))}
  </div>
);

/** Вход/выход элемента внутри листа (без улёта за край): 0..1 */
export const life = (f: number, a: number, b: number, inLen = 10, outLen = 8) => seg(f, a, a + inLen, E.outCubic) * (1 - seg(f, b - outLen, b, E.inCubic));
export { clamp01 };

// ════════════════════════════════════════════════════════════════════════════
// Бумажная идиома: одна длинная поверхность, камера читает; чужое — вклеено.
// ════════════════════════════════════════════════════════════════════════════

// Рваный край: детерминированная ломаная. Возвращает точки вдоль отрезка с поперечным шумом.
export const ragged = (seed: number, n: number, amp: number) => Array.from({ length: n + 1 }, (_, i) => (i === 0 || i === n ? 0 : (rnd(seed + i * 3.7) - 0.5) * 2 * amp));

// ── Длинная полоса + камера-чтец ────────────────────────────────────────────
/** Ключ камеры: в кадре f центр экрана смотрит на точку полосы (cx, cy) с масштабом s. */
export type CamKey = { f: number; cy: number; s?: number; cx?: number };
export const camAt = (f: number, keys: CamKey[]) => {
  const k = keys;
  if (f <= k[0].f) return { cx: k[0].cx ?? 540, cy: k[0].cy, s: k[0].s ?? 1 };
  for (let i = 0; i < k.length - 1; i++) {
    if (f <= k[i + 1].f) {
      const t = E.inOutCubic((f - k[i].f) / Math.max(1, k[i + 1].f - k[i].f));
      return { cx: lerp(t, k[i].cx ?? 540, k[i + 1].cx ?? 540), cy: lerp(t, k[i].cy, k[i + 1].cy), s: lerp(t, k[i].s ?? 1, k[i + 1].s ?? 1) };
    }
  }
  const l = k[k.length - 1];
  return { cx: l.cx ?? 540, cy: l.cy, s: l.s ?? 1 };
};
/**
 * Полоса: один высокий лист (h px), по которому едет камера (keys). Между ключами — inOutCubic,
 * одинаковые соседние ключи = остановка на чтение. Отъезд (s≈0.5) показывает весь коллаж — это итог.
 * Под листом — стол; при отъезде видны края листа и тень.
 */
export const LongPage: React.FC<{ f: number; keys: CamKey[]; h: number; w?: number; children: React.ReactNode }> = ({ f, keys, h, w = 1080, children }) => {
  const { cx, cy, s } = camAt(f, keys);
  return (
    <AbsoluteFill style={{ overflow: 'hidden' }}>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: w,
          height: h,
          transformOrigin: '0 0',
          transform: `translate(${540 - cx * s}px, ${960 - cy * s}px) scale(${s}) rotate(${Math.sin(f * 0.019) * 0.2}deg)`,
          boxShadow: '0 30px 120px rgba(40,28,14,0.35)',
        }}
      >
        <PaperTexture tone={C.paperHi} />
        {children}
      </div>
    </AbsoluteFill>
  );
};

// ── Вырезка: реальное видео/скрин в бумажной рамке на скотче ────────────────
/** Кусок скотча: полупрозрачный, с рваными торцами; прилипает за 4f. */
export const Tape: React.FC<{ f: number; at: number; x: number; y: number; w?: number; rotate?: number; seed?: number }> = ({ f, at, x, y, w = 170, rotate = -30, seed = 1 }) => {
  const p = seg(f, at, at + 4, E.outCubic);
  if (p <= 0) return null;
  const n = 6;
  const L = ragged(seed, n, 4), R = ragged(seed + 9, n, 4);
  const poly = [...L.map((d, i) => `${6 + d}px ${(i / n) * 100}%`), ...R.map((d, i) => `calc(100% - ${6 + d}px) ${(1 - i / n) * 100}%`)].join(',');
  return (
    <div
      style={{
        position: 'absolute', left: x - w / 2, top: y - 24, width: w, height: 48,
        background: 'linear-gradient(180deg, rgba(240,232,210,0.78), rgba(225,214,186,0.72))',
        boxShadow: '0 1px 2px rgba(60,40,20,0.2)',
        clipPath: `polygon(${poly})`,
        transform: `rotate(${rotate}deg) scale(${lerp(p, 1.25, 1)})`,
        opacity: p,
      }}
    />
  );
};

/**
 * Вырезка: белое поле как у отпечатка, край — ножницами (cut) или рваный (torn).
 * Ложится шлепком (8f: scale 1.12→1, поворот +5°→rotate, тень большая→прижатая), затем скотч на углы.
 * Внутрь — что угодно: <OffthreadVideo>, <Img> скриншота, сцена.
 */
export const Cutout: React.FC<{
  f: number; at: number; x: number; y: number; w: number; h: number; rotate?: number; border?: number; edge?: 'cut' | 'torn'; tape?: boolean; seed?: number; children: React.ReactNode;
}> = ({ f, at, x, y, w, h, rotate = -2, border = 18, edge = 'cut', tape = true, seed = 5, children }) => {
  const p = seg(f, at, at + 8, E.press);
  if (f < at) return null;
  const W = w + border * 2, H = h + border * 2;
  let clip: string | undefined;
  if (edge === 'torn') {
    const n = 22, a = 5;
    const top = ragged(seed, n, a), rgt = ragged(seed + 50, n, a), bot = ragged(seed + 100, n, a), lft = ragged(seed + 150, n, a);
    const pts = [
      ...top.map((d, i) => `${(i / n) * 100}% ${a + d}px`),
      ...rgt.map((d, i) => `calc(100% - ${a + d}px) ${(i / n) * 100}%`),
      ...bot.map((d, i) => `${(1 - i / n) * 100}% calc(100% - ${a + d}px)`),
      ...lft.map((d, i) => `${a + d}px ${(1 - i / n) * 100}%`),
    ];
    clip = `polygon(${pts.join(',')})`;
  }
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: W, height: H, transform: `rotate(${lerp(p, rotate + 5, rotate)}deg) scale(${lerp(p, 1.12, 1)})`, opacity: Math.min(1, p * 2) }}>
      <div style={{ position: 'absolute', inset: 0, filter: `drop-shadow(0 ${lerp(p, 40, 8)}px ${lerp(p, 50, 14)}px rgba(40,28,14,${lerp(p, 0.4, 0.3)}))` }}>
        <div style={{ position: 'absolute', inset: 0, background: '#fbf9f4', clipPath: clip }}>
          <div style={{ position: 'absolute', left: border, top: border, width: w, height: h, overflow: 'hidden', background: C.ink }}>{children}</div>
          <AbsoluteFill style={{ backgroundImage: GRAIN, opacity: 0.35, mixBlendMode: 'multiply', pointerEvents: 'none' }} />
        </div>
      </div>
      {tape ? (
        <>
          <Tape f={f} at={at + 8} x={14} y={10} rotate={-38} seed={seed + 1} />
          <Tape f={f} at={at + 11} x={W - 14} y={H - 10} rotate={-38} seed={seed + 2} />
        </>
      ) : null}
    </div>
  );
};

// ── Наклейка ────────────────────────────────────────────────────────────────
/** Вырубная наклейка: белая кайма, шлепок с небольшим перелётом (1.08), уголок подвёрнут. */
export const Sticker: React.FC<{ f: number; at: number; x: number; y: number; text: string; d?: number; bg?: string; fg?: string; rotate?: number; size?: number }> = ({
  f, at, x, y, text, d = 220, bg = C.amber, fg = C.paperHi, rotate = 12, size,
}) => {
  if (f < at) return null;
  const t = seg(f, at, at + 9);
  const sc = t < 0.6 ? lerp(E.outCubic(t / 0.6), 1.5, 0.95) : lerp(E.outCubic((t - 0.6) / 0.4), 0.95, 1);
  return (
    <div style={{ position: 'absolute', left: x - d / 2, top: y - d / 2, width: d, height: d, transform: `rotate(${rotate}deg) scale(${sc})`, opacity: Math.min(1, t * 3) }}>
      <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: '#fffdf8', boxShadow: `0 ${lerp(t, 26, 5)}px ${lerp(t, 34, 10)}px rgba(40,28,14,0.3)` }} />
      <div style={{ position: 'absolute', inset: 12, borderRadius: '50%', background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center', color: fg, fontFamily: SERIF, fontWeight: 700, fontStyle: 'italic', fontSize: size ?? d * 0.2, lineHeight: 1, padding: 10, boxSizing: 'border-box' }}>
        {text}
      </div>
      {/* подвёрнутый уголок: светлая «изнанка» + тень */}
      <div style={{ position: 'absolute', right: d * 0.1, bottom: d * 0.06, width: d * 0.2, height: d * 0.2, background: 'linear-gradient(135deg, rgba(0,0,0,0) 50%, #ece6da 50%)', borderRadius: '0 0 50% 0', boxShadow: '-3px -3px 6px rgba(40,28,14,0.15)', transform: 'rotate(8deg)' }} />
    </div>
  );
};

// ── Бумажные полоски-подписи (поверх видео/фото) ────────────────────────────
/** *строка* = акцентная полоска (accent: чернила на бумаге, янтарь поверх тёмного видео). Каждая строка — отдельная полоска бумаги с рваными торцами; въезжает 10f со своим наклоном, шаг 6f. */
export const Strips: React.FC<{ f: number; at: number; lines: string[]; x: number; y: number; size?: number; step?: number; align?: 'left' | 'right'; accent?: string }> = ({
  f, at, lines, x, y, size = 50, step = 6, align = 'left', accent = C.ink,
}) => (
  <div style={{ position: 'absolute', left: x, top: y, display: 'flex', flexDirection: 'column', alignItems: align === 'left' ? 'flex-start' : 'flex-end', gap: 10 }}>
    {lines.map((l, i) => {
      const p = seg(f, at + i * step, at + i * step + 10, E.press);
      const r = (rnd(i * 13 + 2) - 0.5) * 4;
      const n = 5;
      const L = ragged(i * 7 + 1, n, 5), R = ragged(i * 7 + 40, n, 5);
      const poly = [...L.map((d, k) => `${6 + d}px ${(k / n) * 100}%`), ...R.map((d, k) => `calc(100% - ${6 + d}px) ${(1 - k / n) * 100}%`)].join(',');
      const ink = /^\*.*\*$/.test(l);
      return (
        <div key={i} style={{ filter: 'drop-shadow(0 6px 8px rgba(40,28,14,0.3))', opacity: Math.min(1, p * 2), transform: `translateX(${(1 - p) * (align === 'left' ? -60 : 60)}px) rotate(${r + (1 - p) * 4}deg)` }}>
          <div style={{ background: ink ? accent : '#fbf9f4', color: ink ? C.paperHi : C.ink, clipPath: `polygon(${poly})`, padding: '10px 30px 12px', fontFamily: SERIF, fontWeight: 700, fontSize: size, lineHeight: 1.1, whiteSpace: 'nowrap' }}>
            {ink ? l.slice(1, -1) : l}
          </div>
        </div>
      );
    })}
  </div>
);

// ── Разрыв листа ────────────────────────────────────────────────────────────
/**
 * Верхний лист рвётся пополам по рваной линии и разлетается (16f, inCubic): левая половина уходит влево с поворотом,
 * правая — вправо. На торце белые волокна (drop-shadow). Под ним уже лежит следующий лист — рендерить его до <Tear>.
 */
export const Tear: React.FC<{ f: number; at: number; len?: number; seed?: number; children: React.ReactNode }> = ({ f, at, len = 16, seed = 21, children }) => {
  if (f < at) return <>{children}</>;
  if (f >= at + len) return null;
  const p = seg(f, at, at + len, E.inCubic);
  const crack = seg(f, at, at + 3); // сначала трещина проходит сверху вниз
  const n = 32;
  const off = ragged(seed, n, 34);
  const xs = off.map((d, i) => 540 + d + (i / n - 0.5) * 120);
  const ys = off.map((_, i) => (i / n) * 1920 * Math.max(crack, 0.001));
  const edge = xs.map((x, i) => `${x}px ${ys[i]}px`);
  const leftPoly = `polygon(0 0, ${edge.join(',')}, ${xs[n]}px 1920px, 0 1920px)`;
  const rightPoly = `polygon(${xs[0]}px 0, 1080px 0, 1080px 1920px, ${xs[n]}px 1920px, ${[...edge].reverse().join(',')})`;
  const half = (poly: string, dir: number) => (
    <AbsoluteFill style={{ filter: 'drop-shadow(0 0 1.5px #fffdf6) drop-shadow(0 0 1.5px #fffdf6) drop-shadow(0 20px 30px rgba(40,28,14,0.35))', transform: `translate(${dir * p * 760}px, ${p * 120}px) rotate(${dir * p * 14}deg)`, transformOrigin: dir < 0 ? '0% 100%' : '100% 100%' }}>
      <AbsoluteFill style={{ clipPath: poly }}>{children}</AbsoluteFill>
    </AbsoluteFill>
  );
  return crack < 1 ? <>{children}</> : <>{half(leftPoly, -1)}{half(rightPoly, 1)}</>;
};

// ════════════════════════════════════════════════════════════════════════════
// Динамика рилса: рисовка от руки, бумажные переходы, толчки камеры.
// ════════════════════════════════════════════════════════════════════════════

/** Толчок камеры от «шлепков»: каждый удар даёт +amp к масштабу и гаснет за ~10f. Возвращает scale. */
export const bump = (f: number, hits: number[], amp = 0.03) =>
  1 + hits.reduce((a, h) => (f >= h ? a + amp * Math.exp(-(f - h) / 4) * Math.cos((f - h) * 0.5) : a), 0);

/** Камера «из рук» над столом: медленный дрейф + наезд; plus — дополнительный scale (bump). */
export const HandCam: React.FC<{ f: number; push?: [number, number, number, number]; plus?: number; children: React.ReactNode }> = ({ f, push, plus = 1, children }) => {
  const s = push ? lerp(seg(f, push[0], push[1], E.inOutCubic), push[2], push[3]) : 1;
  return (
    <AbsoluteFill style={{ transform: `translate(${Math.sin(f * 0.05) * 6}px, ${Math.cos(f * 0.043) * 5}px) rotate(${Math.sin(f * 0.031) * 0.35}deg) scale(${s * plus})` }}>
      {children}
    </AbsoluteFill>
  );
};

/** Рисовка от руки: SVG-путь(и) дорисовываются за len кадров, потом линия «кипит» (сдвиг каждые 3f). */
export const DOODLE = {
  circle: (cx: number, cy: number, rx: number, ry: number) =>
    `M ${cx + rx} ${cy - ry * 0.1} C ${cx + rx} ${cy - ry * 1.2}, ${cx - rx * 1.1} ${cy - ry * 1.1}, ${cx - rx} ${cy + ry * 0.1} C ${cx - rx * 0.95} ${cy + ry * 1.15}, ${cx + rx * 1.15} ${cy + ry * 1.05}, ${cx + rx * 1.05} ${cy - ry * 0.35}`,
  swoosh: (x: number, y: number, w: number) => `M ${x} ${y + 8} C ${x + w * 0.3} ${y - 6}, ${x + w * 0.65} ${y + 4}, ${x + w} ${y - 10}`,
  star: (x: number, y: number, r: number) =>
    Array.from({ length: 4 }, (_, i) => {
      const a = (i / 4) * Math.PI;
      return `M ${x - Math.cos(a) * r} ${y - Math.sin(a) * r} L ${x + Math.cos(a) * r} ${y + Math.sin(a) * r}`;
    }).join(' '),
  arrow: (x1: number, y1: number, x2: number, y2: number) => {
    const a = Math.atan2(y2 - y1, x2 - x1);
    const mx = (x1 + x2) / 2 + Math.sin(a) * 40, my = (y1 + y2) / 2 - Math.cos(a) * 40;
    const h = (d: number) => `M ${x2} ${y2} L ${x2 - Math.cos(a + d) * 34} ${y2 - Math.sin(a + d) * 34}`;
    return `M ${x1} ${y1} Q ${mx} ${my}, ${x2} ${y2} ${h(0.5)} ${h(-0.5)}`;
  },
  spark: (x: number, y: number, r: number) =>
    [0, 1, 2].map((i) => {
      const a = -Math.PI / 2 + (i - 1) * 0.6;
      return `M ${x + Math.cos(a) * r * 0.45} ${y + Math.sin(a) * r * 0.45} L ${x + Math.cos(a) * r} ${y + Math.sin(a) * r}`;
    }).join(' '),
  scribble: (x: number, y: number, w: number, h: number) =>
    `M ${x} ${y + h} ` + Array.from({ length: 7 }, (_, i) => `L ${x + ((i + 1) / 7) * w} ${y + (i % 2 ? h : 0)}`).join(' '),
};
export const Doodle: React.FC<{ f: number; at: number; d: string; len?: number; color?: string; width?: number; style?: React.CSSProperties }> = ({
  f, at, d, len = 12, color = C.red, width = 7, style,
}) => {
  if (f < at) return null;
  const p = seg(f, at, at + len, E.outCubic);
  const b = Math.floor(f / 3);
  return (
    <svg width={1080} height={1920} style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible', pointerEvents: 'none', ...style }}>
      <path
        d={d}
        transform={`translate(${(rnd(b) - 0.5) * 2} ${(rnd(b + 5) - 0.5) * 2})`}
        fill="none"
        stroke={color}
        strokeWidth={width}
        strokeLinecap="round"
        strokeLinejoin="round"
        pathLength={1}
        strokeDasharray={1}
        strokeDashoffset={1 - p}
      />
    </svg>
  );
};

/** Ragged polygon helpers: горизонтальный рваный край на высоте y (в px кадра). */
const raggedRow = (seed: number, y: number, amp = 26, n = 28) => ragged(seed, n, amp).map((d, i) => [(i / n) * 1080, y + d] as const);

/**
 * Переход «лист с рваным краем»: новый лист (children) въезжает снизу вверх за len кадров (outQuint),
 * его верхний край рваный, на кромке белые волокна и тень. Старая сцена под ним остаётся.
 */
export const PaperWipe: React.FC<{ f: number; at: number; len?: number; seed?: number; tone?: string; children: React.ReactNode }> = ({ f, at, len = 14, seed = 31, tone = C.paperHi, children }) => {
  if (f < at) return null;
  const p = seg(f, at, at + len, E.outQuint);
  const top = lerp(p, 1920 + 60, -60);
  const row = raggedRow(seed, 40, 24);
  const poly = `polygon(${row.map(([x, y]) => `${x}px ${y}px`).join(',')}, 1080px 2100px, 0 2100px)`;
  return (
    <AbsoluteFill style={{ transform: `translateY(${top}px) rotate(${(1 - p) * -3}deg)`, filter: 'drop-shadow(0 -2px 0 #fffdf6) drop-shadow(0 -18px 30px rgba(40,28,14,0.35))' }}>
      <div style={{ position: 'absolute', left: -20, right: -20, top: 0, height: 2100, clipPath: poly }}>
        <div style={{ position: 'absolute', left: 20, top: 60, width: 1080, height: 1920 }}>
          <PaperTexture tone={tone} />
          {children}
        </div>
      </div>
    </AbsoluteFill>
  );
};

/** Переход «страница перелистывается»: верхняя сцена (children) поворачивается вокруг левого края (len кадров), оборот — бумага. */
export const PageFlip: React.FC<{ f: number; at: number; len?: number; children: React.ReactNode }> = ({ f, at, len = 16, children }) => {
  if (f >= at + len) return null;
  const p = seg(f, at, at + len, E.inOutCubic);
  const ang = -p * 180;
  return (
    <AbsoluteFill style={{ perspective: 2200, perspectiveOrigin: '0% 50%' }}>
      <AbsoluteFill style={{ transformOrigin: '0% 50%', transform: `rotateY(${ang}deg)`, transformStyle: 'preserve-3d' }}>
        <AbsoluteFill style={{ backfaceVisibility: 'hidden' }}>
          {children}
          <AbsoluteFill style={{ background: `linear-gradient(90deg, rgba(0,0,0,0) 40%, rgba(40,28,14,${p * 0.5}))` }} />
        </AbsoluteFill>
        <AbsoluteFill style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}>
          <PaperTexture tone="#ece5d8" />
          <AbsoluteFill style={{ background: `linear-gradient(270deg, rgba(0,0,0,0) 30%, rgba(40,28,14,${(1 - p) * 0.4}))` }} />
        </AbsoluteFill>
      </AbsoluteFill>
      <AbsoluteFill style={{ background: 'rgba(30,20,10,1)', opacity: Math.sin(p * Math.PI) * 0.18, pointerEvents: 'none', zIndex: -1 }} />
    </AbsoluteFill>
  );
};

/**
 * «Бумага рвётся и открывает видео»: лист с рваной дырой; дыра растёт от маленькой до почти полного кадра.
 * under — то, что видно в дыре (видео). Края дыры с белыми волокнами и тенью внутрь.
 */
export const TornWindow: React.FC<{ f: number; at: number; len?: number; from?: number; to?: number; cx?: number; cy?: number; seed?: number; tone?: string; children?: React.ReactNode }> = ({
  f, at, len = 14, from = 0.05, to = 0.86, cx = 540, cy = 900, seed = 61, tone = C.paperHi, children,
}) => {
  const p = seg(f, at, at + len, E.outQuint);
  const k = lerp(p, from, to);
  const n = 40;
  const off = ragged(seed, n, 1);
  const pts = off.map((d, i) => {
    const a = (i / n) * Math.PI * 2;
    const rx = 540 * k * (1 + d * 0.09), ry = 960 * k * (1 + d * 0.06);
    return `${cx + Math.cos(a) * rx}px ${cy + Math.sin(a) * ry}px`;
  });
  const clip = `polygon(evenodd, 0 0, 1080px 0, 1080px 1920px, 0 1920px, 0 0, ${pts.join(',')}, ${pts[0]})`;
  return (
    <AbsoluteFill style={{ filter: 'drop-shadow(0 0 2px #fffdf6) drop-shadow(0 0 2px #fffdf6) drop-shadow(0 8px 20px rgba(20,14,8,0.5))' }}>
      <AbsoluteFill style={{ clipPath: clip }}>
        <PaperTexture tone={tone} />
        {children}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/** Слова-вырезки: каждое слово на своём куске бумаги (разные тона), шлепок 6f, поворот, шаг step. */
const SCRAP = [
  { bg: '#fbf9f4', fg: C.ink },
  { bg: C.ink, fg: C.paperHi },
  { bg: '#d9c39a', fg: C.ink },
  { bg: C.amber, fg: C.paperHi },
];
export const CutWords: React.FC<{ f: number; at: number; words: string[]; step?: number; size?: number; x?: number; y?: number; gap?: number }> = ({
  f, at, words, step = 14, size = 150, x = 70, y = 520, gap = 34,
}) => (
  <div style={{ position: 'absolute', left: x, top: y, display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap }}>
    {words.map((w, i) => {
      const t0 = at + i * step;
      if (f < t0) return <div key={i} style={{ height: size * 1.25 }} />;
      const p = seg(f, t0, t0 + 6, E.inCubic);
      const r = (rnd(i * 9 + 4) - 0.5) * 8;
      const sc = SCRAP[i % SCRAP.length];
      const nn = 6;
      const L = ragged(i * 5 + 3, nn, 9), R = ragged(i * 5 + 70, nn, 9), T = ragged(i * 5 + 140, 14, 5), B = ragged(i * 5 + 200, 14, 5);
      const poly = [
        ...T.map((d, k) => `${(k / 14) * 100}% ${6 + d}px`),
        ...R.map((d, k) => `calc(100% - ${9 + d}px) ${(k / nn) * 100}%`),
        ...B.map((d, k) => `${(1 - k / 14) * 100}% calc(100% - ${6 + d}px)`),
        ...L.map((d, k) => `${9 + d}px ${(1 - k / nn) * 100}%`),
      ].join(',');
      return (
        <div key={i} style={{ marginLeft: (rnd(i * 3 + 1) * 120) | 0, transform: `rotate(${r}deg) scale(${lerp(p, 1.45, 1)})`, opacity: Math.min(1, p * 3), filter: `drop-shadow(0 ${lerp(p, 30, 7)}px ${lerp(p, 30, 8)}px rgba(40,28,14,0.35))` }}>
          <div style={{ background: sc.bg, color: sc.fg, clipPath: `polygon(${poly})`, padding: `${size * 0.1}px ${size * 0.26}px ${size * 0.14}px`, fontFamily: SERIF, fontWeight: 700, fontStyle: i % 2 ? 'italic' : 'normal', fontSize: size, lineHeight: 1, letterSpacing: '-0.02em', whiteSpace: 'nowrap' }}>
            {w}
          </div>
        </div>
      );
    })}
  </div>
);

// ════════════════════════════════════════════════════════════════════════════
// Бумажная аппликация (рисуем сами, без внешних картинок) и видео-полоса без надписей.
// ════════════════════════════════════════════════════════════════════════════

const DIORAMA = {
  day: { sky: ['#f4ead6', '#e8d6b4'], sun: '#d38a2c', cloud: '#fbf7ee', hills: ['#dcc49c', '#c39759', '#8c5f33', '#2e241b'], star: null as string | null },
  night: { sky: ['#1b1713', '#2b241d'], sun: '#efe4cc', cloud: '#3a3229', hills: ['#3f352b', '#54473a', '#6e5c47', '#120f0c'], star: '#efe4cc' },
};

/** Хребет холма: волна + рваный край. Возвращает clip-path polygon (координаты внутри слоя 1200×(1920-top+80)). */
const ridge = (seed: number, amp: number, freq: number, phase: number) => {
  const n = 40;
  const r = ragged(seed, n, 7);
  const pts = Array.from({ length: n + 1 }, (_, i) => {
    const x = (i / n) * 1200;
    const y = 120 + Math.sin(x * freq + phase) * amp + Math.sin(x * freq * 2.3 + phase * 1.7) * amp * 0.35 + r[i];
    return `${x}px ${y}px`;
  });
  return `polygon(${pts.join(',')}, 1200px 100%, 0 100%)`;
};

/** Рваный круг (солнце/луна) */
const raggedCircle = (seed: number, n = 96, amp = 0.012) => {
  const r = ragged(seed, n, 1);
  return `polygon(${r.map((d, i) => {
    const a = (i / n) * Math.PI * 2;
    const k = 50 * (1 + d * amp * 2);
    return `${50 + Math.cos(a) * k}% ${50 + Math.sin(a) * k}%`;
  }).join(',')})`;
};

/**
 * Бумажная аппликация на весь кадр: небо, солнце/луна, облака, 4 слоя вырезанных холмов.
 * Слои встают по очереди, как в книжке-раскладушке (at, шаг 4f), потом живут параллаксом.
 */
export const Diorama: React.FC<{ f: number; at?: number; night?: boolean }> = ({ f, at = 0, night }) => {
  const P = night ? DIORAMA.night : DIORAMA.day;
  const tops = [960, 1130, 1310, 1500];
  const rise = (i: number) => seg(f, at + i * 4, at + i * 4 + 12, E.press);
  const sunP = seg(f, at + 2, at + 14, E.press);
  const paper = (c: string) => ({ background: c, backgroundImage: GRAIN, backgroundBlendMode: 'multiply' as const });
  return (
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${P.sky[0]}, ${P.sky[1]})`, overflow: 'hidden' }}>
      <AbsoluteFill style={{ backgroundImage: GRAIN, opacity: night ? 0.25 : 0.5, mixBlendMode: night ? 'screen' : 'multiply' }} />
      {P.star
        ? Array.from({ length: 22 }, (_, i) => {
            const tw = 0.5 + 0.5 * Math.sin(f * 0.15 + i);
            return <div key={i} style={{ position: 'absolute', left: rnd(i * 3.1) * 1040 + 20, top: rnd(i * 7.7) * 820 + 60, width: 8 + rnd(i) * 8, height: 8 + rnd(i) * 8, background: P.star ?? undefined, clipPath: 'polygon(50% 0, 62% 38%, 100% 50%, 62% 62%, 50% 100%, 38% 62%, 0 50%, 38% 38%)', opacity: 0.4 + tw * 0.6 * sunP }} />;
          })
        : null}
      {/* солнце / луна */}
      <div style={{ position: 'absolute', left: 560, top: 430, width: 380, height: 380, filter: 'drop-shadow(0 10px 18px rgba(40,28,14,0.3))', transform: `translateY(${lerp(sunP, 260, 0) + Math.sin(f * 0.03) * 8}px) rotate(${f * 0.15}deg)` }}>
        <div style={{ position: 'absolute', inset: 0, ...paper(P.sun), clipPath: raggedCircle(night ? 9 : 4) }} />
      </div>
      {/* облака */}
      {[{ x: 90, y: 360, s: 1 }, { x: 640, y: 860, s: 0.7 }].map((c, i) => (
        <div key={i} style={{ position: 'absolute', left: c.x + Math.sin(f * 0.02 + i * 2) * 24 + (1 - rise(1)) * (i ? 300 : -300), top: c.y, width: 340 * c.s, height: 140 * c.s, filter: 'drop-shadow(0 8px 12px rgba(40,28,14,0.25))' }}>
          <div style={{ position: 'absolute', inset: 0, ...paper(P.cloud), clipPath: 'polygon(6% 100%, 2% 70%, 12% 46%, 26% 44%, 32% 18%, 50% 4%, 66% 14%, 74% 36%, 88% 38%, 98% 66%, 94% 100%)' }} />
        </div>
      ))}
      {/* холмы */}
      {tops.map((t, i) => {
        const p = rise(i);
        const par = Math.sin(f * 0.025) * (i + 1) * 7;
        return (
          <div key={i} style={{ position: 'absolute', left: -60 + par, top: t - 120 + (1 - p) * 700, width: 1200, height: 1920 - t + 200, filter: `drop-shadow(0 -10px 16px rgba(30,20,10,${night ? 0.5 : 0.3}))` }}>
            <div style={{ position: 'absolute', inset: 0, ...paper(P.hills[i]), clipPath: ridge(i * 17 + 3, 46 - i * 6, 0.006 + i * 0.0018, i * 1.9) }} />
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

/**
 * Видео-полоса: показывает только окно исходника (доли кадра x0..x1, y0..y1) — так в кадр не попадают надписи исходника.
 * Ставится внутрь Cutout/контейнера размером w×h.
 */
export const VideoBand: React.FC<{ src: string; w: number; h: number; x0: number; x1: number; y0: number; srcW?: number; srcH?: number }> = ({ src, w, h, x0, x1, y0, srcW = 1280, srcH = 720 }) => {
  const s = w / ((x1 - x0) * srcW);
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', width: w, height: h }}>
      <OffthreadVideo src={src} muted style={{ position: 'absolute', left: -x0 * srcW * s, top: -y0 * srcH * s, width: srcW * s, height: srcH * s }} />
    </div>
  );
};

/**
 * Штриховка карандашом: параллельные штрихи внутри круга ложатся один за другим (шаг 1f, штрих 4f),
 * чуть кривые и разной длины, как от руки. Для «закрасить», «выделить объект» без обводки.
 */
export const HatchFill: React.FC<{ f: number; at: number; cx: number; cy: number; r: number; gap?: number; angle?: number; color?: string; width?: number; opacity?: number }> = ({
  f, at, cx, cy, r, gap = 18, angle = -35, color = C.inkSoft, width = 4, opacity = 0.6,
}) => {
  if (f < at) return null;
  const n = Math.floor((2 * r) / gap);
  const id = `hatch-${cx}-${cy}`;
  const b = Math.floor(f / 3);
  return (
    <svg width={1080} height={1920} style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible', pointerEvents: 'none', mixBlendMode: 'multiply' }}>
      <defs>
        <clipPath id={id}>
          <circle cx={cx} cy={cy} r={r} />
        </clipPath>
      </defs>
      <g clipPath={`url(#${id})`} transform={`rotate(${angle} ${cx} ${cy}) translate(${(rnd(b) - 0.5) * 1.5} 0)`} opacity={opacity}>
        {Array.from({ length: n }, (_, i) => {
          const p = seg(f, at + i, at + i + 4, E.outCubic);
          const y = cy - r + gap / 2 + i * gap;
          const x0 = cx - r - 10 + rnd(i * 3) * 30, x1 = cx + r + 10 - rnd(i * 5) * 30;
          const bend = (rnd(i * 7) - 0.5) * 8;
          return p > 0 ? (
            <path key={i} d={`M ${x0} ${y} Q ${(x0 + x1) / 2} ${y + bend}, ${x1} ${y + (rnd(i) - 0.5) * 6}`} fill="none" stroke={color} strokeWidth={width} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
          ) : null;
        })}
      </g>
    </svg>
  );
};

/** Безопасная зона Reels/Shorts 1080×1920: текст и детали контента только внутри; ниже bottom — только фон и анимация. */
export const SAFE = { top: 230, bottom: 1440, left: 60, right: 1020, rightColumn: { x: 940, fromY: 1000 } } as const;
