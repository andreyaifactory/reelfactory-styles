// versus-slam · 竖版 9:16（1080×1920）。
// 保留：20f 建立 hold + 10f ease-in(cubic) 对冲、撞击帧 30 白闪 0.9→0（3f）、震屏 12px 指数衰减 τ1.6、"VS" 盖章 1.6→1 back(2.6) 6f。
// 竖版：左右半屏（竖画只有 540 宽一半，太窄）改为上下半屏沿斜缝对撞——缝过安全区中心 (540, 835)，
// 左端低右端高、斜 12°（1080 宽上竖向偏移 230）；上半从上方 −1500 冲下、下半从下方 +1500 冲上；VS 字块随缝倾斜。
// 以下为横版原注释：
// versus-slam 对撞开屏：左右两个半屏画面（带 78° 斜切边）从画外加速对冲，沿斜缝砰地撞合；
// 撞击帧白闪 + 整机震屏指数衰减 + "VS" 字块盖章压出，结尾静止 hold。
import React from 'react';
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from 'remotion';
import { G, TitleBlock } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const VERSUS_SLAM_VERTICAL_DURATION = 120;
const IMPACT = 30;
const SEAM_L = SAFE_CY + 115; // 缝左端 y
const SEAM_R = SAFE_CY - 115; // 缝右端 y
const SEAM_DEG = (Math.atan2(SEAM_R - SEAM_L, 1080) * 180) / Math.PI;

export const VersusSlamVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const topY = interpolate(frame, [20, IMPACT], [-1500, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.in(Easing.cubic) });
  const since = frame - IMPACT;
  const env = since >= 0 ? 12 * Math.exp(-since / 1.6) : 0;
  const shakeX = env * 0.6 * Math.sin(since * 4.1 + 0.7);
  const shakeY = env * Math.sin(since * 3.4);
  const flash = interpolate(frame, [IMPACT, IMPACT + 3], [0.9, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const vsScale = interpolate(frame, [IMPACT, IMPACT + 6], [1.6, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.back(2.6)) });
  const vsOpacity = interpolate(frame, [IMPACT, IMPACT + 2], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const impacted = frame >= IMPACT;
  return (
    <AbsoluteFill style={{ background: G.bg, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, transform: `translate(${shakeX}px, ${shakeY}px)` }}>
        {!impacted && (
          <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0 }}>
            <line x1={0} y1={SEAM_L} x2={1080} y2={SEAM_R} stroke={G.bar} strokeWidth={4} strokeDasharray="18 16" />
          </svg>
        )}
        <div style={{ position: 'absolute', inset: 0, transform: `translateY(${topY}px)`, clipPath: `polygon(0px 0px, 1080px 0px, 1080px ${SEAM_R}px, 0px ${SEAM_L}px)` }}>
          <FakeDashboardV variant="A" />
        </div>
        <div style={{ position: 'absolute', inset: 0, transform: `translateY(${-topY}px)`, clipPath: `polygon(0px ${SEAM_L}px, 1080px ${SEAM_R}px, 1080px 1920px, 0px 1920px)` }}>
          <FakeDashboardV variant="B" />
        </div>
        {impacted && <div style={{ position: 'absolute', left: 540 - 700, top: SAFE_CY - 6, width: 1400, height: 12, background: G.ink, transform: `rotate(${SEAM_DEG}deg)` }} />}
        {impacted && (
          <div style={{ position: 'absolute', left: 540, top: SAFE_CY, transform: `translate(-50%, -50%) rotate(${SEAM_DEG}deg) scale(${vsScale})`, opacity: vsOpacity, background: G.card, border: `6px solid ${G.ink}`, borderRadius: 20, padding: '18px 46px', boxShadow: '0 18px 60px rgba(0,0,0,0.35)' }}>
            <TitleBlock text="VS" size={150} />
          </div>
        )}
      </div>
      <AbsoluteFill style={{ background: '#ffffff', opacity: flash, pointerEvents: 'none' }} />
    </AbsoluteFill>
  );
};
