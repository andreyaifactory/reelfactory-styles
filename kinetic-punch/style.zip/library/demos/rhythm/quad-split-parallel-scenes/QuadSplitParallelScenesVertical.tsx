// quad-split-parallel-scenes · 竖版 9:16（1080×1920）。
// 保留：四个象限的微场景与全部时间点（打字、tab 弹入、0.42–0.54 whip 急推、三词 0.24/0.46/0.56、BR 五步交互、0.8 卡片弹出），时长 63f。
// 竖版：设计坐标 480×270 → 270×480；2×2 网格只铺在安全区（y 230…1440 → 设计 57.5…360），格子 135×151 近方形；
// 每格内容按原 240 宽的设计盒渲染、盒高 240→268（内容用百分比定位，竖向自然拉开），整体缩 0.5625 塞进格子。
// 网格上下的黑边是底色（无内容）。象限组件从横版文件导出复用。
import React from 'react';
import { DesignStage, useT } from '../../_fixtures/Motion';
import { BGS, QuadBL, QuadBR, QuadTL, QuadTR } from './QuadSplitParallelScenes';

export const QUAD_SPLIT_PARALLEL_SCENES_VERTICAL_DURATION = 63;
const TOP = 57.5;
const QH = (360 - TOP) / 2;

export const QuadSplitParallelScenesVertical: React.FC = () => {
  const t = useT();
  const frame = Math.floor(t * 63);
  const scenes = [<QuadTL key={0} t={t} frame={frame} />, <QuadTR key={1} t={t} frame={frame} />, <QuadBL key={2} t={t} />, <QuadBR key={3} t={t} />];
  return (
    <DesignStage w={270} h={480} bg="#000" raster="zoom">
      {scenes.map((scene, i) => (
        <div key={i} style={{ position: 'absolute', left: (i % 2) * 135, top: TOP + (i >> 1) * QH, width: 135, height: QH, overflow: 'hidden', background: BGS[i] }}>
          <div style={{ position: 'absolute', left: 0, top: 0, width: 240, height: QH / 0.5625, transform: 'scale(0.5625)', transformOrigin: '0 0' }}>{scene}</div>
        </div>
      ))}
    </DesignStage>
  );
};
