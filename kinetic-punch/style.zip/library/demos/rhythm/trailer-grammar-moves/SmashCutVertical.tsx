// smash-cut · 竖版 9:16（1080×1920）。
// 保留：0–41 轰鸣段（5 张卡两轮飞掠，第二轮更快，ease-in 加速，scale 1.5→3 冲脸，速度门控模糊 1→5px）、
// 背景 1→1.55 加速推近 + 滚动 1.8°；42 一帧硬切变体 B 整齐静止，停满 93f。
// 竖版：FakeDashboard → FakeDashboardV；飞卡起终点按竖画面重算（横向 ±1400 → ±1000，纵向 ±900 → ±1300），
// 卡片尺寸 ×0.85（竖画宽较窄），飞行中心对准安全区中心 y 835。
// 以下为横版原注释：
// 猛切（喧闹→死寂）：轰鸣段多卡多方向高速飞掠冲镜，背景持续加速推近并滚动——切点前一刻动势最猛；
// 一帧硬切整齐静止全景，无一物在动。反差即手法本体。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G, Card } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const SMASH_CUT_VERTICAL_DURATION = 135;
const CUT = 42;
type Fly = { from: [number, number]; to: [number, number]; rot: [number, number]; seed: number; w: number; h: number };
const FLIES: Fly[] = [
  { from: [-1000, -160], to: [1000, 80], rot: [-6, 5], seed: 1, w: 374, h: 246 },
  { from: [1000, 240], to: [-1000, -140], rot: [7, -4], seed: 2, w: 340, h: 221 },
  { from: [-220, -1300], to: [150, 1300], rot: [-3, 8], seed: 3, w: 391, h: 255 },
  { from: [-950, 1150], to: [950, -1080], rot: [5, -7], seed: 4, w: 357, h: 238 },
  { from: [980, -1120], to: [-980, 1180], rot: [-8, 4], seed: 5, w: 408, h: 264 },
];
const passWindow = (i: number, k: number): [number, number] => {
  const start = i * 4 + k * 20;
  return [start, start + (k === 0 ? 16 : 12)];
};
const FlyCard: React.FC<{ fly: Fly; i: number; frame: number }> = ({ fly, i, frame }) => {
  let active: [number, number] | null = null;
  for (let k = 0; k < 2; k++) {
    const [s, e] = passWindow(i, k);
    if (frame >= s && frame < e) {
      active = [s, e];
      break;
    }
  }
  if (!active) return null;
  const p = interpolate(frame, active, [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.in(Easing.quad) });
  const x = fly.from[0] + (fly.to[0] - fly.from[0]) * p;
  const y = fly.from[1] + (fly.to[1] - fly.from[1]) * p;
  return (
    <div style={{ position: 'absolute', left: 540 - fly.w / 2, top: SAFE_CY - fly.h / 2, transform: `translate(${x}px, ${y}px) rotate(${fly.rot[0] + (fly.rot[1] - fly.rot[0]) * p}deg) scale(${1.5 + 1.5 * p})`, filter: `blur(${1 + 4 * p}px)` }}>
      <Card w={fly.w} h={fly.h} seed={fly.seed} style={{ boxShadow: '0 12px 40px rgba(0,0,0,0.25)' }} />
    </div>
  );
};

export const SmashCutVertical: React.FC = () => {
  const frame = useCurrentFrame();
  if (frame >= CUT) return <FakeDashboardV variant="B" />;
  const bgScale = interpolate(frame, [0, CUT], [1, 1.55], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.in(Easing.quad) });
  const bgRot = interpolate(frame, [0, CUT], [0, 1.8], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.in(Easing.quad) });
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, overflow: 'hidden', position: 'relative' }}>
      <div style={{ width: 1080, height: 1920, transform: `scale(${bgScale}) rotate(${bgRot}deg)`, transformOrigin: `50% ${SAFE_CY}px`, filter: 'blur(1.5px)' }}>
        <FakeDashboardV variant="A" />
      </div>
      {FLIES.map((fly, i) => (
        <FlyCard key={i} fly={fly} i={i} frame={frame} />
      ))}
    </div>
  );
};
