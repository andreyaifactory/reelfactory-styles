// bottom-push-stack-wipe · 竖版 9:16（1080×1920）。
// 保留：三次推入起始 18/55/92、每次 30f 重 ease-out bezier(0.12,0.9,0.2,1)、新章连底色从底边推入把旧章顶出、上缘接缝阴影。
// 竖版：推入距离 1080→1920（整屏高）；窗口卡 860 宽保留、卡高 430→640（竖画面更高），卡心钉在安全区中心 y 835；
// 底色装饰条移到安全区内（左上 y 300、右下 y 1360，避开按钮栏 x>940）。
// 以下为横版原注释：
// 换章手法：新场景连底色整屏从底边向上推入，把旧场景顶出画外，连推三章（三种饱和底色，每章中央钉一张灰阶窗口卡随底色走）。
import React from 'react';
import { AbsoluteFill, useCurrentFrame, interpolate, Easing } from 'remotion';
import { Card, G } from '../../_fixtures/Fixtures';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const BOTTOM_PUSH_STACK_WIPE_VERTICAL_DURATION = 140;
const H = 1920;
const CHAPTERS = [{ color: G.bg }, { color: '#2bac76' }, { color: '#36c5f0' }, { color: '#e01e5a' }];
const PUSH_STARTS = [18, 55, 92];
const PUSH_DUR = 30;
const heavyEaseOut = Easing.bezier(0.12, 0.9, 0.2, 1);

const ChapterScene: React.FC<{ chapter: number }> = ({ chapter }) => (
  <AbsoluteFill style={{ background: CHAPTERS[chapter].color }}>
    {chapter > 0 && (
      <>
        <div style={{ position: 'absolute', top: 290, left: 90, width: 440, height: 28, borderRadius: 14, background: 'rgba(255,255,255,0.28)' }} />
        <div style={{ position: 'absolute', top: 1360, left: 380, width: 340, height: 28, borderRadius: 14, background: 'rgba(255,255,255,0.22)' }} />
        <div style={{ position: 'absolute', top: 260, right: 120, width: 100, height: 100, borderRadius: '50%', background: 'rgba(255,255,255,0.18)' }} />
      </>
    )}
    <div style={{ position: 'absolute', left: 110, top: SAFE_CY - 346, boxShadow: '0 30px 80px rgba(0,0,0,0.28)', borderRadius: 18 }}>
      <div style={{ width: 860, background: '#f2f2f0', borderRadius: '18px 18px 0 0', height: 52, display: 'flex', alignItems: 'center', gap: 10, padding: '0 22px', boxSizing: 'border-box', border: `2px solid ${G.border}`, borderBottom: 'none' }}>
        {['#e0605a', '#e8b93e', '#67bb5a'].map((dot, i) => (
          <div key={i} style={{ width: 16, height: 16, borderRadius: 8, background: dot }} />
        ))}
        <div style={{ marginLeft: 18, height: 14, width: 220, background: G.bar, borderRadius: 7 }} />
      </div>
      <Card w={860} h={640} seed={chapter + 2} style={{ borderRadius: '0 0 18px 18px', padding: 34 }} />
    </div>
  </AbsoluteFill>
);

export const BottomPushStackWipeVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const progress = PUSH_STARTS.map((s) => interpolate(frame, [s, s + PUSH_DUR], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: heavyEaseOut }));
  return (
    <AbsoluteFill style={{ overflow: 'hidden', background: G.bg }}>
      {CHAPTERS.map((_, i) => {
        const pushedIn = i === 0 ? 1 : progress[i - 1];
        const pushedOut = i < CHAPTERS.length - 1 ? progress[i] : 0;
        const y = (1 - pushedIn) * H - pushedOut * H;
        if (y <= -H || y >= H) return null;
        return (
          <AbsoluteFill key={i} style={{ transform: `translateY(${y}px)` }}>
            <ChapterScene chapter={i} />
            {i > 0 && <div style={{ position: 'absolute', top: -48, left: 0, right: 0, height: 48, background: 'linear-gradient(to top, rgba(0,0,0,0.30), rgba(0,0,0,0))', opacity: pushedIn < 1 ? 1 : 0 }} />}
          </AbsoluteFill>
        );
      })}
    </AbsoluteFill>
  );
};
