// text-as-mask · 竖版 9:16（1080×1920）。
// 时间轴同横版（0–20f hold → 20–100f 字内漂移 → 100–130f mask ×26 放大溢出 + 全屏层淡入 → 130–150f 静止）。
// 竖版：字内素材换竖版假 App（FakeDashboardV A）；"SCALE" 字号 290 横向占满约 900px，
// 字心对准安全区中心；横向漂移量随画宽收为 ±70；去掉底部演示注释（落在安全区外）。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const TEXT_AS_MASK_VERTICAL_DURATION = 150;

const FS = 290;
const BASE = SAFE_CY + FS * 0.36; // 基线：让大写字身中心落在安全区中心
const MASK_SVG = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920"><text x="540" y="${BASE}" font-family="Helvetica, Arial, sans-serif" font-size="${FS}" font-weight="900" letter-spacing="-7" text-anchor="middle" fill="white">SCALE</text></svg>`;
const MASK_URL = `url("data:image/svg+xml,${encodeURIComponent(MASK_SVG)}")`;
// 放大原点：字母 L 的竖笔（横版 61.5% → 竖版按字号/画宽换算 ≈ 65.5%），纵向取字身中心
const ORIGIN = `65.5% ${((SAFE_CY / 1920) * 100).toFixed(2)}%`;

export const TextAsMaskVertical: React.FC = () => {
  const f = useCurrentFrame();
  const clamp = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
  const endT = interpolate(f, [100, 130], [0, 1], { ...clamp, easing: Easing.bezier(0.4, 0, 0.2, 1) });
  const driftX = interpolate(f, [20, 100], [70, -70], clamp);
  const dx = f < 100 ? driftX : interpolate(endT, [0, 1], [-70, 0]);
  const dashS = interpolate(endT, [0, 1], [1.15, 1]);
  const maskS = interpolate(endT, [0, 1], [1, 26]);
  const cover = interpolate(endT, [0.25, 0.9], [0, 1], clamp);

  const dashMotion: React.CSSProperties = {
    position: 'absolute',
    inset: 0,
    transform: `translateX(${dx}px) scale(${dashS})`,
    transformOrigin: `50% ${SAFE_CY}px`,
  };

  return (
    <div style={{ width: 1080, height: 1920, background: G.ink, position: 'relative', overflow: 'hidden' }}>
      <div
        style={{
          position: 'absolute',
          inset: 0,
          transform: `scale(${maskS})`,
          transformOrigin: ORIGIN,
          WebkitMaskImage: MASK_URL,
          maskImage: MASK_URL,
          WebkitMaskRepeat: 'no-repeat',
          maskRepeat: 'no-repeat',
          WebkitMaskSize: '1080px 1920px',
          maskSize: '1080px 1920px',
        }}
      >
        <div style={{ position: 'absolute', inset: 0, transform: `scale(${1 / maskS})`, transformOrigin: ORIGIN }}>
          <div style={dashMotion}>
            <FakeDashboardV variant="A" />
          </div>
        </div>
      </div>
      <div style={{ position: 'absolute', inset: 0, opacity: cover }}>
        <div style={dashMotion}>
          <FakeDashboardV variant="A" />
        </div>
      </div>
    </div>
  );
};
