import React from 'react';
import { useCurrentFrame, useVideoConfig } from 'remotion';
import { C, E, GRAIN, SERIF, lerp, ragged, rnd, seg } from './kit';

// Субтитры «Бумажная печать»: каждая фраза — полоска бумаги с рваными торцами, которую шлёпают внизу кадра.
// Сказанное — чернила, звучащее — чернила + янтарная линейка под словом (растёт 5f), ещё не сказанное — карандаш.
// Шрифт — засечки 700, без курсива (курсив меняет ширину → строка прыгает).
// Новая фраза — новая полоска: ложится оттиском 7f (scale 1.06→1, подъём 16px), наклон у каждой свой, ±1.2°.

/** Слово полоски: времена — в кадрах ролика. */
export type StripWord = { text: string; from: number; to: number };

/**
 * Одна полоска-подпись. Чистая отрисовка: что показывать и когда, решает тот, кто её ставит.
 * from — кадр, с которого полоска лежит в кадре; frame — текущий кадр ролика.
 */
export const CaptionStrip: React.FC<{
  words: StripWord[];
  from: number;
  frame: number;
  size?: number;
  maxWidth?: number;
  seed?: number;
}> = ({ words, from, frame, size = 54, maxWidth = 900, seed = 0 }) => {
  const p = seg(frame, from, from + 7, E.press);
  const tilt = (rnd(seed * 7.3 + 1) - 0.5) * 2.4;
  const n = 5;
  const L = ragged(seed * 11 + 3, n, 6), R = ragged(seed * 11 + 40, n, 6);
  const T = ragged(seed * 11 + 80, 16, 2.5), B = ragged(seed * 11 + 120, 16, 2.5);
  const poly = [
    ...T.map((d, k) => `${(k / 16) * 100}% ${3 + d}px`),
    ...R.map((d, k) => `calc(100% - ${8 + d}px) ${(k / n) * 100}%`),
    ...B.map((d, k) => `${(1 - k / 16) * 100}% calc(100% - ${3 + d}px)`),
    ...L.map((d, k) => `${8 + d}px ${(1 - k / n) * 100}%`),
  ].join(',');
  return (
    <div
      style={{
        display: 'inline-block',
        maxWidth,
        opacity: Math.min(1, p * 2.5),
        transform: `translateY(${lerp(p, 16, 0)}px) rotate(${tilt}deg) scale(${lerp(p, 1.06, 1)})`,
        filter: `drop-shadow(0 ${lerp(p, 18, 6)}px ${lerp(p, 22, 9)}px rgba(40,28,14,0.32))`,
      }}
    >
      <div
        style={{
          position: 'relative',
          background: '#fbf9f4',
          clipPath: `polygon(${poly})`,
          padding: `${Math.round(size * 0.24)}px ${Math.round(size * 0.62)}px ${Math.round(size * 0.3)}px`,
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          columnGap: Math.round(size * 0.3),
          rowGap: Math.round(size * 0.08),
          fontFamily: SERIF,
          fontSize: size,
          fontWeight: 700,
          letterSpacing: '-0.01em',
          lineHeight: 1.18,
        }}
      >
        <div style={{ position: 'absolute', inset: 0, backgroundImage: GRAIN, opacity: 0.35, mixBlendMode: 'multiply', pointerEvents: 'none' }} />
        {words.map((w, i) => {
          const active = frame >= w.from && frame < w.to + 2;
          const said = frame >= w.to;
          const u = active ? seg(frame, w.from, w.from + 5, E.outCubic) : 0;
          return (
            <span key={i} style={{ position: 'relative', color: active || said ? C.ink : C.pencil }}>
              {w.text}
              <span style={{ position: 'absolute', left: 0, right: 0, bottom: -Math.round(size * 0.06), height: Math.max(4, Math.round(size * 0.08)), background: C.amber, transform: `scaleX(${u})`, transformOrigin: '0 50%' }} />
            </span>
          );
        })}
      </div>
    </div>
  );
};

/** Слово из расшифровки: время в секундах. Таймкоды — whisper-cli (-ojf -ml 1 -sow). */
export type Word = { t: string; s: number; e: number };

/**
 * Субтитры ролика целиком: фразы по 2–6 слов (разрыв на . ? ! и на паузе >0.3s, одиночное слово
 * приклеивается к предыдущей фразе). Полоска стоит по центру, верх — top (над нижней безопасной зоной).
 */
export const InkCaptions: React.FC<{ chunks: Word[][]; top?: number; size?: number; hideFrom?: number }> = ({ chunks, top = 1250, size = 58, hideFrom }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;
  if (hideFrom !== undefined && f >= hideFrom) return null;
  const idx = chunks.findIndex((c, i) => {
    const start = c[0].s - 0.08;
    const next = chunks[i + 1];
    const end = next ? Math.min(next[0].s - 0.08, c[c.length - 1].e + 0.6) : c[c.length - 1].e + 0.6;
    return t >= start && t < end;
  });
  if (idx < 0) return null;
  const c = chunks[idx];
  const from = Math.round((c[0].s - 0.08) * fps);
  return (
    <div style={{ position: 'absolute', top, left: 60, right: 60, display: 'flex', justifyContent: 'center' }}>
      <CaptionStrip
        words={c.map((w) => ({ text: w.t, from: Math.round(w.s * fps), to: Math.round(w.e * fps) }))}
        from={from}
        frame={f}
        size={size}
        maxWidth={960}
        seed={idx + 1}
      />
    </div>
  );
};
