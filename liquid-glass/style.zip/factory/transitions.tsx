import React from 'react';
import { AbsoluteFill } from 'remotion';
import type { TransitionSpec } from '../../../core/transitions';
import type { StyleSeamProps } from '../../../core/style-contract';
import { C, E, IRIS, lerp, seg } from '../kit/kit';

/**
 * Жидкие склейки «Жидкого стекла» для ядра фабрики.
 *
 * В ките пака переход видит оба кадра сразу (`a` и `b`). В фабрике блоки не
 * накладываются: уход живёт в последних кадрах старого блока, приход — в первых
 * кадрах нового. Поэтому каждая склейка здесь — одно движение стекла, воды или
 * света, разрезанное по стыку: к последнему кадру ухода старый кадр закрыт
 * целиком (матовым стеклом, жидкостью, светом), с первого кадра прихода
 * покрытие уходит и открывает новый. Ничего не бьётся и не вылетает за край.
 */

const W = 1080;
const H = 1920;
/** Центр композиции пака: туда падает капля и там открывается линза. */
const CX = 540;
const CY = 835;

/** Жидкость капли: светлое ядро, перелив, глубокая ночь по краю. */
const LIQUID = `radial-gradient(circle at ${CX}px ${CY - 60}px, #ffffff 0%, ${C.pink} 7%, ${C.violet} 24%, #2b1d8f 52%, #120a3d 78%, ${C.bg} 100%)`;
/** Мягкий свет, в который уходит кадр: белое ядро, фиолетовый ореол, ночь. */
const LIGHT = `radial-gradient(900px 1100px at 50% 44%, #ffffff 0%, #e6dcff 28%, ${C.violet} 62%, ${C.bg2} 100%)`;

/** Волнистый круг капли: контур дрожит, пока растекается, и успокаивается к краю кадра. */
const wobblyCircle = (r: number, calm: number, seed: number) =>
  Array.from({ length: 72 }, (_, i) => {
    const th = (i / 72) * Math.PI * 2;
    const k = 1 + 0.035 * (1 - calm) * Math.sin(5 * th + seed * 0.6) + 0.015 * (1 - calm) * Math.sin(9 * th - seed * 0.4);
    return `${(CX + r * k * Math.cos(th)).toFixed(1)}px ${(CY + r * k * Math.sin(th)).toFixed(1)}px`;
  }).join(', ');

/** Лист толстого матового стекла с радужной кромкой. top — верхний край, bottom — нижний (в пикселях кадра). */
const FrostSheet: React.FC<{ top: number; bottom: number; tint: number }> = ({ top, bottom, tint }) => (
  <div
    style={{
      position: 'absolute',
      left: -200,
      width: W + 400,
      top,
      height: Math.max(0, bottom - top),
      transform: 'rotate(-7deg)',
      backdropFilter: 'blur(40px) saturate(1.6)',
      WebkitBackdropFilter: 'blur(40px) saturate(1.6)',
      background: `linear-gradient(180deg, rgba(255,255,255,0.24), rgba(255,255,255,0.08) 12%, rgba(255,255,255,0.05) 88%, rgba(255,255,255,0.2)), rgba(17,13,34,${tint})`,
      borderTop: '3px solid rgba(255,255,255,0.75)',
      borderBottom: '3px solid rgba(255,255,255,0.55)',
      boxShadow: '0 -20px 60px rgba(143,107,255,0.25), 0 20px 60px rgba(70,224,255,0.2)',
      pointerEvents: 'none',
    }}
  >
    <div style={{ position: 'absolute', left: 0, right: 0, top: 8, height: 26, background: IRIS, opacity: 0.35, filter: 'blur(10px)' }} />
    <div style={{ position: 'absolute', left: 0, right: 0, bottom: 8, height: 22, background: IRIS, opacity: 0.25, filter: 'blur(10px)' }} />
  </div>
);

/**
 * Стеклянная шторка: толстое матовое стекло поднимается снизу и накрывает кадр,
 * затем уходит вверх — под ним уже новый. Одно движение вверх на два блока.
 */
const GlassWipe: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  // Лист выше кадра: наклон -7° не должен открыть углы.
  const reach = 520;
  if (phase === 'out') {
    const p = E.flow(t);
    const top = lerp(p, H + 80, -reach);
    const soft = seg(t, 0.55, 1, E.inCubic);
    return (
      <>
        <AbsoluteFill style={{ filter: soft > 0 ? `blur(${18 * soft}px)` : undefined }}>{children}</AbsoluteFill>
        <FrostSheet top={top} bottom={H + reach} tint={0.35 + 0.4 * soft} />
      </>
    );
  }
  const p = E.flow(t);
  const bottom = lerp(p, H + reach, -80);
  const soft = 1 - seg(t, 0, 0.45, E.outCubic);
  return (
    <>
      <AbsoluteFill style={{ filter: soft > 0 ? `blur(${18 * soft}px)` : undefined }}>{children}</AbsoluteFill>
      <FrostSheet top={-reach} bottom={bottom} tint={0.35 + 0.4 * soft} />
    </>
  );
};

/**
 * Капля: капля падает в центр и разливается жидкостью на весь кадр; в жидкости
 * волнистым кругом раскрывается новый кадр, по краю бегут светлые круги.
 */
const DropReveal: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  if (phase === 'out') {
    const fall = seg(t, 0, 0.45, E.inCubic);
    const spread = seg(t, 0.4, 1, E.flow);
    const R = lerp(spread, 30, 2300);
    return (
      <>
        {children}
        {spread > 0 && (
          <AbsoluteFill style={{ background: LIQUID, clipPath: `polygon(${wobblyCircle(R, spread, t * 30)})` }} />
        )}
        {spread === 0 && (
          <div
            style={{
              position: 'absolute',
              left: CX - 28,
              top: lerp(fall, CY - 420, CY) - 34,
              width: 56,
              height: 68,
              borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
              background: `radial-gradient(circle at 34% 30%, #ffffff 0%, ${C.pink} 18%, ${C.violet} 52%, #3a2ab0 100%)`,
              boxShadow: '0 0 30px rgba(143,107,255,0.6)',
            }}
          />
        )}
      </>
    );
  }
  const p = E.flow(t);
  const R = lerp(p, 30, 2250);
  return (
    <>
      <AbsoluteFill style={{ background: LIQUID }} />
      <AbsoluteFill
        style={{
          clipPath: `polygon(${wobblyCircle(R, p, 30 + t * 30)})`,
          transform: `scale(${lerp(p, 1.08, 1)})`,
          transformOrigin: `${CX}px ${CY}px`,
        }}
      >
        {children}
      </AbsoluteFill>
      {p < 1 && (
        <svg width={W} height={H} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
          <circle cx={CX} cy={CY} r={R} fill="none" stroke="rgba(255,255,255,0.7)" strokeWidth={4} opacity={1 - p} />
          <circle cx={CX} cy={CY} r={R + 18} fill="none" stroke={C.violet} strokeWidth={16} opacity={0.4 * (1 - p)} style={{ filter: 'blur(8px)' }} />
        </svg>
      )}
    </>
  );
};

/** Фильтр жидкой волны: кадр плывёт, как отражение в воде. */
const RippleDefs: React.FC<{ id: string; s: number; p: number }> = ({ id, s, p }) => (
  <svg width={0} height={0} style={{ position: 'absolute' }}>
    <filter id={id} x="0" y="0" width="100%" height="100%">
      <feTurbulence type="fractalNoise" baseFrequency={`${0.004 + 0.002 * p} ${0.014 + 0.006 * p}`} numOctaves={2} seed={3} result="t" />
      <feDisplacementMap in="SourceGraphic" in2="t" scale={95 * s} xChannelSelector="R" yChannelSelector="G" />
    </filter>
  </svg>
);

/**
 * Жидкая волна: кадр плывёт, как отражение в воде, и тонет в жидком свете;
 * на гребне волны из света выплывает новый и успокаивается.
 */
const Ripple: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  // Волна одна на стык: на уходе нарастает, на приходе стихает.
  const s = phase === 'out' ? E.inOutCubic(t) : 1 - E.inOutCubic(t);
  const p = phase === 'out' ? t * 0.5 : 0.5 + t * 0.5;
  const id = `lg-ripple-${phase}`;
  const wash = phase === 'out' ? seg(t, 0.35, 1, E.inCubic) : 1 - seg(t, 0, 0.65, E.outCubic);
  return (
    <>
      <RippleDefs id={id} s={s} p={p} />
      <AbsoluteFill style={{ filter: `url(#${id}) blur(${10 * s}px)`, transform: `scale(${1 + 0.1 * s})` }}>{children}</AbsoluteFill>
      <AbsoluteFill
        style={{
          background: `radial-gradient(1000px 1300px at 50% 44%, ${C.violet} 0%, rgba(70,224,255,0.55) 38%, ${C.bg2} 78%, ${C.bg} 100%)`,
          opacity: wash,
          pointerEvents: 'none',
        }}
      />
    </>
  );
};

/**
 * Нырок в линзу: в центре кадра проступает толстая линза, камера ныряет в неё —
 * линза разрастается на весь кадр, внутри свет; на приходе радужная кромка
 * линзы уходит за края, и из света проступает новый кадр.
 */
const LensDive: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  if (phase === 'out') {
    const open = E.jelly(seg(t, 0, 0.45));
    const dive = seg(t, 0.35, 1, E.inCubic);
    // К последнему кадру ухода линза накрывает весь кадр, даже его нижние углы.
    const R = lerp(Math.max(dive, seg(t, 0.45, 0.88)), 170 * open, 2300);
    return (
      <>
        <AbsoluteFill style={{ transform: `scale(${1 + 0.4 * dive})`, transformOrigin: `${CX}px ${CY}px`, filter: `blur(${10 * dive}px)` }}>
          {children}
        </AbsoluteFill>
        {R > 1 && (
          <div
            style={{
              position: 'absolute',
              left: CX - R,
              top: CY - R,
              width: R * 2,
              height: R * 2,
              borderRadius: '50%',
              overflow: 'hidden',
              boxShadow: `0 30px 70px rgba(4,2,20,${0.5 * (1 - dive)}), inset 0 0 0 3px rgba(255,255,255,0.6)`,
            }}
          >
            {/* Внутри линзы — тот же кадр, увеличенный; при нырке его заливает свет. */}
            <div style={{ position: 'absolute', left: R - CX, top: R - CY, width: W, height: H, transform: `scale(${lerp(dive, 1.7, 2.6)})`, transformOrigin: `${CX}px ${CY}px` }}>
              {children}
            </div>
            <div style={{ position: 'absolute', left: R - CX, top: R - CY, width: W, height: H, background: LIGHT, opacity: seg(t, 0.45, 0.88, E.inOutCubic) }} />
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: `radial-gradient(circle, rgba(255,255,255,0) 70%, rgba(70,224,255,0.3) 84%, rgba(255,143,210,0.3) 93%, rgba(255,255,255,0.65) 99%)` }} />
            <div style={{ position: 'absolute', left: '16%', top: '10%', width: '42%', height: '22%', borderRadius: '50%', background: 'radial-gradient(ellipse, rgba(255,255,255,0.55), rgba(255,255,255,0) 70%)', transform: 'rotate(-28deg)' }} />
          </div>
        )}
      </>
    );
  }
  const p = E.glide(t);
  const R = lerp(E.outCubic(t), 1150, 2600);
  const light = 1 - seg(t, 0, 0.7, E.outCubic);
  return (
    <>
      <AbsoluteFill style={{ transform: `scale(${lerp(p, 1.15, 1)})`, transformOrigin: `${CX}px ${CY}px`, filter: light > 0 ? `blur(${14 * light}px)` : undefined }}>
        {children}
      </AbsoluteFill>
      <AbsoluteFill style={{ background: LIGHT, opacity: light, pointerEvents: 'none' }} />
      <svg width={W} height={H} style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'visible' }}>
        <defs>
          <linearGradient id="lg-lens-rim" x1="0" x2="1">
            <stop offset="0" stopColor={C.cyan} />
            <stop offset="0.38" stopColor={C.violet} />
            <stop offset="0.7" stopColor={C.pink} />
            <stop offset="1" stopColor={C.peach} />
          </linearGradient>
        </defs>
        <circle cx={CX} cy={CY} r={R} fill="none" stroke="url(#lg-lens-rim)" strokeWidth={40} opacity={0.5 * (1 - t)} style={{ filter: 'blur(14px)' }} />
        <circle cx={CX} cy={CY} r={R} fill="none" stroke="rgba(255,255,255,0.8)" strokeWidth={4} opacity={1 - t} />
      </svg>
    </>
  );
};

/** Расфокус в свет: кадр расплывается и уходит в мягкий свет, из света проступает следующий. */
const Defocus: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  const k = phase === 'out' ? E.inCubic(t) : 1 - E.outCubic(t);
  return (
    <>
      <AbsoluteFill style={{ filter: k > 0 ? `blur(${36 * k}px) brightness(${1 + 0.6 * k})` : undefined, transform: `scale(${1 + 0.06 * k})` }}>
        {children}
      </AbsoluteFill>
      <AbsoluteFill style={{ background: LIGHT, opacity: Math.pow(k, 1.6), pointerEvents: 'none' }} />
    </>
  );
};

export const transitions: Record<string, TransitionSpec> = {
  'glass-wipe': {
    what: 'толстое матовое стекло поднимается снизу, накрывает кадр и уходит вверх, под ним новый',
    character: 'move',
    enter: 10,
    exit: 9,
    render: GlassWipe,
    sound: 'swipe',
  },
  'drop-reveal': {
    what: 'капля падает и разливается жидкостью, в ней волнистым кругом раскрывается новый кадр',
    character: 'open',
    enter: 14,
    exit: 9,
    render: DropReveal,
  },
  ripple: {
    what: 'кадр плывёт волной и тонет в жидком свете, на гребне выплывает новый',
    character: 'move',
    enter: 12,
    exit: 10,
    render: Ripple,
  },
  'lens-dive': {
    what: 'в кадре проступает линза, камера ныряет в неё, из света проступает новый кадр',
    character: 'open',
    enter: 12,
    exit: 10,
    render: LensDive,
    sound: 'rise',
  },
  defocus: {
    what: 'кадр расфокусируется в мягкий свет, из света проступает следующий',
    character: 'move',
    enter: 9,
    exit: 8,
    render: Defocus,
  },
};

/**
 * Очередь «сам подбери»: жидкие склейки пака и растворения ядра. Сдвигов и
 * бросков нет — в этом мире ничего не вылетает за край. Нырок в линзу — сильный
 * ход, ставится руками на смену главы.
 */
export const autoTransitions = ['glass-wipe', 'drop-reveal', 'ripple', 'defocus', 'blur-through'];
