// blur-slide · 竖版 9:16（1080×1920）。
// 时间轴、缓动、词间 stagger、三通道（y/blur/opacity）完全同横版；设计坐标换成 270×480（×4 放大）。
// 竖版：主标题折成两行（"Your headline / goes here"）并放大到 40，副标题折两行 15，整组对准安全区中心（SAFE_CY）。
// 词序号跨行连续，保证 stagger 节奏与横版的 4 词 / 5 词一致。
// 以下为横版原注释：
// blur-slide — Blur Slide 逐词入场（motion-lab 定稿转原生 Remotion）
// 标题逐词入场：y 40→0 + blur 10→0 + opacity 0→1，词间 stagger 极短（1 帧量级），
// easeOutCubic——y/blur/opacity 三通道同缓动同步收敛的"专业文字 reveal"；副标题随后同法跟进。
import React from 'react';
import { DesignStage, E, lerp, seg, useT } from '../../_fixtures/Motion';
import { SAFE } from '../../_fixtures/Vertical';

export const BLUR_SLIDE_VERTICAL_DURATION = 114;

const K = 4; // 1080 / 270
const H1_LINES = [['Your', 'headline'], ['goes', 'here']];
const H2_LINES = [['Short', 'supporting', 'subtitle'], ['for', 'placeholders']];

const Lines: React.FC<{ lines: string[][]; tLine: number; gap: number; dy: number; style: React.CSSProperties }> = ({ lines, tLine, gap, dy, style }) => {
  let i = -1;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', ...style }}>
      {lines.map((ws, li) => (
        <div key={li} style={{ display: 'flex', gap: '0.32em' }}>
          {ws.map((w) => {
            i++;
            const p = seg(tLine, i * gap, i * gap + 0.32, E.outCubic);
            return (
              <span key={w} style={{ opacity: p, transform: `translateY(${lerp(p, dy, 0)}px)`, filter: `blur(${(1 - p) * 10}px)` }}>
                {w}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

export const BlurSlideVertical: React.FC = () => {
  const t = useT();
  return (
    <DesignStage w={270} h={480} bg="#0a0b10">
      <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE.top / K, height: (SAFE.bottom - SAFE.top) / K, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14 }}>
        <Lines lines={H1_LINES} tLine={seg(t, 0.06, 0.62)} gap={0.055} dy={40} style={{ fontWeight: 800, fontSize: 40, lineHeight: 1.12, fontFamily: '-apple-system,sans-serif', color: '#eef1fa', letterSpacing: '-0.5px' }} />
        <Lines lines={H2_LINES} tLine={seg(t, 0.34, 0.9)} gap={0.04} dy={26} style={{ fontWeight: 400, fontSize: 15, lineHeight: 1.4, fontFamily: '-apple-system,sans-serif', color: '#7d86a3' }} />
      </div>
    </DesignStage>
  );
};
