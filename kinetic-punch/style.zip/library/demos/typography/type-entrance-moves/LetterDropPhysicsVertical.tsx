// letter-drop-physics · 竖版 9:16（1080×1920）。
// 保留：逐字起落 10+i*5、重力下落 T_FALL 24f、两次衰减弹跳 30%/9%（16f/8f）、落地 ±6° 歪角与 ±5px 错位、帧 110 齐整回正 6f、116–150 静止。
// 竖版：一行 7 字 "GRAVITY"（1050 宽）放不下 → 两行 "GRA" / "VITY"，每行有自己的地板线；字号 140→190，槽宽 150→200；
// 下落距离 720→900（竖画面更高，落差按画高放大，用时不变 → 速度按比例放大，已写在此）。两行整组对准安全区中心。
// 以下为横版原注释：
// 字符坠落堆积（letter-drop-physics）——"GRAVITY" 7 字符各自绝对定位，第 i 字符从帧 10+i*5 起下落：
// ① 重力加速掉到基线（地板线可见）；② 落地后 2 次衰减弹跳，落地瞬间 rotate 到 seed hash ±6° 小歪角并保持；
// ③ 帧 110 一拍：6f ease-out 全体齐整回正（rotate→0、偏移→0、scale 1.06→1），帧 116–150 真静止收尾。
import React from 'react';
import { useCurrentFrame, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const LETTER_DROP_PHYSICS_VERTICAL_DURATION = 150;
const h = (n: number) => {
  const s = Math.sin(n * 127.3) * 43758.5453;
  return s - Math.floor(s);
};
const LINES = ['GRA', 'VITY'];
const SLOT_W = 200;
const FONT = 190;
const LINE_H = 300;
const DROP = 900;
const T_FALL = 24;
const T_B1 = 16;
const T_B2 = 8;
const SNAP = 110;
const SNAP_DUR = 6;
const easeOutCubic = Easing.out(Easing.cubic);
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const dropY = (t: number): number => {
  if (t <= 0) return -DROP;
  if (t < T_FALL) return -DROP + DROP * (t / T_FALL) ** 2;
  if (t < T_FALL + T_B1) {
    const u = (t - T_FALL) / T_B1;
    return -DROP * 0.3 * 4 * u * (1 - u);
  }
  if (t < T_FALL + T_B1 + T_B2) {
    const u = (t - T_FALL - T_B1) / T_B2;
    return -DROP * 0.09 * 4 * u * (1 - u);
  }
  return 0;
};

export const LetterDropPhysicsVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const snap = easeOutCubic(clamp01((frame - SNAP) / SNAP_DUR));
  const top0 = SAFE_CY - LINE_H; // 第一行字顶
  let idx = 0;
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, overflow: 'hidden', position: 'relative' }}>
      {LINES.map((line, li) => {
        const w = line.length * SLOT_W;
        const left = (1080 - w) / 2;
        const restTop = top0 + li * LINE_H;
        return (
          <React.Fragment key={li}>
            <div style={{ position: 'absolute', left: left - 50, top: restTop + FONT + 14, width: w + 100, height: 8, background: G.bar, borderRadius: 4 }} />
            {line.split('').map((ch, ci) => {
              const i = idx++;
              const t = frame - (10 + i * 5);
              const y = dropY(t);
              const landP = clamp01((t - T_FALL) / 6);
              const rot = (h(i + 1) - 0.5) * 12 * landP * (1 - snap);
              const jitter = (h(i + 11) - 0.5) * 10 * landP * (1 - snap);
              const scale = frame < SNAP ? 1 : 1 + 0.06 * (1 - snap);
              return (
                <div
                  key={ci}
                  style={{
                    position: 'absolute',
                    left: left + ci * SLOT_W,
                    top: restTop,
                    width: SLOT_W,
                    height: FONT,
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'center',
                    transform: `translateY(${y + jitter}px) rotate(${rot}deg) scale(${scale})`,
                    transformOrigin: '50% 100%',
                    fontFamily: 'Helvetica, Arial, sans-serif',
                    fontWeight: 800,
                    fontSize: FONT,
                    lineHeight: 1,
                    color: G.ink,
                  }}
                >
                  {ch}
                </div>
              );
            })}
          </React.Fragment>
        );
      })}
    </div>
  );
};
