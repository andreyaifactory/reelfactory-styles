// title-demote-to-label · 竖版 9:16（1080×1920）。
// 保留：两段（0–91 变体 A、92 起变体 B 带选中高亮）、显影 0–12、高亮 14–24/32–40、降格 20f inOutCubic、内容 GROW+40 生长、白闪 4f。
// 竖版：标题两行（"Running / Subagents"、"Select the / Answer"），字号 128→150；降格终点从左上 (150,110) 改为安全区左上 (80,300)，
// scale 1→0.36（竖版标签仍可读）；骨架块宽 1500→920 竖排，从 y 400 起向下生长，最后一块卡片 h 300→420，全部在 1440 以上。
// 以下为横版原注释：
// 大标题居中显影站稳一拍，随后缩小 ~0.3x 平移到左上角变小节标签，内容区（灰阶骨架块）在其下方生长。
// 附加变体（framer text-selection-title）：标题登场带文本选中蓝高亮块、随后撤掉。
import React from 'react';
import { AbsoluteFill, useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const TITLE_DEMOTE_TO_LABEL_VERTICAL_DURATION = 184;
const FONT = 'Helvetica, Arial, sans-serif';
const SEL = 'rgba(58, 128, 236, 0.35)';
const cl = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;

const Skeleton: React.FC<{ t: number }> = ({ t }) => {
  const blocks = [
    { w: 920, h: 30 },
    { w: 780, h: 30 },
    { w: 860, h: 30 },
    { w: 480, h: 30 },
    { w: 920, h: 420, card: true },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 38 }}>
      {blocks.map((b, i) => {
        const bt = interpolate(t, [i * 0.16, i * 0.16 + 0.3], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
        return (
          <div
            key={i}
            style={{
              width: b.w * (0.35 + 0.65 * bt),
              height: b.h,
              background: b.card ? G.card : G.line,
              border: b.card ? `2px solid ${G.border}` : 'none',
              borderRadius: b.card ? 18 : 15,
              opacity: bt,
              transform: `translateY(${(1 - bt) * 32}px)`,
              boxSizing: 'border-box',
            }}
          />
        );
      })}
    </div>
  );
};

const DemoteScene: React.FC<{ frame: number; title: string[]; withSelection: boolean }> = ({ frame, title, withSelection }) => {
  const SEL_ON = 14;
  const SEL_OFF = 32;
  const DEMOTE = withSelection ? 44 : 32;
  const GROW = DEMOTE + 12;
  const rev = interpolate(frame, [0, 12], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const dem = interpolate(frame, [DEMOTE, DEMOTE + 20], [0, 1], { ...cl, easing: Easing.inOut(Easing.cubic) });
  const scale = interpolate(dem, [0, 1], [1, 0.36]);
  const x = interpolate(dem, [0, 1], [540, 80]);
  const y = interpolate(dem, [0, 1], [SAFE_CY, 300]);
  let selLeft = 0;
  let selWidth = 0;
  if (withSelection) {
    const on = interpolate(frame, [SEL_ON, SEL_ON + 10], [0, 1], { ...cl, easing: Easing.out(Easing.quad) });
    const off = interpolate(frame, [SEL_OFF, SEL_OFF + 8], [0, 1], { ...cl, easing: Easing.in(Easing.quad) });
    selLeft = off * 100;
    selWidth = Math.max(0, on * 100 - selLeft);
  }
  const growT = interpolate(frame, [GROW, GROW + 40], [0, 1], cl);
  return (
    <AbsoluteFill style={{ background: G.bg }}>
      <div style={{ position: 'absolute', left: 80, top: 420 }}>
        <Skeleton t={growT} />
      </div>
      <div style={{ position: 'absolute', left: x, top: y, transform: `translate(${-(1 - dem) * 50}%, -50%) scale(${scale})`, transformOrigin: 'left center', opacity: rev, filter: `blur(${(1 - rev) * 12}px)` }}>
        <div style={{ position: 'relative', fontFamily: FONT, fontWeight: 800, fontSize: 150, lineHeight: 1.04, color: G.ink, letterSpacing: -3, whiteSpace: 'nowrap', padding: '10px 18px', textAlign: dem > 0.5 ? 'left' : 'center' }}>
          {withSelection && selWidth > 0 && <div style={{ position: 'absolute', left: `${selLeft}%`, top: 8, width: `${selWidth}%`, height: 'calc(100% - 16px)', background: SEL, borderRadius: 6 }} />}
          {title.map((l) => (
            <div key={l} style={{ position: 'relative' }}>
              {l}
            </div>
          ))}
        </div>
      </div>
    </AbsoluteFill>
  );
};

export const TitleDemoteToLabelVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const SPLIT = 92;
  if (frame < SPLIT) return <DemoteScene frame={frame} title={['Running', 'Subagents']} withSelection={false} />;
  const f = frame - SPLIT;
  const flash = interpolate(f, [0, 4], [1, 0], cl);
  return (
    <AbsoluteFill>
      <DemoteScene frame={f} title={['Select the', 'Answer']} withSelection />
      <AbsoluteFill style={{ background: '#fff', opacity: flash, pointerEvents: 'none' }} />
    </AbsoluteFill>
  );
};
