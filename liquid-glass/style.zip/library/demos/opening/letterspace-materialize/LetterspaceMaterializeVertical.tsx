// letterspace-materialize · 竖版 9:16（1080×1920）。
// 描画参数同横版（全字符 START 16 统一起笔、DUR 52 同帧齐收、easeInOut、收笔提亮 8f）；
// 竖版：SUPERHUMAN 拆两行（SUPER / HUMAN），字形放大 1.5 倍（117×96），整组对准安全区中心；
// 暮色光带随字组下移，留在安全区下半。
import React from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame } from 'remotion';
import { SafeCenter, SAFE_CY } from '../../_fixtures/Vertical';

export const LETTERSPACE_MATERIALIZE_VERTICAL_DURATION = 110;

const GLYPHS: Record<string, string> = {
  S: 'M 62 13 C 51 4, 18 3, 15 15 C 12 26, 29 29, 39 31 C 50 33, 66 37, 63 48 C 60 59, 21 61, 11 50',
  U: 'M 12 5 L 12 40 C 12 59, 66 59, 66 40 L 66 5',
  P: 'M 12 59 L 12 5 L 44 5 C 64 5, 64 32, 44 32 L 12 32',
  E: 'M 62 5 L 12 5 L 12 59 L 62 59 M 12 31 L 56 31',
  R: 'M 12 59 L 12 5 L 44 5 C 64 5, 64 31, 44 31 L 12 31 M 42 31 L 64 59',
  H: 'M 12 5 L 12 59 M 66 5 L 66 59 M 12 31 L 66 31',
  M: 'M 8 59 L 8 6 L 39 38 L 70 6 L 70 59',
  A: 'M 7 59 L 39 5 L 71 59 M 17 41 L 61 41',
  N: 'M 12 59 L 12 5 L 66 59 L 66 5',
};

const ROWS = ['SUPER', 'HUMAN'];
const START = 16;
const DUR = 52;
const K = 1.5;

export const LetterspaceMaterializeVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [START, START + DUR], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const e = p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
  const doneGlow = interpolate(frame, [START + DUR, START + DUR + 8], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const glowAmt = p >= 1 ? doneGlow : p > 0.7 ? (p - 0.7) / 0.3 : 0;

  const letter = (ch: string, key: number) => (
    <svg key={key} width={78 * K} height={64 * K} viewBox="0 0 78 64" style={{ overflow: 'visible', display: 'block' }}>
      {p > 0 && (
        <path
          d={GLYPHS[ch]}
          fill="none"
          stroke="#f4f2f8"
          strokeWidth={5.5}
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={1 - e}
          style={{ filter: `drop-shadow(0 0 ${6 + glowAmt * 10}px rgba(240,235,255,${0.35 + glowAmt * 0.35}))` }}
        />
      )}
    </svg>
  );

  return (
    <AbsoluteFill style={{ background: 'linear-gradient(178deg, #2c2a55 0%, #3d3465 30%, #241f40 58%, #0e0c1e 100%)' }}>
      <div
        style={{
          position: 'absolute', left: 0, right: 0, top: SAFE_CY + 120, height: 260,
          background: 'linear-gradient(180deg, rgba(232,150,170,0) 0%, rgba(226,140,165,0.20) 45%, rgba(120,100,170,0.12) 75%, rgba(0,0,0,0) 100%)',
          filter: 'blur(24px)',
        }}
      />
      <div
        style={{
          position: 'absolute', right: -60, top: SAFE_CY - 380, width: 620, height: 300,
          background: 'radial-gradient(ellipse at center, rgba(216,120,160,0.16) 0%, rgba(0,0,0,0) 70%)',
          filter: 'blur(30px)',
        }}
      />
      <SafeCenter style={{ gap: 64 }}>
        {ROWS.map((row, r) => (
          <div key={r} style={{ display: 'flex', gap: 40, alignItems: 'center' }}>
            {row.split('').map((ch, i) => letter(ch, i))}
          </div>
        ))}
      </SafeCenter>
    </AbsoluteFill>
  );
};
