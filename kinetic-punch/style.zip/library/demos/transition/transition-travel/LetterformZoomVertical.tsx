// letterform-zoom · 竖版 9:16（1080×1920）。
// 保留：0–25 hold、25–85 推进（bezier 0.6,0,0.85,0.5 叠指数 scale 1→28）、盖板在 scale 15→24 退场、速度模糊 0→1.5→16 除以 scale、
// 新页面 1→1.1 跟推、85–110 落回 1。
// 竖版：标题 "DASH" 字号 560→330（宽 ≈ 935，在 960 内），字块对准安全区中心；A 字腔中心按同一 Helvetica 度量比例换算：
// x = 540 − 187×(330/560) ≈ 430，基线 y ≈ 835 + 0.36×330 ≈ 954，腔心 y ≈ 954 − 0.42×330 ≈ 815。新页面 = FakeDashboardV B。
// 以下为横版原注释：
// letterform-zoom〔转场〕：巨型标题 "DASH" 字腔透出新页面，镜头急速推进字母 A 的三角字腔，洞被撑满全屏的瞬间新页面接管，残余笔画滑出画外。
// 底层新页面静置全屏（微 dolly）；上层"米灰盖板"用 SVG <mask>（白底 + 黑字）在字形处挖洞——洞里即透出新页面；
// 对盖板整组做 transform-origin 对准 A 字腔中心的指数 scale 1→28。
import React, { useId } from 'react';
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV } from '../../_fixtures/Vertical';

export const LETTERFORM_ZOOM_VERTICAL_DURATION = 140;
const FS = 330;
const BASELINE = 954;
const ORIGIN = { x: 430, y: 815 };
const ZOOM_MAX = 28;
const titleFont: React.CSSProperties = { fontFamily: 'Helvetica Neue, Helvetica, Arial, sans-serif', fontWeight: 900, fontSize: FS };

export const LetterformZoomVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const cutId = `lfzv-cut-${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const t = interpolate(frame, [25, 85], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.bezier(0.6, 0, 0.85, 0.5) });
  const scale = Math.pow(ZOOM_MAX, t);
  const plateOpacity = interpolate(scale, [15, 24], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const visBlur = interpolate(t, [0, 0.45, 1], [0, 1.5, 16], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const blurCss = visBlur / scale;
  const bScale = frame < 85 ? interpolate(t, [0, 1], [1, 1.1]) : interpolate(frame, [85, 110], [1.1, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) });
  return (
    <AbsoluteFill style={{ background: G.bg, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, transform: `scale(${bScale})`, transformOrigin: `${ORIGIN.x}px ${ORIGIN.y}px` }}>
        <FakeDashboardV variant="B" />
      </div>
      {plateOpacity > 0 && (
        <div style={{ position: 'absolute', inset: 0, transform: `scale(${scale})`, transformOrigin: `${ORIGIN.x}px ${ORIGIN.y}px`, opacity: plateOpacity, filter: blurCss > 0.02 ? `blur(${blurCss}px)` : undefined }}>
          <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{ position: 'absolute', inset: 0, display: 'block' }}>
            <defs>
              <mask id={cutId}>
                <rect width={1080} height={1920} fill="#fff" />
                <text x={540} y={BASELINE} textAnchor="middle" fill="#000" style={titleFont}>
                  DASH
                </text>
              </mask>
            </defs>
            <rect width={1080} height={1920} fill={G.bg} mask={`url(#${cutId})`} />
            <text x={540} y={BASELINE} textAnchor="middle" fill="none" stroke={G.ink} strokeWidth={3} opacity={0.3} style={titleFont}>
              DASH
            </text>
          </svg>
          <div style={{ position: 'absolute', left: 0, right: 0, top: 1030, display: 'flex', justifyContent: 'center', gap: 16 }}>
            <div style={{ width: 260, height: 18, background: G.bar, borderRadius: 9 }} />
            <div style={{ width: 140, height: 18, background: G.line, borderRadius: 9 }} />
          </div>
        </div>
      )}
    </AbsoluteFill>
  );
};
