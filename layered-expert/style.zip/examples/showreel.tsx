import React from 'react';
import { Audio, Composition, Sequence, registerRoot, staticFile, useCurrentFrame } from 'remotion';
import {
  BigNumber, Card, Headline, LayerFonts, Phone, Script, Stage, Subs, cameraAt, ramp, type Shot, type Word,
} from '../kit/kit';
// Слова с временем чистой дорожки — из проекта шоурила.
import words from './words.json';

// Исходник шоурила `clips/layered-reel.mp4` — пример, как раскладывается ролик,
// а не сцена для запуска: это отдельная композиция со своими файлами, вне фабрики.
// В фабрике та же раскладка живёт одной главой — `factory/STYLE.md`.
//
// Шоурил стиля «Слои»: 24 с, 30 к/с. Речь с первого кадра.
// Хук общий → «1» без CapCut крупно → «2» ChatGPT и Claude → скрин статистики →
// крупный айфон с записью профиля до самого конца.
// Маска считалась на 0–13.8 с: только там графика за человеком.
const END = 720;
// Склейки самой дорожки (work/edl.json): смена плана стоит ровно на них, иначе
// видео прыгает, а через несколько кадров ещё раз прыгает зум.
const CUT = [138, 267, 408, 518] as const;
const PHONE = CUT[3];

const SHOTS: Shot[] = [
  { from: 0, zoom: [1.0, 1.06], focus: [540, 780] },
  { from: CUT[0], zoom: [1.2, 1.25], focus: [540, 0] },
  { from: CUT[1], zoom: [1.04, 1.08], focus: [540, 0] },
  // Ближе на склейке и стоит всю фразу; общий план — склейкой на следующей фразе.
  { from: CUT[2], zoom: [1.2, 1.24], focus: [540, 780] },
  { from: PHONE, zoom: [1.0, 1.06], focus: [540, 780] },
];
const BUMPS = [173, 311, 324, 421];

const SFX: Array<[number, string, number]> = [
  [1, 'swipe-2.wav', 0.5],
  [58, 'pencil-write-short.mp3', 1.2],
  [96, 'pencil-write-short.mp3', 1.2],
  [CUT[0], 'whoosh-3.wav', 0.35],
  [CUT[0] + 2, 'drop-1.wav', 0.6],
  [155, 'swipe-2.wav', 0.5],
  [173, 'enter-2.wav', 0.7],
  [181, 'pencil-write-short.mp3', 1.4],
  [CUT[1], 'whoosh-3.wav', 0.3],
  [CUT[1] + 2, 'drop-1.wav', 0.6],
  [311, 'enter-2.wav', 0.7],
  [324, 'enter-2.wav', 0.7],
  [343, 'swipe-2.wav', 0.5],
  [CUT[2], 'whoosh-3.wav', 0.3],
  [421, 'enter-2.wav', 0.75],
  [472, 'pencil-write-short.mp3', 1.2],
  [PHONE, 'whoosh-3.wav', 0.45],
  [PHONE + 9, 'snap-1.wav', 0.6],
];

const Logo: React.FC<{ src: string; size?: string }> = ({ src, size = '58%' }) => (
  <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#fff' }}>
    <img src={staticFile(src)} style={{ width: size, height: size }} />
  </div>
);

const Reel: React.FC = () => {
  const f = useCurrentFrame();
  const { zoom, focus } = cameraAt(f, SHOTS, END, BUMPS);

  const behind = (
    <>
      <Headline lines={['Трендовые', 'рилсы']} at={0} out={CUT[0]} x={540} y={235} size={130} />
      <BigNumber n="1" at={CUT[0]} out={CUT[1]} x={810} y={430} size={440} />
      <Headline lines={['Без CapCut']} at={155} out={CUT[1]} x={540} y={290} size={118} />
      <BigNumber n="2" at={CUT[1]} out={CUT[2]} x={150} y={400} size={440} />
      <Card at={324} out={CUT[2]} x={40} y={940} w={280} h={280} tilt={-7}><Logo src="claude.svg" /></Card>
      <Headline lines={['Без доп. сервисов']} at={343} out={CUT[2]} x={540} y={270} size={100} />
    </>
  );

  const front = (
    <>
      <Script text="в 2026" at={58} out={CUT[0]} x={780} y={520} rotate={-7} size={60} />
      <Script text={'с помощью\nнейросетей'} at={96} out={CUT[0]} x={40} y={640} rotate={-6} size={56} />
      <Card at={173} out={CUT[1]} x={700} y={1150} w={270} h={270} tilt={6}><Logo src="capcut.svg" size="56%" /></Card>
      {/* Росчерк зачёркивает CapCut. */}
      <Script text="" at={181} out={CUT[1]} x={690} y={1140} rotate={0} color="#4F8DF7"
        arrow={{ d: 'M10 270 C 90 190, 190 100, 290 10', w: 300, h: 280, x: 0, y: 0, stroke: 11 }} />
      <Script text="ChatGPT" at={315} out={CUT[2]} x={745} y={750} rotate={4} />
      <Card at={311} out={CUT[2]} x={735} y={830} w={270} h={270} tilt={6}><Logo src="openai.svg" /></Card>
      <Script text="Claude" at={328} out={CUT[2]} x={70} y={860} rotate={-6} />
      <Card at={421} out={PHONE + 6} x={360} y={1160} w={360} h={354} tilt={-4} src="shot.png" />
      <Script text={'статистика\nаккаунта'} at={472} out={PHONE + 6} x={40} y={1080} rotate={-6} size={54}
        arrow={{ d: 'M0 0 C 40 30, 80 50, 120 40', w: 120, h: 50, x: 200, y: 130 }} />
      {/* Запись экрана — крупно и до конца ролика; кадр за телефоном притушен. */}
      <div style={{ position: 'absolute', inset: 0, background: '#05070c', opacity: 0.4 * ramp(f, PHONE, PHONE + 12) }} />
      <Phone at={PHONE} out={END + 10} x={250} y={290} w={580} tilt={0} video="profile.mp4" />
    </>
  );

  return (
    <LayerFonts base="fonts">
      <Stage video="clean.mp4" matte="matte.webm" zoom={zoom} focus={focus} behind={behind} front={front} voice />
      {/* Под телефоном субтитры опускаются ниже его края. */}
      <Subs
        words={words as Word[]}
        accent={['capcut', 'агент']}
        area={(fr) => (fr >= CUT[2] ? { top: 1530, left: 90, right: 90 } : { top: 1480, left: 90, right: 90 })}
      />

      {SFX.map(([at, file, v]) => (
        <Sequence key={`${at}-${file}`} from={at} durationInFrames={45}>
          <Audio src={staticFile(`sfx/${file}`)} volume={v} />
        </Sequence>
      ))}
    </LayerFonts>
  );
};

registerRoot(() => (
  <Composition id="layered-showreel" component={Reel} durationInFrames={END} fps={30} width={1080} height={1920} />
));
