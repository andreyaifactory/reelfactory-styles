import type { StyleTokens } from '../../../core/style-contract';
import { C, DISPLAY, FIELDS, TEXT } from '../kit/kit';

/**
 * «Удар» в словаре ядра фабрики. Значения — из `pack.json → tokens`: плоские
 * кислотные поля (чёрный, лайм, синий, красный, белый), сверхузкий жирный капс
 * Fira Sans Extra Condensed во всю ширину кадра, Rubik 900 — всё мелкое: ярлыки,
 * подписи, имена, субтитры. Скруглений, градиентов и теней нет.
 */
export const tokens: StyleTokens = {
  name: 'Удар',

  color: {
    text: C.white,
    textMuted: C.gray,
    textFaint: '#5c5c5e',
    bg: C.black,
    bgTop: C.black,
    accent: C.lime,
    accentSoft: C.lime,
    surface: C.white,
    surfaceBorder: C.black,
    black: C.black,
    white: C.white,
    lime: C.lime,
    blue: C.blue,
    red: C.red,
    gray: C.gray,
  },

  type: {
    hero: { size: 300, weight: 900, lh: 0.84, ls: '0em', family: DISPLAY, uppercase: true },
    heroTight: { size: 220, weight: 900, lh: 0.84, ls: '0em', family: DISPLAY, uppercase: true },
    title: { size: 140, weight: 900, lh: 0.86, ls: '0em', family: DISPLAY, uppercase: true },
    stat: { size: 520, weight: 900, lh: 0.84, ls: '0em', family: DISPLAY, uppercase: true },
    label: { size: 76, weight: 900, lh: 1.0, ls: '0em', family: TEXT, uppercase: true },
    body: { size: 72, weight: 800, lh: 1.08, ls: '0em', family: TEXT },
    caption: { size: 88, weight: 900, lh: 1.08, ls: '0em', family: TEXT, uppercase: true },
  },

  /** Мир прямоугольный: ни у плашки, ни у врезки, ни у ярлыка скругления нет. */
  radius: { card: 0, capsule: 0, pill: 0, bar: 0 },

  space: { gap: 24 },

  extra: {
    /** Свечения, блика и мягкой тени нет. Тень — плоская цветная плита со сдвигом 24 px. */
    glow: 'none',
    plateShift: 24,
    /** Поля сцены: пара «поле → текст → акцент». Два одинаковых поля подряд нельзя. */
    fields: FIELDS,
  },
};
