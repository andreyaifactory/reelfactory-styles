import React from 'react';
import type { StyleCaptionProps } from '../../../core/style-contract';
import { CaptionGroup } from '../kit/kit';

/** Ключевое слово группы — самое длинное: оно несёт смысл чаще служебных. */
const keyIndex = (words: { text: string }[]) => {
  let best = 0;
  words.forEach((w, i) => {
    if (w.text.replace(/[^\p{L}\p{N}]/gu, '').length > words[best].text.replace(/[^\p{L}\p{N}]/gu, '').length) best = i;
  });
  return best;
};

/**
 * Субтитры фабрики в «Ударе»: белый Rubik 900 капсом с чёрной обводкой, без
 * плашки; слово появляется рывком, когда сказано, одно ключевое — лаймом.
 * Место и размер полосы даёт ядро, группа только рисуется в них.
 */
export const Caption: React.FC<StyleCaptionProps> = ({ page, frame, box }) => {
  const key = keyIndex(page.words);
  return (
    <div style={{ width: box.width }}>
      <CaptionGroup f={frame} size={box.fontSize} words={page.words.map((w, i) => ({ text: w.text, s: w.from, e: w.to, key: i === key }))} />
    </div>
  );
};
