import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { C, GRAIN, Tape } from '../kit/kit';

/**
 * Оправа реального скрина — вырезка на скотче: белое поле отпечатка, зерно,
 * прижатая тень, лёгкий наклон, два куска скотча на углах. Движение снимка
 * внутри (наезд, проход, дрейф) ведёт ядро.
 */
export const ScreenFrame: React.FC<{ width: number; height: number; children: React.ReactNode }> = ({
  width,
  height,
  children,
}) => {
  const frame = useCurrentFrame();
  const border = 18;
  return (
    <div style={{ position: 'relative', width, height, transform: 'rotate(-1.2deg)' }}>
      <div
        style={{
          position: 'absolute',
          inset: -border,
          background: '#fbf9f4',
          boxShadow: '0 10px 26px rgba(40,28,14,0.3)',
        }}
      >
        <AbsoluteFill style={{ backgroundImage: GRAIN, opacity: 0.35, mixBlendMode: 'multiply' }} />
      </div>
      <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: C.ink }}>{children}</div>
      <Tape f={frame} at={6} x={12} y={-8} rotate={-38} seed={3} />
      <Tape f={frame} at={9} x={width - 12} y={height + 8} rotate={-38} seed={4} />
    </div>
  );
};
