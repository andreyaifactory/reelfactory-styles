import React from 'react';
import type { StyleCaptionProps } from '../../../core/style-contract';
import { CaptionStrip } from '../kit/InkCaptions';

/**
 * Субтитры фабрики в бумажном виде: каждая страница — своя полоска бумаги.
 * Место и размер полосы даёт ядро, полоска только рисуется в них.
 */
export const Caption: React.FC<StyleCaptionProps> = ({ page, index, frame, box }) => (
  <CaptionStrip words={page.words} from={page.from} frame={frame} size={box.fontSize} maxWidth={box.width} seed={index + 1} />
);
