import React from 'react';
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, FAKE_V, VW, VH } from '../../_fixtures/Vertical';

// wireframe-draw-on · 竖版 9:16（1080×1920）：描线错峰与扫描实体化的帧参数同横版（150f）。
// 竖版：线框照竖版假 App（FakeDashboardV A：顶栏 160、2×3 卡、底部 tab 150）重画；
// 侧栏换成底部 tab 栏（同一起笔帧 20）；扫描仍从左向右，跨 1080 宽。
export const WIREFRAME_DRAW_ON_VERTICAL_DURATION = 150;

// wireframe-draw-on〔入场退场〕：界面先以蓝图细线描画成形（stroke-dashoffset
// 分组错峰），随后一条发光竖线从左向右扫过，扫过之处线框实体化为真实灰阶界面。
// 节拍：0–20 hold 空底 → 20–82 分组描线 → 88–118 光线扫描实体化 → 118–150 hold。

// FakeDashboardV A 的几何：内容区 y 160…1770，padding 36、gap 28，2 列 × 3 行
const CARD_W = (VW - FAKE_V.pad * 2 - 28) / 2; // 490
const CARD_H = (VH - FAKE_V.top - FAKE_V.tab - FAKE_V.pad * 2 - 28 * 2) / 3; // 494
const CARD_X = [FAKE_V.pad, FAKE_V.pad + CARD_W + 28];
const CARD_Y = [0, 1, 2].map((r) => FAKE_V.top + FAKE_V.pad + r * (CARD_H + 28));

const seedFrac = (i: number) => {
  const v = Math.sin(i * 127.3) * 43758.5453;
  return v - Math.floor(v);
};

export const WireframeDrawOnVertical: React.FC = () => {
  const frame = useCurrentFrame();

  // 描线进度：每组 30f 画完，start 错峰
  const draw = (start: number) =>
    interpolate(frame, [start, start + 30], [0, 1], {
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
      easing: Easing.bezier(0.4, 0, 0.3, 1),
    });

  const tSide = draw(20); // 侧栏
  const tTop = draw(30); // 顶栏
  const tCards = Array.from({ length: 6 }, (_, i) => draw(40 + i * 3)); // 卡片错峰
  const tChart = draw(52); // 折线图

  // 实体化扫描：88–118 从左向右
  const scan = interpolate(frame, [88, 118], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.bezier(0.55, 0, 0.25, 1),
  });
  const scanX = scan * VW;
  const lineOpacity = interpolate(frame, [86, 92, 112, 120], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  // 描线小工具：pathLength=1 + dashoffset 从 1 → 0
  const stroke = (t: number): React.SVGAttributes<SVGElement> => ({
    fill: 'none',
    stroke: G.mid,
    strokeWidth: 2.5,
    pathLength: 1,
    strokeDasharray: 1,
    strokeDashoffset: 1 - t,
    strokeLinecap: 'round',
    opacity: t > 0 ? 1 : 0,
  });

  // 折线图数据（seed 正弦哈希，落在右列中排卡内部）
  const chartCardX = CARD_X[1];
  const chartCardY = CARD_Y[1];
  const chartPts = Array.from({ length: 8 }, (_, i) => {
    const px = chartCardX + 50 + (i * (CARD_W - 100)) / 7;
    const py = chartCardY + 130 + seedFrac(i + 3) * 230;
    return `${px},${py}`;
  }).join(' ');

  return (
    <AbsoluteFill style={{ background: G.bg, overflow: 'hidden' }}>
      {/* —— 线框层（蓝图描线） —— */}
      <svg width={VW} height={VH} viewBox={`0 0 ${VW} ${VH}`} style={{ position: 'absolute', inset: 0 }}>
        {/* 底部 tab 栏（顶替横版侧栏，同一起笔帧） */}
        <line x1={4} y1={VH - FAKE_V.tab} x2={VW - 4} y2={VH - FAKE_V.tab} {...stroke(tSide)} />
        {Array.from({ length: 4 }).map((_, i) => (
          <rect key={`t${i}`} x={VW * ((i + 0.5) / 4) - 22} y={VH - FAKE_V.tab / 2 - 22} width={44} height={44} rx={12} {...stroke(draw(24 + i * 2))} />
        ))}

        {/* 顶栏 */}
        <line x1={4} y1={FAKE_V.top} x2={VW - 4} y2={FAKE_V.top} {...stroke(tTop)} />
        <rect x={40} y={FAKE_V.top - 82} width={52} height={52} rx={14} {...stroke(draw(32))} />
        <rect x={114} y={FAKE_V.top - 67} width={260} height={22} rx={11} {...stroke(draw(34))} />
        <circle cx={VW - 66} cy={FAKE_V.top - 56} r={26} {...stroke(draw(38))} />

        {/* 3×2 卡片：轮廓 + 内部占位线 */}
        {tCards.map((t, i) => {
          const cx = CARD_X[i % 2];
          const cy = CARD_Y[Math.floor(i / 2)];
          const titleW = (CARD_W - 36) * (0.45 + (((i + 1) * 37) % 40) / 100);
          return (
            <g key={`c${i}`}>
              <rect x={cx} y={cy} width={CARD_W} height={CARD_H} rx={14} {...stroke(t)} />
              <rect x={cx + 18} y={cy + 18} width={titleW} height={16} rx={8} {...stroke(draw(46 + i * 3))} />
              <line x1={cx + 18} y1={cy + 62} x2={cx + 18 + (CARD_W - 36) * 0.82} y2={cy + 62} {...stroke(draw(49 + i * 3))} />
              <line x1={cx + 18} y1={cy + 88} x2={cx + 18 + (CARD_W - 36) * 0.62} y2={cy + 88} {...stroke(draw(51 + i * 3))} />
              <circle cx={cx + 31} cy={cy + CARD_H - 31} r={13} {...stroke(draw(53 + i * 3))} />
            </g>
          );
        })}

        {/* 折线图（画在中列下排卡内） */}
        <polyline points={chartPts} {...stroke(tChart)} strokeWidth={3} />
      </svg>

      {/* —— 实体层：clip-path inset 从左向右展开 —— */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          clipPath: `inset(0 ${(1 - scan) * 100}% 0 0)`,
        }}
      >
        <FakeDashboardV variant="A" />
      </div>

      {/* —— 4px 发光扫描竖线（琥珀微光） —— */}
      <div
        style={{
          position: 'absolute',
          left: scanX - 2,
          top: 0,
          width: 4,
          height: VH,
          background: '#ffc46b',
          opacity: lineOpacity,
          boxShadow:
            '0 0 18px 6px rgba(232, 163, 61, 0.65), 0 0 60px 18px rgba(232, 163, 61, 0.28)',
        }}
      />
    </AbsoluteFill>
  );
};
