import React from 'react';
import { useCurrentFrame } from 'remotion';
import { Aurora } from '../kit/kit';

/**
 * Живой слой — жидкий свет пака: четыре пятна перелива медленно текут и дышат.
 * Это воздух мира, а не событие: правило «нет мёртвого кадра» выполняет сцена —
 * капля, плита, слово, камера. Пульс на долях сцена даёт своим `Aurora`.
 */
export const Ambient: React.FC = () => {
  const frame = useCurrentFrame();
  return <Aurora f={frame} theme="night" energy={0.8} />;
};
