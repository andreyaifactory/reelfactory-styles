// hit-counter · 竖版 9:16（1080×1920）。
// 保留：命中时刻 30/60/90（动画时间）、每次全局顿帧 2f（帧 remap）、卡命中前 10f ease-in 砸落、触地压扁、伤害数字 1.4→1 上浮 60 渐隐 12f、
// 计数器脉冲 1.3/1.45/1.6 指数回落 + 倾斜 −2/−4/−6 保持 + 字号逐次加大。
// 竖版：三个槽位一排 → 一列（槽 760×260，间距 60，y 420/740/1060，全部在安全区）；卡从画面上方 −700 砸落；
// 伤害数字落在卡面上方 40px（卡右侧，避开上一槽）；计数器从右上角（平台遮挡区）移到安全区右上 (right 90, top 250)。
// 以下为横版原注释：
// hit-counter 连招计数：三张功能卡接连砸入槽位，每次命中 = 全局顿帧 2f + 落点伤害数字上浮渐隐 + 右上角 ×N 计数跳字（脉冲/倾斜逐次加码）。
// 组合：hitstop + damage-number-pop + combo-counter。
import React from 'react';
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from 'remotion';
import { Card, TitleBlock, G } from '../../_fixtures/Fixtures';
import { FakeDashboardV } from '../../_fixtures/Vertical';

export const HIT_COUNTER_VERTICAL_DURATION = 150;
const HITS_T = [30, 60, 90];
const STOP = 2;
const HITS_REAL = HITS_T.map((h, i) => h + i * STOP);
const SLOT_W = 760;
const SLOT_H = 260;
const SLOT_X = (1080 - SLOT_W) / 2;
const SLOT_YS = [420, 740, 1060];
const DMG_TEXT = ['+1.2k', '+2.4k', '+4.8k'];
const PULSE = [1.3, 1.45, 1.6];
const TILT = [-2, -4, -6];

export const HitCounterVertical: React.FC = () => {
  const frame = useCurrentFrame();
  let t = frame;
  for (const h of HITS_REAL) t -= Math.min(Math.max(frame - h, 0), STOP);
  const count = HITS_T.filter((h) => t >= h).length;
  let counterScale = 1;
  let counterRot = 0;
  let counterSize = 96;
  if (count > 0) {
    const i = count - 1;
    counterScale = 1 + (PULSE[i] - 1) * Math.exp(-(t - HITS_T[i]) / 2.4);
    counterRot = TILT[i];
    counterSize = 96 + i * 16;
  }
  return (
    <AbsoluteFill style={{ background: G.bg, overflow: 'hidden' }}>
      <div style={{ filter: 'saturate(0.9)', opacity: 0.4 }}>
        <FakeDashboardV variant="B" />
      </div>
      {SLOT_YS.map((y, i) => (
        <div key={`s${i}`} style={{ position: 'absolute', left: SLOT_X, top: y, width: SLOT_W, height: SLOT_H, border: `3px dashed ${G.bar}`, borderRadius: 18, boxSizing: 'border-box' }} />
      ))}
      {HITS_T.map((hit, i) => {
        if (t < hit - 10) return null;
        const y = interpolate(t, [hit - 10, hit], [-700, SLOT_YS[i]], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.in(Easing.quad) });
        const since = t - hit;
        const squash = since >= 0 ? 1 - 0.06 * Math.exp(-since / 1.5) : 1;
        return (
          <div key={`c${i}`} style={{ position: 'absolute', left: SLOT_X, top: y, transform: `scaleY(${squash})`, transformOrigin: 'bottom center' }}>
            <Card w={SLOT_W} h={SLOT_H} seed={i + 2} style={{ boxShadow: '0 16px 48px rgba(0,0,0,0.25)' }} />
          </div>
        );
      })}
      {HITS_T.map((hit, i) => {
        const s = t - hit;
        if (s < 0 || s > 14) return null;
        const scale = interpolate(s, [0, 5], [1.4, 1], { extrapolateRight: 'clamp', easing: Easing.out(Easing.quad) });
        const rise = interpolate(s, [0, 12], [0, -60], { extrapolateRight: 'clamp', easing: Easing.out(Easing.quad) });
        const opacity = interpolate(s, [0, 4, 12], [1, 1, 0], { extrapolateRight: 'clamp' });
        return (
          <div key={`d${i}`} style={{ position: 'absolute', left: SLOT_X + SLOT_W - 150, top: SLOT_YS[i] + 40 + rise, transform: `translateX(-50%) scale(${scale})`, transformOrigin: 'center bottom', opacity }}>
            <TitleBlock text={DMG_TEXT[i]} size={84} />
          </div>
        );
      })}
      <div style={{ position: 'absolute', right: 90, top: 250, transform: `scale(${counterScale}) rotate(${counterRot}deg)`, opacity: count === 0 ? 0.25 : 1 }}>
        <div style={{ background: G.ink, color: '#fff', borderRadius: 20, padding: '10px 34px 16px', fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: counterSize, letterSpacing: -2, lineHeight: 1.1, boxShadow: '0 8px 28px rgba(0,0,0,0.3)' }}>{`×${count}`}</div>
      </div>
    </AbsoluteFill>
  );
};
