import React from 'react';
import { KineticFonts } from '../kit/kit';

/**
 * Шрифты пака — из его же файлов: при включении стиля `kit/public/` раскладывается
 * в `public/kinetic/`, туда же смотрит кит. Кадры ждут, пока Fira Sans Extra
 * Condensed и Rubik не загрузятся: слово-удар подгоняется по ширине кадра по
 * реальному шрифту, и запасной узкий гротеск дал бы другой кегль.
 */
export const FontLoader: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <KineticFonts>{children}</KineticFonts>
);
