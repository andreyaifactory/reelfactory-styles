import React from 'react';
import { GlassFonts } from '../kit/kit';

/**
 * Шрифты пака — из его же файлов: при включении стиля `kit/public/fonts/`
 * раскладывается в `public/glass/fonts/`, туда же смотрит кит. Кадры ждут, пока
 * Unbounded и Manrope не загрузятся: системным шрифтам не доверяем, на Windows
 * их нет, и текст молча уехал бы в другой гротеск с другой шириной строки.
 */
export const FontLoader: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <GlassFonts>{children}</GlassFonts>
);
