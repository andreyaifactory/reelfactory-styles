import React from 'react';
import { C, PaperTexture } from '../kit/kit';

/** Подложка кадра — лист бумаги: волокна, зерно, мягкая виньетка. */
export const Background: React.FC = () => <PaperTexture tone={C.paper} />;
