// impact-burst-kit · 竖版 9:16（1080×1920）。
// 保留：0–14 驻场、14–20 主卡 6f in(cubic) 砸落（scale 1.8→1、y −120→0）、20 落点：环 14f + 14 粒子 22f + 4f 震屏 6px + 6f 压扁回弹；
// 邻卡阻尼振荡 cos(0.5t)·e^(−t/8)（40f 内钳 0）。
// 竖版：一排三卡改为一列三卡（卡 700×300，间距 80），主卡在中、心对准安全区中心；邻卡被波及时改为上下外推 30→40px + rotate ±3°。
// 邻卡中心距 460→380，按同一环扩散曲线（80→1100，out-cubic）前沿到达仍在落点后 3f（帧 23），不变。粒子飞散 160–340 → 220–460。删除 TitleBlock。
// 以下为横版原注释：
// 落点冲击套件——shockwave-ring + particle-burst 组合变异。主卡砸落的落点帧同时触发：冲击波环扩散 + 14 粒子放射迸发 + 震屏，
// 且冲击波前沿扫到邻卡的那一帧邻卡被向外推开再 spring 弹回——"波及邻居"即两条词汇焊接成立的证据。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G, Card } from '../../_fixtures/Fixtures';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const IMPACT_BURST_KIT_VERTICAL_DURATION = 140;
const h = (n: number) => {
  const s = Math.sin(n * 127.3) * 43758.5453;
  return s - Math.floor(s);
};
const CW = 700;
const CH = 300;
const GAP = 80;
const X = (1080 - CW) / 2;
const CX = 540;
const CY = SAFE_CY;
const IMPACT = 20;
const HIT_NEIGHBOR = IMPACT + 3;
const PARTICLES = Array.from({ length: 14 }).map((_, i) => ({ angle: -Math.PI / 2 + (h(i + 1) - 0.5) * Math.PI * 1.7, dist: 220 + h(i + 40) * 240, size: 12 + h(i + 80) * 14, square: i % 2 === 0 }));
const pushEnv = (f: number) => {
  const t = f - HIT_NEIGHBOR;
  if (t < 0 || t >= 40) return 0;
  return Math.cos(t * 0.5) * Math.exp(-t / 8);
};
const cl = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;

export const ImpactBurstKitVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const dropP = interpolate(frame, [14, IMPACT], [0, 1], { ...cl, easing: Easing.in(Easing.cubic) });
  const mainScale = interpolate(dropP, [0, 1], [1.8, 1]);
  const mainDy = interpolate(dropP, [0, 1], [-120, 0]);
  const sq = interpolate(frame, [IMPACT, IMPACT + 3, IMPACT + 6], [0, 1, 0], { ...cl, easing: Easing.out(Easing.quad) });
  const ringP = interpolate(frame, [IMPACT, IMPACT + 14], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const ringR = interpolate(ringP, [0, 1], [80, 1100]);
  const ringOp = frame >= IMPACT && frame < IMPACT + 14 ? 0.75 * (1 - ringP) : 0;
  const pT = interpolate(frame, [IMPACT, IMPACT + 22], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const env = pushEnv(frame);
  let shakeX = 0;
  let shakeY = 0;
  if (frame >= IMPACT && frame < IMPACT + 4) {
    const amp = 6 * (1 - (frame - IMPACT) / 4);
    shakeX = (h(frame * 3.7) - 0.5) * 2 * amp;
    shakeY = (h(frame * 7.1 + 13) - 0.5) * 2 * amp;
  }
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, transform: `translate(${shakeX}px, ${shakeY}px)` }}>
        <div style={{ position: 'absolute', left: X, top: CY - CH / 2 - GAP - CH, transform: `translateY(${-40 * env}px) rotate(${-3 * env}deg)` }}>
          <Card w={CW} h={CH} seed={2} />
        </div>
        <div style={{ position: 'absolute', left: X, top: CY + CH / 2 + GAP, transform: `translateY(${40 * env}px) rotate(${3 * env}deg)` }}>
          <Card w={CW} h={CH} seed={4} />
        </div>
        <div style={{ position: 'absolute', left: X, top: CY - CH / 2 + mainDy, transform: `scale(${mainScale * (1 + 0.07 * sq)}, ${mainScale * (1 - 0.1 * sq)})`, transformOrigin: '50% 100%' }}>
          <Card w={CW} h={CH} seed={7} style={{ boxShadow: '0 6px 18px rgba(0,0,0,0.16)' }} />
        </div>
        {frame >= IMPACT &&
          frame < IMPACT + 22 &&
          PARTICLES.map((p, i) => {
            const s = p.size * (1 - pT);
            if (s < 0.5) return null;
            return <div key={i} style={{ position: 'absolute', left: CX + Math.cos(p.angle) * p.dist * pT - s / 2, top: CY + Math.sin(p.angle) * p.dist * pT - s / 2, width: s, height: s, background: G.ink, borderRadius: p.square ? 2 : '50%', opacity: 1 - pT * pT }} />;
          })}
        {ringOp > 0 && <div style={{ position: 'absolute', left: CX - ringR, top: CY - ringR, width: ringR * 2, height: ringR * 2, border: `4px solid ${G.ink}`, borderRadius: '50%', opacity: ringOp, boxSizing: 'border-box' }} />}
      </div>
    </div>
  );
};
