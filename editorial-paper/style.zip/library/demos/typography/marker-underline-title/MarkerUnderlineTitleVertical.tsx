// marker-underline-title · 竖版 9:16（1080×1920）。
// 与横版同一套马克笔笔形与时间轴（标题 22f 落定 → 停一拍 → 10f 描画）；
// 排版改为三行竖排，下划线所在的 "new" 单独成行放大，整体对准安全区中心。
import React, { useId } from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame } from 'remotion';
import { SafeCenter } from '../../_fixtures/Vertical';

const mulberry32 = (a: number) => () => {
  let t = (a += 0x6d2b79f5);
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

// 马克笔笔画（与横版同算法）：中轴微歪 + 变宽轮廓
const buildStroke = (len: number, seed: number) => {
  const rand = mulberry32(seed);
  const N = 40;
  const top: string[] = [];
  const bot: string[] = [];
  const wob = Array.from({ length: N + 1 }, () => rand() - 0.5);
  for (let i = 0; i <= N; i++) {
    const t = i / N;
    const x = t * len;
    const mid = 19 - t * 9 + Math.sin(t * Math.PI * 1.6 + 0.4) * 2.6 + wob[i] * 1.6;
    const wBase = 14 + Math.sin(t * Math.PI) * 6 - Math.max(0, t - 0.86) * 46;
    const w = Math.max(2.2, wBase + wob[i] * 3);
    top.push(`${x.toFixed(1)},${(mid - w / 2).toFixed(1)}`);
    bot.push(`${x.toFixed(1)},${(mid + w / 2).toFixed(1)}`);
  }
  return `M${top.join('L')}L${bot.reverse().join('L')}Z`;
};

export const MARKER_UNDERLINE_TITLE_VERTICAL_DURATION = 60;

export const MarkerUnderlineTitleVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const revealId = `reveal-${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  // 竖版 "new" 字号 200 → 笔画按比例放长、加粗（svg 整体 ×1.45）
  const LEN = 252;
  const K = 1.65;

  const enter = interpolate(frame, [0, 22], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const eo = 1 - Math.pow(1 - enter, 3);
  const titleY = (1 - eo) * 48;
  const titleOp = Math.min(1, enter * 1.6);

  const draw = interpolate(frame, [32, 42], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const drawE = 1 - Math.pow(1 - draw, 2.2);
  const path = buildStroke(LEN, 77);

  return (
    <AbsoluteFill style={{ background: '#f4f4f2' }}>
      <SafeCenter>
        <div
          style={{
            opacity: titleOp,
            transform: `translateY(${titleY}px)`,
            fontFamily: '-apple-system, "Helvetica Neue", Arial, sans-serif',
            fontWeight: 700,
            color: '#191919',
            textAlign: 'center',
            lineHeight: 1.08,
            letterSpacing: '-0.02em',
          }}
        >
          <div style={{ fontSize: 150 }}>Meet the</div>
          <div style={{ fontSize: 230, margin: '6px 0 26px' }}>
            <span style={{ fontStyle: 'italic', position: 'relative', display: 'inline-block' }}>
              new
              <svg
                width={LEN * K}
                height={44 * K}
                viewBox={`0 0 ${LEN} 44`}
                style={{ position: 'absolute', left: -18, bottom: -30, overflow: 'visible' }}
              >
                <defs>
                  <clipPath id={revealId}>
                    <rect x={0} y={-20} width={drawE * (LEN + 6)} height={60} />
                  </clipPath>
                </defs>
                {draw > 0 && <path d={path} fill="#111111" clipPath={`url(#${revealId})`} />}
              </svg>
            </span>
          </div>
          <div style={{ fontSize: 150 }}>Notion AI</div>
        </div>
      </SafeCenter>
    </AbsoluteFill>
  );
};
