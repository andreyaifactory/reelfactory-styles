import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { GRAIN, rnd } from '../kit/kit';

/**
 * Живой слой бумаги — зерно перескакивает раз в три кадра, как у плёнки,
 * снятой «на тройках». Это воздух, а не событие: правило «нет мёртвого кадра»
 * выполняет сцена — шлепки, рука, камера в руках.
 */
export const Ambient: React.FC = () => {
  const frame = useCurrentFrame();
  const step = Math.floor(frame / 3);
  return (
    <AbsoluteFill
      style={{
        backgroundImage: GRAIN,
        backgroundPosition: `${Math.round(rnd(step) * 400)}px ${Math.round(rnd(step + 7) * 400)}px`,
        opacity: 0.16,
        mixBlendMode: 'multiply',
        pointerEvents: 'none',
      }}
    />
  );
};
