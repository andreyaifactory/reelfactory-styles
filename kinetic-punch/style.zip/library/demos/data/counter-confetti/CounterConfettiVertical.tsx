// counter-confetti · 竖版 9:16（1080×1920）。
// 保留：计数 0.06–0.56 easeOutQuart、scale 过冲 [0.2,1.3,1.3,1]、纸屑抢拍 BURST 0.52、52 片同种子参数、到位冲击环 0.545–0.75、标签 0.62–0.82。
// 竖版：设计坐标 480×270 → 270×480（DesignStage 放大 4×）；数字中心从 47% 移到安全区中心（835/1920 ≈ 43.5%），字号 74→64（"1,000" 在窄画宽内）；
// 纸屑起点从 ±250 改 ±150（窄画面的两侧），水平冲速 ×0.6；辉光 340→300。
// 标签 "METRIC THIS WEEK"（宽字距大写）改为 "Metric this week"，字号 10→14，字距收拢 11→5 改 4→1。标签位于 y 56%（≈1075px）。
// 以下为横版原注释：
// Counter Confetti 数字冲刺纸屑：大数字 0 → 1000 用 easeOutQuart 冲刺，scale 走 [0.2,1.3,1.3,1] 过冲；
// 数字到位前 5 帧就从两侧 burst 出 8 色纸屑，带重力下落与自转飘散。
import React from 'react';
import { DesignStage, E, lerp, rand, seg, useT } from '../../_fixtures/Motion';

export const COUNTER_CONFETTI_VERTICAL_DURATION = 138;
const PAL = ['#ff6b8b', '#ffb347', '#ffe86b', '#7bff9e', '#5fd8ff', '#6c8cff', '#c86cff', '#ff6cf0'];
const BURST = 0.52;
const CYP = '43.5%';
const BITS = Array.from({ length: 52 }, (_, i) => {
  const isRect = rand(i * 3) > 0.4;
  const w = 5 + rand(i + 2) * 6;
  const h = isRect ? 8 + rand(i + 5) * 7 : w;
  const side = i % 2 ? 1 : -1;
  return { w, h, isRect, color: PAL[i % 8], x0: side * 150, y0: (rand(i + 30) - 0.5) * 60, vx: -side * (150 + rand(i * 5 + 1) * 300) * 0.6, vy: -(230 + rand(i * 7 + 3) * 220), g: 900 + rand(i + 60) * 520, spin: (rand(i + 90) - 0.5) * 1500, d: rand(i + 120) * 0.06 };
});

export const CounterConfettiVertical: React.FC = () => {
  const t = useT();
  const p = seg(t, 0.06, 0.56, E.outQuart);
  const val = Math.round(p * 1000);
  const sc = lerp(seg(t, 0.06, 0.3, E.outCubic), 0.2, 1.3) + seg(t, 0.56, 0.72, E.outBack) * (1 - 1.3);
  const rp = seg(t, 0.545, 0.75, E.outQuart);
  return (
    <DesignStage w={270} h={480} bg="radial-gradient(80% 60% at 50% 43%,#161a2b,#07080e 75%)">
      <div style={{ position: 'absolute', left: '50%', top: CYP, width: 300, height: 300, margin: -150, borderRadius: '50%', background: 'radial-gradient(circle,rgba(120,160,255,.28),transparent 66%)', opacity: 0.35 + seg(t, 0.5, 0.62, E.outCubic) * 0.65 - seg(t, 0.72, 1) * 0.5 }} />
      <div style={{ position: 'absolute', left: '50%', top: CYP, transform: `scale(${sc})` }}>
        <div style={{ position: 'absolute', left: 0, top: 0, transform: 'translate(-50%,-50%)', whiteSpace: 'nowrap', fontWeight: 800, fontSize: 64, lineHeight: 1, fontFamily: "-apple-system,Helvetica,'Segoe UI',sans-serif", letterSpacing: -2, background: 'linear-gradient(180deg,#ffffff,#a9bcff)', WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent', textShadow: '0 0 34px rgba(130,160,255,.28)', opacity: Math.min(1, seg(t, 0.02, 0.12) * 1.2) }}>
          {val.toLocaleString('en-US')}
        </div>
      </div>
      <div style={{ position: 'absolute', left: '50%', top: '56%', transform: 'translate(-50%,0)', fontWeight: 700, fontSize: 14, lineHeight: 1, whiteSpace: 'nowrap', fontFamily: '-apple-system,Helvetica,sans-serif', color: '#7d88a8', opacity: seg(t, 0.62, 0.78, E.outCubic), letterSpacing: lerp(seg(t, 0.62, 0.82, E.outCubic), 4, 1) }}>
        Metric this week
      </div>
      <div style={{ position: 'absolute', left: '50%', top: CYP, width: 120, height: 120, margin: -60, borderRadius: '50%', border: '2px solid rgba(160,190,255,.8)', boxSizing: 'content-box', opacity: rp > 0 ? (1 - rp) * 0.9 : 0, transform: `scale(${0.35 + rp * 2.6})` }} />
      {BITS.map((b, i) => {
        const u = seg(t, BURST + b.d, 1);
        const life = u * 1.1;
        const x = b.x0 + b.vx * life;
        const y = b.y0 + b.vy * life + 0.5 * b.g * life * life;
        return <div key={i} style={{ position: 'absolute', left: '50%', top: CYP, width: b.w, height: b.h, background: b.color, borderRadius: b.isRect ? 2 : '50%', opacity: u <= 0 ? 0 : Math.min(1, u * 8) * (1 - seg(u, 0.74, 1) * 0.95), transform: `translate(calc(-50% + ${x}px),calc(-50% + ${y}px)) rotate(${b.spin * life}deg) scale(${0.8 + (1 - u) * 0.35})` }} />;
      })}
    </DesignStage>
  );
};
