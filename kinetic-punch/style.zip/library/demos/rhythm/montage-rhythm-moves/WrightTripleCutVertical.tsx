// wright-triple-cut · 竖版 9:16（1080×1920）。
// 保留：0–24 全景 hold、三个 10f 特写（25/35/45，每个 4f 静 + 3f 动作 + 3f 静）、55 甩回全景 6f poly(5)、
// 高速段 3 层错帧副本、结果卡片 57–84 泛光 + 57–64 弹一下、之后全静止。
// 竖版：FakeDashboard → FakeDashboardV（2 列 × 3 行）；特写舞台白卡 1400×800 → 900×1000，居中到安全区中心；
// 按钮 620→700 宽、开关轨道不变（竖画宽内）、翻牌数字不变；甩回方向保持横向（竖画宽 1080，滑入距离 900→760）。
// 结果卡片 = 竖版网格右上卡（799, 443 为中心）。
// 以下为横版原注释：
// Edgar Wright《僵尸肖恩》流程三连快切：全景 hold；三个 10f 特写硬切连打：①光标按下按钮 ②开关左拨右 ③大数字翻牌 0→1；
// 帧 55 甩回全景（whip 滑入 + 错帧副本模拟运动模糊），结果卡片提亮泛光 + 大 "1" 标记结果。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const WRIGHT_TRIPLE_CUT_VERTICAL_DURATION = 130;
const C1 = 25;
const C2 = 35;
const C3 = 45;
const WHIP = 55;
const cl = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;
const CloseupStage: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div style={{ width: 1080, height: 1920, background: G.panel, position: 'relative' }}>
    <div style={{ position: 'absolute', left: 90, top: SAFE_CY - 500, width: 900, height: 1000, background: G.card, border: `4px solid ${G.border}`, borderRadius: 32, boxShadow: '0 6px 24px rgba(0,0,0,0.08)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{children}</div>
  </div>
);
const RESULT = { left: 554, top: 196, w: 490, h: 494 };

export const WrightTripleCutVertical: React.FC = () => {
  const f = useCurrentFrame();
  if (f < C1) return <FakeDashboardV variant="A" />;
  if (f < C2) {
    const p = interpolate(f - C1, [4, 7], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
    const btnY = 8 * p;
    return (
      <CloseupStage>
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: 700, height: 210, borderRadius: 44, background: p < 0.5 ? G.bar : '#5c5c5a', border: `5px solid ${G.mid}`, boxSizing: 'border-box', transform: `translateY(${btnY}px)`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ width: 300, height: 34, borderRadius: 17, background: p < 0.5 ? G.card : G.line }} />
          </div>
          <div style={{ position: 'absolute', left: '50%', top: '50%', width: 104, height: 104, marginLeft: -52, marginTop: -52 + btnY, borderRadius: 52, background: G.ink, border: '8px solid #ffffff', boxSizing: 'border-box', transform: `scale(${1 - 0.3 * p})`, boxShadow: '0 4px 14px rgba(0,0,0,0.3)' }} />
        </div>
      </CloseupStage>
    );
  }
  if (f < C3) {
    const p = interpolate(f - C2, [4, 7], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
    const trackW = 560;
    const trackH = 240;
    const knob = 192;
    const pad = 24;
    return (
      <CloseupStage>
        <div style={{ position: 'relative', width: trackW, height: trackH, borderRadius: trackH / 2, background: p < 0.5 ? G.mid : G.ink }}>
          <div style={{ position: 'absolute', top: pad, left: pad + p * (trackW - knob - pad * 2), width: knob, height: knob, borderRadius: knob / 2, background: G.card, boxShadow: '0 6px 18px rgba(0,0,0,0.35)' }} />
        </div>
      </CloseupStage>
    );
  }
  if (f < WHIP) {
    const p = interpolate(f - C3, [4, 7], [0, 1], { ...cl, easing: Easing.inOut(Easing.cubic) });
    const showOne = p >= 0.5;
    const angle = showOne ? (1 - p) * 2 * 90 : -p * 2 * 90;
    return (
      <CloseupStage>
        <div style={{ perspective: 1200 }}>
          <div style={{ width: 480, height: 620, borderRadius: 34, background: G.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `rotateX(${angle}deg)`, backfaceVisibility: 'hidden', boxShadow: '0 8px 28px rgba(0,0,0,0.25)' }}>
            <div style={{ fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 460, color: '#ffffff', lineHeight: 1 }}>{showOne ? '1' : '0'}</div>
          </div>
        </div>
      </CloseupStage>
    );
  }
  const t = f - WHIP;
  const whipX = t >= 6 ? 0 : interpolate(t, [0, 6], [760, 0], { ...cl, easing: Easing.out(Easing.poly(5)) });
  const speeding = t < 4;
  const glow = interpolate(f, [57, 84], [0, 1], cl);
  const pop = f >= 64 ? 1 : interpolate(f, [57, 60, 64], [1, 1.07, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const dash = (x: number, opacity: number, key: string) => (
    <div key={key} style={{ position: 'absolute', left: 0, top: 0, transform: `translateX(${x}px)`, opacity }}>
      <FakeDashboardV variant="A" />
    </div>
  );
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, overflow: 'hidden', position: 'relative' }}>
      {speeding && dash(whipX + 180, 0.18, 'e2')}
      {speeding && dash(whipX + 90, 0.35, 'e1')}
      {dash(whipX, 1, 'main')}
      <div style={{ position: 'absolute', left: RESULT.left, top: RESULT.top, width: RESULT.w, height: RESULT.h, transform: `translateX(${whipX}px) scale(${pop})`, borderRadius: 14, boxSizing: 'border-box', background: `rgba(255,255,255,${0.72 * glow})`, border: `5px solid rgba(47,47,47,${glow})`, boxShadow: `0 0 ${70 * glow}px rgba(255,255,255,${0.95 * glow}), 0 0 ${26 * glow}px rgba(47,47,47,${0.28 * glow})`, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: glow }}>
        <div style={{ fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 280, color: G.ink, lineHeight: 1 }}>1</div>
      </div>
    </div>
  );
};
