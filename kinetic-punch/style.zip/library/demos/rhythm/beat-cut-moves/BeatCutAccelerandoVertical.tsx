// beat-cut-accelerando · 竖版 9:16（1080×1920）。
// 保留：切点 0/49/65/77/85/91/95（间隔 16→12→8→6→4）、真硬切无过渡、切帧 +5% 亮度与 6% 白层、末段回主画面 1→1.06 慢推 20f。
// 竖版：FakeDashboard → FakeDashboardV；六个视图的对焦点改为竖版卡片/列表行的位置，对焦点推到安全区中心（540, 835）而非画面中心。
// 以下为横版原注释：
// 六个不同构图按 16→12→8→6→4 帧递减间隔全屏硬切，加速逼近，最后一切戛然定格回主画面并 1→1.06 慢推收住。
// 真硬切：frame 落在哪个区间就渲染哪个视图，无任何过渡。
import React from 'react';
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY, fakeRowH, fakeRowTop } from '../../_fixtures/Vertical';

export const BEAT_CUT_ACCELERANDO_VERTICAL_DURATION = 130;
type View = { variant: 'A' | 'B'; scale: number; cx: number; cy: number };
const VIEWS: View[] = [
  { variant: 'A', scale: 1, cx: 540, cy: 960 },
  { variant: 'A', scale: 1.7, cx: 540, cy: 690 },
  { variant: 'A', scale: 2.5, cx: 281, cy: 443 },
  { variant: 'B', scale: 1, cx: 540, cy: 960 },
  { variant: 'B', scale: 1.8, cx: 540, cy: fakeRowTop(3) + fakeRowH() / 2 },
  { variant: 'B', scale: 2.8, cx: 360, cy: fakeRowTop(1) + fakeRowH() / 2 },
];
const CUTS = [0, 49, 65, 77, 85, 91, 95];
const FINAL = 95;

const ViewShot: React.FC<{ view: View; extraScale?: number }> = ({ view, extraScale = 1 }) => (
  <div style={{ width: 1080, height: 1920, transformOrigin: `${view.cx}px ${view.cy}px`, transform: `translate(${540 - view.cx}px, ${(view.scale === 1 ? 960 : SAFE_CY) - view.cy}px) scale(${view.scale * extraScale})` }}>
    <FakeDashboardV variant={view.variant} />
  </div>
);

export const BeatCutAccelerandoVertical: React.FC = () => {
  const frame = useCurrentFrame();
  let seg = 0;
  for (let i = 0; i < CUTS.length; i++) if (frame >= CUTS[i]) seg = i;
  const isFinal = seg === CUTS.length - 1;
  const view = isFinal ? VIEWS[0] : VIEWS[seg];
  const push = isFinal ? interpolate(frame, [FINAL, FINAL + 20], [1, 1.06], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) }) : 1;
  const isCutFrame = CUTS.some((c, i) => i > 0 && frame === c);
  return (
    <AbsoluteFill style={{ background: G.bg, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, filter: `brightness(${isCutFrame ? 1.05 : 1})` }}>
        <ViewShot view={view} extraScale={push} />
      </div>
      {isCutFrame && <AbsoluteFill style={{ background: '#ffffff', opacity: 0.06 }} />}
    </AbsoluteFill>
  );
};
