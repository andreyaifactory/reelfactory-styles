// beat-step-list-theme-cycle · 竖版 9:16（1080×1920）。
// 保留：拍长 18f、首拍 30、三拍、拍头 6f 内三通道（行上移/胶囊换色/场底色）同步跳变、胶囊 1.12→0.97→1 弹落。
// 竖版：竖画面本来就是列表的长边——行高 150→190、字号 92→128、胶囊宽 900→940；胶囊与选中行对准安全区中心 y 835；
// 上下羽化 300→420，下羽化盖住 1440 以下（那里只剩底色）。
// 以下为横版原注释：
// 深色场形容词列表逐拍步进：每拍列表上移一行 + 选中胶囊跳到下一行并换色（绿→紫→红），整场底色同步换（深棕→深紫→深藏青）。
// 一拍之内"行、色、场"三通道同步跳变，~0.6s 一拍。
import React from 'react';
import { AbsoluteFill, interpolate, useCurrentFrame } from 'remotion';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const BEAT_STEP_LIST_THEME_CYCLE_VERTICAL_DURATION = 110;
const FONT = 'Helvetica, Arial, sans-serif';
const ROW_H = 190;
const WORDS = ['modern', 'playful', 'expressive', 'seamless', 'intuitive', 'bold', 'honest'];
const BEAT_LEN = 18;
const FIRST_BEAT = 30;
const N_BEATS = 3;
const THEMES = [
  { pill: '#d8d8d4', bg: '#241a12' },
  { pill: '#4fae62', bg: '#1e2416' },
  { pill: '#8e6fd8', bg: '#221a33' },
  { pill: '#d64d55', bg: '#141c2e' },
];
const snap = (t: number) => interpolate(t, [0, 1], [0, 1], { easing: (x) => 1 - Math.pow(1 - x, 3.2), extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
const mix = (a: string, b: string, t: number) => {
  const pa = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16));
  const pb = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16));
  return `rgb(${pa.map((v, i) => Math.round(v + (pb[i] - v) * t)).join(',')})`;
};

export const BeatStepListThemeCycleVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const raw = (frame - FIRST_BEAT) / BEAT_LEN;
  const beat = Math.min(N_BEATS, Math.max(0, Math.floor(raw) + 1));
  const beatStartFrame = FIRST_BEAT + (beat - 1) * BEAT_LEN;
  const tInBeat = beat === 0 ? 1 : snap((frame - beatStartFrame) / 6);
  const step = beat === 0 ? 0 : beat - 1 + tInBeat;
  // 首词在中心行之上留两行，列表看起来"有上文"
  const listY = -(step + 2) * ROW_H;
  const themePrev = THEMES[Math.max(0, beat - 1)];
  const themeNow = THEMES[beat];
  const mixT = beat === 0 ? 1 : tInBeat;
  const pillColor = mix(themePrev.pill, themeNow.pill, mixT);
  const bgColor = mix(themePrev.bg, themeNow.bg, mixT);
  const pop = beat === 0 ? 1 : interpolate(tInBeat, [0, 0.6, 1], [1.12, 0.97, 1]);
  const words = ['clear', 'simple', ...WORDS];
  return (
    <AbsoluteFill style={{ background: bgColor, fontFamily: FONT }}>
      <div style={{ position: 'absolute', left: '50%', top: SAFE_CY - ROW_H / 2 + 12, width: 940, height: ROW_H - 24, transform: `translateX(-50%) scale(${pop})`, background: pillColor, borderRadius: 999, boxShadow: '0 14px 40px rgba(0,0,0,0.35)' }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE_CY - ROW_H / 2, transform: `translateY(${listY}px)` }}>
        {words.map((w, i) => {
          const isSel = i === beat + 2;
          return (
            <div key={w} style={{ height: ROW_H, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ fontSize: 128, fontWeight: 800, letterSpacing: -2, color: isSel ? (beat === 0 ? '#2a2018' : '#ffffff') : 'rgba(255,255,255,0.34)', position: 'relative', zIndex: 2 }}>{w}</span>
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 420, background: `linear-gradient(${bgColor}, transparent)`, zIndex: 3 }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 1300, bottom: 0, background: `linear-gradient(transparent, ${bgColor} 40%)`, zIndex: 3 }} />
    </AbsoluteFill>
  );
};
