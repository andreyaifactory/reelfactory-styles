import type { StyleTokens } from '../../../core/style-contract';
import { C, MONO, SERIF } from '../kit/kit';

/**
 * «Бумажная печать» в словаре ядра фабрики. Значения — из `pack.json → tokens`:
 * чернила по бумаге, один янтарный акцент, красный — только рука редактора.
 * Засечки 700 без капса; моно — для служебных строк и имён в распечатке экрана.
 */
export const tokens: StyleTokens = {
  name: 'Бумажная печать',

  color: {
    text: C.ink,
    textMuted: C.muted,
    textFaint: C.pencil,
    bg: C.paper,
    bgTop: C.paperHi,
    accent: C.amber,
    accentSoft: 'rgba(149,89,5,0.16)',
    surface: '#fbf9f4',
    surfaceBorder: 'rgba(19,17,15,0.16)',
    inkSoft: C.inkSoft,
    red: C.red,
    highlighter: C.hl,
    desk: C.desk,
  },

  type: {
    hero: { size: 112, weight: 700, lh: 1.08, ls: '-0.015em', family: SERIF },
    heroTight: { size: 96, weight: 700, lh: 1.08, ls: '-0.015em', family: SERIF },
    title: { size: 64, weight: 700, lh: 1.12, ls: '-0.01em', family: SERIF },
    stat: { size: 168, weight: 700, lh: 1.0, ls: '-0.02em', family: SERIF },
    label: { size: 30, weight: 400, lh: 1.25, ls: '0.02em', family: MONO },
    body: { size: 46, weight: 400, lh: 1.42, ls: '0', family: SERIF },
    quote: { size: 96, weight: 700, lh: 1.1, ls: '-0.01em', family: SERIF },
  },

  /** Бумага не скругляется: вырезка режется ножницами, а не штампуется. */
  radius: { card: 2, pill: 4, bar: 2 },

  space: { gap: 18 },

  extra: {
    /** Свечения в этом мире нет. */
    glow: 'none',
    /** «Ночной выпуск» — один контраст-разворот или весь ролик, не вперемешку. */
    night: { bg: '#16130f', sheet: '#221e19', text: '#efe7d8', muted: '#9a9183', accent: '#d89a3c', red: '#d0573f' },
  },
};
