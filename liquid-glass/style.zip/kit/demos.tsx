import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { Aurora, BeatWords, Bubble, C, DISPLAY, IRIS, irisText, Capsule, GlassTitle, Condense, Defocus, Drop, DropReveal, FloatCam, Frost, Glass, GlassStack, GlassWipe, Layer, Lens, LensDive, LiquidBlob, LiquidStat, Melt, Merge, Ripple, Split, Stage, Streak, TEXT, beatF } from './kit';

// «Жидкое стекло»: изолированные демо своих компонентов. Каждое — один приём, 1080×1920, своя шкала.
// «Видео» в демо — абстрактный живой кадр Footage, на его месте может быть любой ролик.

/** Заглушка видео: абстрактный живой кадр без текста (тёплый свет, глянцевые шары, бегущие полосы света). На его месте — любой ролик. */
export const Footage: React.FC<{ f: number; w: number; h: number; speed?: number; from?: number }> = ({ f, w, h, speed = 1, from = 0 }) => {
  const t = (f + from) * speed;
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: 'linear-gradient(165deg, #ffcfa8 0%, #ff8fb4 45%, #7b5cff 100%)' }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{ position: 'absolute', left: -w, width: w * 3, height: 90 + i * 40, top: ((t * (1.4 + i * 0.5) + i * 420) % (h + 600)) - 300, transform: 'rotate(-18deg)', background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.35), transparent)', filter: 'blur(18px)' }} />
      ))}
      {[0, 1, 2, 3, 4].map((i) => {
        const r = 70 + ((i * 53) % 90);
        const x = (w * (0.15 + 0.18 * i) + 60 * Math.sin(t * 0.03 + i * 1.7)) % w;
        const y = h * (0.2 + 0.15 * ((i * 3) % 5)) + 80 * Math.cos(t * 0.025 + i);
        return <div key={`s${i}`} style={{ position: 'absolute', left: x - r, top: y - r, width: r * 2, height: r * 2, borderRadius: '50%', background: 'radial-gradient(circle at 32% 28%, #fff, rgba(255,255,255,0.4) 25%, rgba(255,120,190,0.5) 60%, rgba(90,60,220,0.6))', boxShadow: '0 20px 50px rgba(60,20,120,0.35)' }} />;
      })}
    </div>
  );
};

const LightScene: React.FC<{ f: number; text?: string; at?: number; hue?: number }> = ({ f, text = 'Стекло\nпроявляется', at = 0, hue = 0 }) => (
  <AbsoluteFill>
    <Aurora f={f} hue={hue} />
    <div style={{ position: 'absolute', top: 640, left: 90, right: 90 }}>
      <Condense f={f} at={at + 4} text={text} size={104} />
    </div>
  </AbsoluteFill>
);
const ScreenScene: React.FC<{ f: number; at?: number }> = ({ f, at = 0 }) => (
  <AbsoluteFill>
    <Aurora f={f} hue={60} />
    <Capsule f={f} at={at} x={120} y={330} w={840} h={1000}>
      <Footage f={f} w={840} h={1000} />
    </Capsule>
  </AbsoluteFill>
);

// 1. Жидкий свет (+ перелив гаммы)
const DAurora: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} flip={60} energy={1.3} />
      <div style={{ position: 'absolute', top: 700, left: 90, right: 90 }}>
        <Condense f={f} at={10} text="Свет *течёт*" size={118} align="center" />
      </div>
    </Stage>
  );
};

// 2. Стеклянная плашка: конденсация, блик, испарение
const DGlass: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} />
      <Glass f={f} at={6} out={92} x={90} y={560} w={900} h={520} sheenAt={34} pad="64px 64px">
        <Condense f={f} at={16} out={88} text="Плашка из *стекла*" size={78} />
        <div style={{ marginTop: 36 }}>
          <Condense f={f} at={26} out={88} text="за ней видно свет, кромка переливается" size={42} font="text" weight={600} color={C.muted} lh={1.3} />
        </div>
      </Glass>
    </Stage>
  );
};

// 3. Конденсация текста + акцент переливом + испарение
const DCondense: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} />
      <div style={{ position: 'absolute', top: 560, left: 90, right: 90 }}>
        <Condense f={f} at={6} out={80} text={'Слова\nпроступают\nиз *тумана*'} size={108} />
      </div>
    </Stage>
  );
};

// 4. Капли-пилюли
const DDrops: React.FC = () => {
  const f = useCurrentFrame();
  const items = ['Быстро', 'Без студии', 'Стиль за минуту', 'Свой свет'];
  return (
    <Stage>
      <Aurora f={f} />
      {items.map((s, i) => (
        <Drop key={s} f={f} at={6 + i * 12} x={i % 2 ? 640 : 440} y={480 + i * 170} w={60 + s.length * 30} label={s} accent={i === 2} />
      ))}
    </Stage>
  );
};

// 5. Слияние капель
const DMerge: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} />
      {[['Свет', 250, 470], ['Стекло', 830, 600], ['Капля', 300, 1180]].map(([s, x, y], i) => (
        <div key={i} style={{ position: 'absolute', left: (x as number) - 150, top: (y as number) - 130, width: 300, textAlign: 'center', fontFamily: TEXT, fontWeight: 700, fontSize: 44, opacity: 1 - Math.min(1, Math.max(0, (f - 26) / 8)) }}>
          {s}
        </div>
      ))}
      <Merge f={f} at={30} cx={540} cy={835} from={[[250, 470, 60], [830, 600, 54], [300, 1180, 66]]} label="Всё в одном" />
    </Stage>
  );
};

// 6. Линза
const LensContent: React.FC<{ f: number }> = ({ f }) => (
  <AbsoluteFill>
    <Aurora f={f} />
    <div style={{ position: 'absolute', top: 520, left: 90, right: 90 }}>
      <Condense f={f} at={-30} text={'Деталь\nпод *линзой*'} size={110} />
      <div style={{ marginTop: 40 }}>
        <Condense f={f} at={-30} text="мелкий текст становится крупным, как через каплю воды" size={40} font="text" weight={600} color={C.muted} lh={1.35} />
      </div>
    </div>
  </AbsoluteFill>
);
const DLens: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <LensContent f={f} />
      <Lens f={f} at={10} dur={50} path={[[260, 860], [760, 860]]} r={170} zoom={1.8} content={<LensContent f={f} />} />
    </Stage>
  );
};

// 7. Видео в стеклянной капсуле
const DCapsule: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} />
      <Capsule f={f} at={6} x={150} y={300} w={780} h={820} sheenAt={34}>
        <Footage f={f} w={780} h={820} />
      </Capsule>
      <div style={{ position: 'absolute', top: 1210, left: 90, right: 150 }}>
        <Condense f={f} at={24} text="Видео — *в капле*" size={74} align="center" />
      </div>
    </Stage>
  );
};

// 8. Сплит: видео сверху, графика снизу, граница — мениск
const DSplit: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Split
        f={f}
        at={14}
        split={820}
        top={<Footage f={f} w={1080} h={1920} from={200} />}
        bottom={
          <AbsoluteFill>
            <Aurora f={f} />
            <LiquidStat f={f} at={30} x={90} y={870} value={87} pct={0.87} suffix="%" label="досматривают до конца" />
          </AbsoluteFill>
        }
      />
    </Stage>
  );
};

// 9. Видео в капле поверх графики → капля разливается на весь кадр
const DBubble: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} />
      <div style={{ position: 'absolute', top: 640, left: 90, right: 90 }}>
        <Condense f={f} at={8} text={'Графика —\nглавная,\nвидео *рядом*'} size={92} />
      </div>
      <Bubble f={f} at={14} cx={820} cy={430} d={300} focus={[540, 700]} zoom={0.5} expandAt={84}>
        <Footage f={f} w={1080} h={1920} />
      </Bubble>
    </Stage>
  );
};

// 10. Запотевание: ключевая фраза на стекле поверх кадра, потом стекло протирают
const DFrost: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Footage f={f} w={1080} h={1920} />
      <Frost f={f} at={16} clearAt={92}>
        <div style={{ position: 'absolute', top: 650, left: 90, right: 90 }}>
          <Condense f={f} at={24} text={'Главное —\n*на стекле*'} size={110} align="center" />
        </div>
      </Frost>
    </Stage>
  );
};

// 11. Камера-парение со слоями глубины
const DFloat: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <FloatCam f={f} dur={120} push={[1, 1.06]} accents={[20, 50, 80]} amp={1.6}>
        <Layer z={0.6}>
          <Aurora f={f} />
        </Layer>
        <Layer z={1}>
          <Glass f={f} at={4} x={130} y={420} w={600} h={380} />
        </Layer>
        <Layer z={1.5}>
          <Glass f={f} at={12} x={380} y={700} w={560} h={300} pad="0 50px" style={{ display: 'flex', alignItems: 'center' }}>
            <Condense f={f} at={18} text="Слои *парят*" size={66} />
          </Glass>
        </Layer>
        <Layer z={2}>
          <Drop f={f} at={24} x={330} y={1100} w={360} h={96} label="ближе всех" />
        </Layer>
      </FloatCam>
    </Stage>
  );
};

// 12. Жидкая капля-морф, вздрагивает на долях
const DBlob: React.FC = () => {
  const f = useCurrentFrame();
  const beats = [0, 1, 2, 3, 4, 5, 6].map((n) => beatF(n, 122, 20));
  return (
    <Stage>
      <Aurora f={f} beats={beats} dim={0.7} />
      <LiquidBlob f={f} at={6} beats={beats} r={320}>
        <Condense f={f} at={26} text="перелив" size={96} align="center" />
      </LiquidBlob>
    </Stage>
  );
};

// 13. Слова в бит на стеклянной плите
const DBeatWords: React.FC = () => {
  const f = useCurrentFrame();
  const beats = [0, 1, 2, 3, 4, 5].map((n) => beatF(n, 122, 8));
  return (
    <Stage>
      <FloatCam f={f} dur={110} accents={beats}>
        <Aurora f={f} beats={beats} />
        <BeatWords f={f} beats={beats} words={['свет', '*стекло*', 'капля', 'блик', '*туман*', 'глубина']} />
      </FloatCam>
    </Stage>
  );
};

// 14. Стопка стекла в 3D, раскрывается веером
const DStack: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} hue={30} />
      <GlassStack
        f={f}
        at={4}
        fanAt={48}
        cards={[
          <AbsoluteFill key="a" style={{ padding: 60, justifyContent: 'center' }}>
            <div style={{ fontFamily: DISPLAY, fontWeight: 700, fontSize: 200, letterSpacing: '-0.05em', lineHeight: 1, ...irisText(f) }}>98%</div>
            <div style={{ fontFamily: DISPLAY, fontWeight: 600, fontSize: 52, color: C.text, marginTop: 20 }}>чистоты</div>
          </AbsoluteFill>,
          <AbsoluteFill key="b" style={{ padding: 60, display: 'flex', flexDirection: 'row', alignItems: 'flex-end', gap: 24 }}>
            {[0.4, 0.6, 0.5, 0.85, 0.7, 1].map((v, i) => (
              <div key={i} style={{ flex: 1, height: `${v * 70}%`, borderRadius: 24, background: IRIS, backgroundSize: '600% 100%', backgroundPosition: `${i * 20}% 0`, opacity: 0.85 }} />
            ))}
          </AbsoluteFill>,
          <AbsoluteFill key="c" style={{ background: `radial-gradient(circle at 30% 30%, ${C.pink}, transparent 55%), radial-gradient(circle at 75% 70%, ${C.cyan}, transparent 55%)`, opacity: 0.55 }} />,
        ]}
      />
    </Stage>
  );
};

// 15. Световой штрих
const DStreak: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} dim={0.6} />
      <Streak f={f} at={20} y={835} />
      <div style={{ position: 'absolute', top: 760, left: 90, right: 90 }}>
        <Condense f={f} at={28} text="*вспышка*" size={130} align="center" />
      </div>
    </Stage>
  );
};

// 16–20. Переходы
const DWipe: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <GlassWipe f={f} at={34} a={<ScreenScene f={f} />} b={<LightScene f={f} at={40} text={'Шторка\nиз *стекла*'} />} />
    </Stage>
  );
};
const DDropReveal: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <DropReveal f={f} at={30} a={<LightScene f={f} text="Капля…" />} b={<ScreenScene f={f} at={30} />} />
    </Stage>
  );
};
const DRipple: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Ripple f={f} at={32} a={<LightScene f={f} text={'По стеклу\nидёт волна'} />} b={<LightScene f={f + 200} at={-180} hue={90} text={'Сцена\n*сменилась*'} />} />
    </Stage>
  );
};
const DLensDive: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <LensDive f={f} at={30} x={540} y={620} a={<LightScene f={f} text={'\n\nНырок\nв *линзу*'} />} b={<ScreenScene f={f} at={-30} />} />
    </Stage>
  );
};
const DDefocus: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Defocus f={f} at={34} a={<ScreenScene f={f} />} b={<LightScene f={f} at={42} text={'Из света —\n*новое*'} />} />
    </Stage>
  );
};

// 21. Стеклянный заголовок
const DGlassTitle: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} />
      <div style={{ position: 'absolute', top: 620, left: 40, right: 40 }}>
        <GlassTitle f={f} at={8} sheenAt={40} text={'ЖИДКОЕ\nСТЕКЛО'} size={142} />
      </div>
    </Stage>
  );
};

// 22. Цифра в стекле
const DStat: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} />
      <LiquidStat f={f} at={6} x={90} y={560} value={3} pct={0.6} prefix="×" label="больше досмотров" />
    </Stage>
  );
};

// 23. Финал: капли стекаются в призыв
const DMelt: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage>
      <Aurora f={f} />
      <Melt f={f} at={8} label="Подпишись" sub="каждый день — новый стиль" />
    </Stage>
  );
};

// 24. Светлая тема «Жемчуг»
const DPearl: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Stage theme="pearl">
      <Aurora f={f} />
      <Glass f={f} at={6} x={90} y={540} w={900} h={460} sheenAt={36} pad="60px 60px">
        <Condense f={f} at={14} text="Днём — *жемчуг*" size={80} />
        <div style={{ marginTop: 34 }}>
          <Condense f={f} at={24} text="светлое стекло для бьюти, ухода и спокойных тем" size={42} font="text" weight={600} color={C.inkMuted} lh={1.3} />
        </div>
      </Glass>
      <Drop f={f} at={40} x={380} y={1080} w={460} label="Та же физика" />
    </Stage>
  );
};

export const PACK_DEMOS: { id: string; dur: number; C: React.FC }[] = [
  { id: 'own-aurora', dur: 120, C: DAurora },
  { id: 'own-glass-panel', dur: 110, C: DGlass },
  { id: 'own-condense', dur: 100, C: DCondense },
  { id: 'own-drops', dur: 100, C: DDrops },
  { id: 'own-merge', dur: 100, C: DMerge },
  { id: 'own-lens', dur: 90, C: DLens },
  { id: 'own-capsule', dur: 100, C: DCapsule },
  { id: 'own-split', dur: 110, C: DSplit },
  { id: 'own-bubble', dur: 120, C: DBubble },
  { id: 'own-frost', dur: 130, C: DFrost },
  { id: 'own-float-cam', dur: 120, C: DFloat },
  { id: 'own-liquid-blob', dur: 120, C: DBlob },
  { id: 'own-beat-words', dur: 110, C: DBeatWords },
  { id: 'own-glass-stack', dur: 120, C: DStack },
  { id: 'own-streak', dur: 80, C: DStreak },
  { id: 'own-glass-wipe', dur: 90, C: DWipe },
  { id: 'own-drop-reveal', dur: 90, C: DDropReveal },
  { id: 'own-ripple', dur: 90, C: DRipple },
  { id: 'own-lens-dive', dur: 90, C: DLensDive },
  { id: 'own-defocus', dur: 90, C: DDefocus },
  { id: 'own-glass-title', dur: 90, C: DGlassTitle },
  { id: 'own-liquid-stat', dur: 90, C: DStat },
  { id: 'own-melt', dur: 110, C: DMelt },
  { id: 'own-pearl', dur: 100, C: DPearl },
];
