// trailer-bumper · 竖版 9:16（1080×1920）。
// 保留：三连 9f 速剪（0/9/18）、镜头内 1→1.04 线性推近、27–32 纯黑 6f、33 起标题淡入+微升 16f 定格、49f 后全静止。
// 竖版：FakeDashboard → FakeDashboardV；第三镜 2.2x 特写对准竖版右上卡（799, 443）并推到安全区中心；
// 标题 "THE LAUNCH" 一行 168px（约 1100 宽）放不下 → 两行 "THE" / "LAUNCH"，字号 200，对准安全区中心；微升 44→56px。
// 以下为横版原注释：
// 前置速剪预告：结构即全部——三连 9f 速剪（A 整页 / B 整页 / A 2.2x 怼脸特写）→ 6f 纯黑喘息 → 正式开场大标题淡入+微升 16f 定格。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const TRAILER_BUMPER_VERTICAL_DURATION = 140;
const CUT_2 = 9;
const CUT_3 = 18;
const BLACK = 27;
const TITLE = 33;
const TITLE_IN = 16;
const push = (frame: number, start: number) => interpolate(frame, [start, start + 9], [1, 1.04], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });

export const TrailerBumperVertical: React.FC = () => {
  const frame = useCurrentFrame();
  if (frame < BLACK) {
    let inner: React.ReactNode;
    if (frame < CUT_2) inner = <div style={{ width: 1080, height: 1920, transform: `scale(${push(frame, 0)})`, transformOrigin: `50% ${SAFE_CY}px` }}><FakeDashboardV variant="A" /></div>;
    else if (frame < CUT_3) inner = <div style={{ width: 1080, height: 1920, transform: `scale(${push(frame, CUT_2)})`, transformOrigin: `50% ${SAFE_CY}px` }}><FakeDashboardV variant="B" /></div>;
    else
      inner = (
        <div style={{ width: 1080, height: 1920, transform: `translate(${540 - 799}px, ${SAFE_CY - 443}px) scale(${2.2 * push(frame, CUT_3)})`, transformOrigin: '799px 443px' }}>
          <FakeDashboardV variant="A" />
        </div>
      );
    return <div style={{ width: 1080, height: 1920, overflow: 'hidden', background: G.bg }}>{inner}</div>;
  }
  if (frame < TITLE) return <div style={{ width: 1080, height: 1920, background: '#000000' }} />;
  const opacity = interpolate(frame, [TITLE, TITLE + TITLE_IN], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const rise = interpolate(frame, [TITLE, TITLE + TITLE_IN], [56, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic) });
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, overflow: 'hidden', position: 'relative' }}>
      <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE_CY, opacity, transform: `translateY(calc(-50% + ${rise}px))`, fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 200, lineHeight: 1, color: G.ink, letterSpacing: -3, textAlign: 'center' }}>
        THE
        <br />
        LAUNCH
      </div>
    </div>
  );
};
