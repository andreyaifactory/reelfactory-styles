import type { StylePack, StyleSound } from '../../../core/style-contract';
import { T } from '../kit/kit';
import { tokens } from './tokens';
import { Background } from './Background';
import { Ambient } from './Ambient';
import { FontLoader } from './fonts';
import { Caption } from './Caption';
import { ScreenFrame } from './ScreenFrame';
import bank from './sfx.json';

/**
 * ПЕРЕХОДНИК стиля «Слои» для фабрики роликов.
 *
 * Сам пак — идиома, кит, шрифты, звук — лежит уровнем выше. Здесь он отдаёт
 * ядру токены, тёмную подложку, мягкий живой свет, шрифты, тонкие субтитры
 * без плашки, оправу скрина и банк звуков (`sfx.json` собирается при
 * включении). Своих склеек нет: стиль меняет план склейкой `cut` и зумом
 * камеры внутри сцены.
 */
const pack: StylePack = {
  tokens,
  Background,
  Ambient,
  FontLoader,
  Caption,
  captionStep: { size: 46, weight: 500, lh: 1.2, ls: '0.01em', family: T.body },
  ScreenFrame,
  sfx: bank as { sounds: StyleSound[] },
};

export default pack;
export { tokens };
