// freeze-annotate · 竖版 9:16（1080×1920）：时间重映射（0–45 流动 → 45–100 定格 → 100–135 解冻 1.4x）、圈注 8f、箭头 6f 同横版。
// 竖版：卡片放大到 620 宽（步距 690），导轨速度按步距同比 22→29px/源帧；定格时目标卡正好停在画面中线，
// 卡心对准安全区中心；圈注椭圆 380×330、箭头从右上落下，均在安全区与按钮栏之外。
// 以下为横版原注释：
// freeze-annotate 定格标注（轮 G）——真实卡片流运动中定格，
// 马克笔琥珀圈注（feTurbulence 手绘抖动）圈住目标卡 + 箭头点题，解冻继续。
// remap：0–45 流动 → 45–100 定格（斜率0）→ 100–135 解冻（1.4x 补偿）。
import { useId } from 'react';
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from 'remotion';
import layout from '../../_textures/live-layout.json';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const FREEZEANNOTATE_VERTICAL_DUR = 135;

const CARD_W = 620;
const GAP = 70;
const CARD_H = CARD_W * (288 / 357); // 卡片纹理宽高比
const RAIL = layout.projects.cards.slice(0, 9);
const TARGET_I = 5;
const AMBER = '#b45309';

export const FreezeAnnotateRealVertical: React.FC = () => {
  const frame = useCurrentFrame();
  // 滤镜 ID 按实例生成，多实例同场不串引（useId 的 «:» 在 url() 里非法，需清洗）
  const roughId = `rough-${useId().replace(/[^a-zA-Z0-9]/g, '')}`;
  const src = interpolate(frame, [0, 45, 100, 135], [0, 45, 45, 94], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
  const dx = src * 29;
  const draw = interpolate(frame, [52, 60], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const arrowDraw = interpolate(frame, [60, 66], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const fade = interpolate(frame, [96, 104], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  // 导轨起点：定格时（dx=45·29=1305）目标卡 k=5 中心落在 x=540
  const X0 = 540 - CARD_W / 2 - TARGET_I * (CARD_W + GAP) + 45 * 29;
  const targetX = X0 + TARGET_I * (CARD_W + GAP) - dx + CARD_W / 2;
  const C = 2230;
  const CY = SAFE_CY; // 椭圆周长近似
  return (
    <AbsoluteFill style={{ backgroundColor: '#f9f6f1', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: SAFE_CY - CARD_H / 2, transform: `translateX(${-dx + X0}px)` }}>
        {Array.from({ length: 14 }).map((_, k) => {
          const c = RAIL[k % RAIL.length];
          const isTarget = k === TARGET_I;
          return (
            <Img
              key={k}
              src={staticFile(`textures/live/${isTarget ? 'card4-hires.png' : c.file}`)}
              style={{
                position: 'absolute', left: k * (CARD_W + GAP), top: 0,
                width: CARD_W, borderRadius: 12,
                boxShadow: '0 4px 16px rgba(31,28,23,0.10)',
              }}
            />
          );
        })}
      </div>
      <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity: fade }}>
        <defs>
          <filter id={roughId}>
            <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="2" seed="7" result="n" />
            <feDisplacementMap in="SourceGraphic" in2="n" scale="7" />
          </filter>
        </defs>
        <ellipse
          cx={targetX} cy={CY} rx={380} ry={330}
          fill="none" stroke={AMBER} strokeWidth={8} strokeLinecap="round"
          strokeDasharray={C} strokeDashoffset={C * (1 - draw)}
          transform={`rotate(-6 ${targetX} ${CY})`}
          filter={`url(#${roughId})`}
        />
        <path
          d={`M ${targetX + 360} ${CY - 560} Q ${targetX + 260} ${CY - 480} ${targetX + 170} ${CY - 380}`}
          fill="none" stroke={AMBER} strokeWidth={8} strokeLinecap="round"
          strokeDasharray={420} strokeDashoffset={420 * (1 - arrowDraw)}
          filter={`url(#${roughId})`}
        />
      </svg>
    </AbsoluteFill>
  );
};
