# Библиотека приёмов пака «Бумажная печать»

Всё нужное для повторения приёмов лежит здесь, интернет и репозиторий не нужны.

- `cards/<имя>.md` — описание приёма: идея, параметры, известные подводные камни. **Читать перед реализацией.** Карточка иногда описывает несколько вариантов приёма; в пак вошли только те, у которых есть файл в колонке «Сцена».
- `demos/<категория>/<имя>/<Сцена>Vertical.tsx` — эталонный код Remotion, кадр 1080×1920. Параметры в коде — проверенная настройка: адаптировать под материал можно, ухудшать параметры из разделов описания «Главное» и «Известные ловушки» нельзя.
- `demos/_fixtures`, `demos/_textures` — общие файлы, на которые ссылается код. Размеры кадра и вертикальная заглушка-приложение — `demos/_fixtures/Vertical.tsx`, правила раскладки — в его начале.
- `public/textures/live/` — картинки, которые код берёт через `staticFile()`. **Скопировать содержимое `library/public/` в `public/` своего Remotion-проекта.**

**npm-зависимости всех приёмов:** `@remotion/motion-blur`, `react`, `remotion`

Описания приёмов — на русском. Комментарии в коде могут быть на китайском (оригинал библиотеки video-shotcraft); назначение каждого приёма в этом паке — в `../pack.json`.

Раскладка рассчитана на безопасную зону Reels: текст в y 230…1440, справа внизу пусто. Если проект задаёт свою безопасную зону, действует она.

| Приём | Сцена (9:16) | Длина | Доп. зависимости | Суть |
|---|---|---|---|---|
| [paper-title-card](cards/paper-title-card.md) | `demos/typography/paper-title-card/PaperTitleCardVertical.tsx` | 55f | — | Одна фраза оттискивается на бумаге по словам, одно слово — курсивом акцентного цвета, завершает короткая линейка |
| [marker-underline-title](cards/marker-underline-title.md) | `demos/typography/marker-underline-title/MarkerUnderlineTitleVertical.tsx` | 60f | — | Когда крупный заголовок лёг, под ключевым словом слева направо быстро прорисовывается маркерное подчёркивание — переменная ширина, неровный край |
| [typewriter-moves](cards/typewriter-moves.md) | `demos/typography/typewriter-moves/TypewriterErrorRetypeVertical.tsx` (error-retype) | 160f | — | «Передумал»: напечатал, стёр и переписал по-другому |
| [split-flap-title](cards/split-flap-title.md) | `demos/typography/split-flap-title/SplitFlapFlipVertical.tsx` | 140f | — | Заголовок как перекидное табло аэропорта — у каждого символа механическая ячейка из двух половин, перелистывает пару знаков и с щелчком встаёт |
| [type-assembly-moves](cards/type-assembly-moves.md) | `demos/typography/type-assembly-moves/TrackingExpandRevealVertical.tsx` (tracking-expand) | 130f | — | Слово раскрывается из сжатой разрядки в нормальную |
| [brand-ink-open](cards/brand-ink-open.md) | `demos/typography/brand-ink-open/BrandInkOpenVertical.tsx` | 104f | — | Тушью рисуется перекрестие → знак оттискивается по буквам → подзаголовок печатается машинкой → секунда покоя → всё поднимается и уходит |
| [letterspace-materialize](cards/letterspace-materialize.md) | `demos/opening/letterspace-materialize/LetterspaceMaterializeVertical.tsx` | 110f | — | Знак с широкой разрядкой «кристаллизуется» — все буквы начинают писаться в один кадр, штрихи растут непрерывно, как рукой |
| [stroke-segment-build](cards/stroke-segment-build.md) | `demos/opening/stroke-segment-build/StrokeSegmentBuildVertical.tsx` | 150f | — | Слово из обрывков штрихов — заголовок разбит на десяток с лишним штрихов, они загораются вразнобой и складываются в слово |
| [crane-rise-reveal](cards/crane-rise-reveal.md) | `demos/opening/crane-rise-reveal/CraneRiseRevealVertical.tsx` | 150f | — | Подъём крана — начало вплотную к одной строке, камера поднимается и отъезжает, строки накатывают одна за другой до целой страницы |
| [text-as-mask](cards/text-as-mask.md) | `demos/opening/text-as-mask/TextAsMaskVertical.tsx` | 150f | — | Текст как маска для видео — сквозь жирные буквы видна плывущая картинка, в конце буквы вырастают и открывают её целиком |
| [type-and-filter](cards/type-and-filter.md) | `demos/interaction/type-and-filter/TypeAndFilterVertical.tsx` | 73f | — | Набор в поиске на настоящем интерфейсе, сетка сама сходится к одной карточке, клик проваливает в детальную страницу |
| [row-embed](cards/row-embed.md) | `demos/ui-entrance/row-embed/RowEmbedVertical.tsx` | 68f | — | Строки, как карточки, опускаются сверху, выравниваются из наклона и встраиваются в страницу |
| [list-stack-press](cards/list-stack-press.md) | `demos/ui-entrance/list-stack-press/ListStackPressVertical.tsx` | 88f | — | Карточки списка по одной взлетают снизу и складываются в стопку; каждая новая продавливает стопку, счётчик щёлкает |
| [paper-craft-moves](cards/paper-craft-moves.md) | `demos/ui-entrance/paper-craft-moves/MaskingTapeSlapVertical.tsx` (masking-tape-slap)<br>`demos/ui-entrance/paper-craft-moves/PopupBookRiseVertical.tsx` (popup-book-rise) | 140f<br>160f | — | Карточку с хлопком прижимает скотч; карточки встают со страницы, как в книжке-раскладушке |
| [draw-svg-trace](cards/draw-svg-trace.md) | `demos/ui-entrance/draw-svg-trace/DrawSvgTraceVertical.tsx` | 140f | — | Обводка-пометка — тушевая линия с кончиком пера обегает контур элемента и «рисует» его |
| [wall-reveal-moves](cards/wall-reveal-moves.md) | `demos/ui-entrance/wall-reveal-moves/WireframeDrawOnVertical.tsx` (wireframe-draw-on) | 150f | — | Интерфейс собирается из чертёжных линий, потом заполняется |
| [skeleton-reveal](cards/skeleton-reveal.md) | `demos/ui-entrance/skeleton-reveal/SkeletonRevealVertical.tsx` | 160f | — | Три ступени «набросок → скелет → содержимое»: рисованная заглушка сменяется серым каркасом, потом готовым окном |
| [deck-deal-flyin](cards/deck-deal-flyin.md) | `demos/ui-entrance/deck-deal-flyin/DeckDealFlyinVertical.tsx` | 113f | — | Стопка карточек крупно, камера отъезжает к странице, и стопка, как при раздаче, разлетается в сетку |
| [element-body-moves](cards/element-body-moves.md) | `demos/ui-entrance/element-body-moves/ContactShadowLiftVertical.tsx` (contact-shadow-lift) | 160f | — | Элемент приподнимается над листом: тень расходится и смягчается |
| [tension-camera-moves](cards/tension-camera-moves.md) | `demos/camera/tension-camera-moves/SlowPushInVertical.tsx` (slow-push-in)<br>`demos/camera/tension-camera-moves/PullBackIsolationVertical.tsx` (pull-back-isolation) | 150f<br>150f | — | Медленный наезд на главное; отъезд, оставляющий героя одного |
| [overhead-camera-moves](cards/overhead-camera-moves.md) | `demos/camera/overhead-camera-moves/OverheadTabletopDropVertical.tsx` (overhead-tabletop-drop)<br>`demos/camera/overhead-camera-moves/TiltRevealVertical.tsx` (tilt-reveal) | 145f<br>145f | — | Камера скользит над столом с карточками; лежащая страница поднимается к зрителю |
| [depth-layer-moves](cards/depth-layer-moves.md) | `demos/camera/depth-layer-moves/MultiplaneRealVertical.tsx` (multiplane) | 135f | — | Многослойный параллакс: три слоя с разной скоростью дают объём |
| [print-texture-transitions](cards/print-texture-transitions.md) | `demos/transition/print-texture-transitions/InkBleedRevealVertical.tsx` (ink-bleed-reveal) | 130f | — | Чернила растекаются бахромчатым краем и съедают старую сцену |
| [shot-transitions](cards/shot-transitions.md) | `demos/transition/shot-transitions/FlashCutVertical.tsx` (flash-cut)<br>`demos/transition/shot-transitions/BlackCardTransitionVertical.tsx` (black-card) | 60f<br>120f | @remotion/motion-blur | Наезд со вспышкой в следующий кадр; титр на чёрном между кадрами |
| [line-carry-transition](cards/line-carry-transition.md) | `demos/transition/line-carry-transition/LineCarryTransitionVertical.tsx` | 160f | — | Линия из сцены A вытягивается за край, камера едет за ней, и линия на ходу становится частью сцены B |
| [trailer-grammar-moves](cards/trailer-grammar-moves.md) | `demos/rhythm/trailer-grammar-moves/CardFootageCadenceVertical.tsx` (card-footage-cadence) | 150f | — | Титры вперемешку с кадрами, ритм ускоряется |
| [page-turn-transitions](cards/page-turn-transitions.md) | `demos/transition/page-turn-transitions/BarnDoorSplitVertical.tsx` (barn-door-split) | 130f | — | Старая страница раскрывается створками, за ней новая |
| [paper-plane-messenger](cards/paper-plane-messenger.md) | `demos/transition/paper-plane-messenger/PaperPlaneMessengerVertical.tsx` | 150f | — | После «Отправить» камера отъезжает, бумажный самолётик летит по дуге в следующий кадр |
| [transition-travel](cards/transition-travel.md) | `demos/transition/transition-travel/SharedElementMorphVertical.tsx` (shared-element-morph) | 130f | — | Общий элемент перелетает из кадра в кадр и становится частью следующего |
| [transition-hidden-cut](cards/transition-hidden-cut.md) | `demos/transition/transition-hidden-cut/InvisibleCutVertical.tsx` (invisible-cut) | 100f | @remotion/motion-blur | Склейка спрятана за предметом переднего плана |
| [mosaic-reframe](cards/mosaic-reframe.md) | `demos/transition/mosaic-reframe/MosaicReframeVertical.tsx` | 180f | — | 12 плиток непрерывно перестраиваются между тремя раскладками — сетка, мозаика с главной плиткой, каскад |
| [hatch-depth](cards/hatch-depth.md) | `demos/data/hatch-depth/HatchDepthVertical.tsx` | 132f | — | Заштрихованные полосы по очереди вытягиваются, штриховка сменяется сплошным акцентом |
| [speed-ramp-freeze](cards/speed-ramp-freeze.md) | `demos/rhythm/speed-ramp-freeze/FreezeAnnotateRealVertical.tsx` (freeze-annotate) | 135f | @remotion/motion-blur | Стоп-кадр с пометкой от руки, потом движение продолжается |
| [odometer-digit-roll](cards/odometer-digit-roll.md) | `demos/data/odometer-digit-roll/OdometerDigitRollVertical.tsx` | 150f | — | Цифра-плакат как одометр — каждый разряд крутится отдельно и встаёт |
| [before-after-slider-scrub](cards/before-after-slider-scrub.md) | `demos/data/before-after-slider-scrub/BeforeAfterSliderScrubVertical.tsx` | 150f | — | Шторка «до/после» — разделитель отлетает и медленно возвращается |
| [scroll-brake-moves](cards/scroll-brake-moves.md) | `demos/data/scroll-brake-moves/ChangelogScrollBrakeVertical.tsx` (changelog-scroll-brake) | 140f | — | Лента несётся и тормозит точно на нужной строке |
| [riso-print-hits](cards/riso-print-hits.md) | `demos/effects/riso-print-hits/RisoMisregistrationHitVertical.tsx` (misregistration-hit)<br>`demos/effects/riso-print-hits/RisoBeatPumpVertical.tsx` (beat-pump) | 120f<br>140f | — | Удар «несовмещения печати»: элемент врезается, раскалывается на две краски и встаёт; пульсация под бит |
| [line-boil](cards/line-boil.md) | `demos/effects/line-boil/LineBoilVertical.tsx` | 140f | — | «Кипящая» линия — в паузе контуры каждые 3 кадра чуть перерисовываются, как от руки |
| [panel-grid-moves](cards/panel-grid-moves.md) | `demos/rhythm/panel-grid-moves/ComicPanelSplitVertical.tsx` (comic-panel-split) | 150f | — | Кадр делится на панели комикса |
| [sakuga-timing-shift](cards/sakuga-timing-shift.md) | `demos/rhythm/sakuga-timing-shift/SakugaTimingShiftVertical.tsx` | 150f | — | «На трёх» → «на единицах»: рывки раз в 3 кадра, в кульминацию — плавно |
| [outro-group-photo-launch](cards/outro-group-photo-launch.md) | `demos/outro/outro-group-photo-launch/OutroGroupPhotoLaunchVertical.tsx` | 145f | — | Элементы всего ролика слетаются и окружают знак, как на групповом фото |
| [edit-hook-moves](cards/edit-hook-moves.md) | `demos/outro/edit-hook-moves/LogoStingButtonVertical.tsx` (logo-sting-button) | 142f | — | Знак в конце встал, и вдруг врезается пасхалка на 12f — «кнопка» в конце трейлера |
