import type { StylePack, StyleSound } from '../../../core/style-contract';
import { TEXT } from '../kit/kit';
import { tokens } from './tokens';
import { Background } from './Background';
import { Ambient } from './Ambient';
import { FontLoader } from './fonts';
import { transitions, autoTransitions } from './transitions';
import { Caption } from './Caption';
import { ScreenFrame } from './ScreenFrame';
import bank from './sfx.json';

/**
 * ПЕРЕХОДНИК «Удара» для фабрики роликов.
 *
 * Сам пак — идиома, компоненты, библиотека, звуки — лежит уровнем выше и не
 * знает о фабрике. Здесь он отдаёт ядру то, что ядро умеет брать от стиля:
 * токены, чёрное поле, полутон живым слоем, шрифты, склейки-удары, субтитры
 * капсом с обводкой, врезку с плитой для скрина и банк звуков (`sfx.json`
 * собирается при включении стиля).
 */
const pack: StylePack = {
  tokens,
  Background,
  Ambient,
  FontLoader,
  transitions,
  autoTransitions,
  Caption,
  captionStep: { size: 80, weight: 900, lh: 1.08, ls: '0em', family: TEXT, uppercase: true },
  ScreenFrame,
  sfx: bank as { sounds: StyleSound[] },
};

export default pack;
export { tokens };
