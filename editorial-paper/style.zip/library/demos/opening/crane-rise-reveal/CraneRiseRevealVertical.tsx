// crane-rise-reveal · 竖版 9:16（1080×1920）。
// 运镜参数同横版（HOLD 20f 特写 → 20–120f Easing.out(quad) 减速升起 → 120–150f 真静止；行越线脉冲 4f 起 18f 落）。
// 竖版：世界换成竖版假 App 列表（FakeDashboardV B，7 行）；起点特写对准最底行图标+标题条，
// 竖幅视野窄，特写倍率 3.2 → 2.6；终点满幅（对准页面中心 540,960）。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, FAKE_V, fakeRowH, fakeRowTop, VW, VH } from '../../_fixtures/Vertical';

export const CRANE_RISE_REVEAL_VERTICAL_DURATION = 150;

const HOLD = 20;
const MOVE_END = 120;
const ease = Easing.out(Easing.quad);

const ROW_LEFT = FAKE_V.pad;
const ROW_W = VW - FAKE_V.pad * 2;
const ROW_H = fakeRowH();
const N = FAKE_V.rows;

const F0 = { x: 300, y: fakeRowTop(N - 1) + ROW_H / 2 };
const F1 = { x: VW / 2, y: VH / 2 };
const S0 = 2.6;

const camAt = (frame: number) => {
  const p = Math.min(1, Math.max(0, (frame - HOLD) / (MOVE_END - HOLD)));
  const e = ease(p);
  const s = S0 + (1 - S0) * e;
  const fx = F0.x + (F1.x - F0.x) * e;
  const fy = F0.y + (F1.y - F0.y) * e;
  return { s, tx: VW / 2 - fx * s, ty: VH / 2 - fy * s, visTop: fy - VH / 2 / s };
};

const triggers = Array.from({ length: N }, (_, i) => {
  for (let f = HOLD; f <= MOVE_END; f++) if (camAt(f).visTop <= fakeRowTop(i) + 1) return f;
  return MOVE_END;
});

export const CraneRiseRevealVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const { s, tx, ty } = camAt(frame);
  return (
    <div style={{ width: VW, height: VH, background: G.bg, overflow: 'hidden', position: 'relative' }}>
      <div style={{ position: 'absolute', width: VW, height: VH, transformOrigin: '0 0', transform: `translate(${tx}px, ${ty}px) scale(${s})` }}>
        <FakeDashboardV variant="B" />
        {triggers.map((t, i) => {
          const op = interpolate(frame, [t, t + 4, t + 22], [0, 0.22, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
          if (op <= 0.001) return null;
          return (
            <div key={i} style={{ position: 'absolute', left: ROW_LEFT, top: fakeRowTop(i), width: ROW_W, height: ROW_H, borderRadius: 18, background: G.ink, opacity: op }} />
          );
        })}
      </div>
    </div>
  );
};
