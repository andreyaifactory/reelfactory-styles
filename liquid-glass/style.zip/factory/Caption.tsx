import React from 'react';
import type { StyleCaptionProps } from '../../../core/style-contract';
import { CaptionCapsule } from '../kit/GlassCaptions';

/**
 * Субтитры фабрики в стекле: каждая страница — своя стеклянная капсула.
 * Место и размер полосы даёт ядро, капсула только рисуется в них.
 */
export const Caption: React.FC<StyleCaptionProps> = ({ page, frame, box }) => (
  <CaptionCapsule words={page.words} from={page.from} frame={frame} size={box.fontSize} maxWidth={box.width} />
);
