import React from 'react';
import { AbsoluteFill } from 'remotion';
import type { TransitionSpec } from '../../../core/transitions';
import type { StyleSeamProps } from '../../../core/style-contract';
import { C, E, PaperTexture, Tear, TornWindow, lerp, ragged } from '../kit/kit';

/**
 * Бумажные склейки «Бумажной печати» для ядра фабрики.
 *
 * Блоки ролика не накладываются друг на друга: уход живёт в последних кадрах
 * старого блока, приход — в первых кадрах нового. Поэтому каждая склейка — одно
 * движение бумаги, разрезанное по стыку: к последнему кадру ухода старый кадр
 * закрыт целиком, с первого кадра прихода бумага уходит и открывает новый.
 */

const W = 1080;
const H = 1920;
/** Лист с рваными краями сверху и снизу — выше кадра, чтобы закрывать его целиком. */
const SHEET = 2060;
/** Верх листа над кадром: рваный край (±24px) уходит выше нуля с запасом. */
const SHEET_TOP = -70;

const sheetClip = (seed: number) => {
  const n = 28;
  const top = ragged(seed, n, 24).map((d, i) => `${(i / n) * 100}% ${30 + d}px`);
  const bottom = ragged(seed + 50, n, 24).map((d, i) => `${(1 - i / n) * 100}% calc(100% - ${30 + d}px)`);
  return `polygon(${[...top, ...bottom].join(',')})`;
};

const Sheet: React.FC<{ y: number; tilt: number; seed?: number }> = ({ y, tilt, seed = 31 }) => (
  <AbsoluteFill
    style={{
      transform: `translateY(${y}px) rotate(${tilt}deg)`,
      filter: 'drop-shadow(0 0 2px #fffdf6) drop-shadow(0 -16px 28px rgba(40,28,14,0.32))',
      pointerEvents: 'none',
    }}
  >
    <div style={{ position: 'absolute', left: -30, top: SHEET_TOP, width: W + 60, height: SHEET, clipPath: sheetClip(seed) }}>
      <div style={{ position: 'absolute', left: 30, top: 0, width: W, height: SHEET }}>
        <PaperTexture tone={C.paper} />
      </div>
    </div>
  </AbsoluteFill>
);

/** Лист с рваным краем проезжает снизу вверх: накрывает старый кадр и, уходя, открывает новый. */
const PaperWipe: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  if (phase === 'out') {
    const p = E.inOutCubic(t);
    return (
      <>
        {children}
        <Sheet y={lerp(p, H + 60, 0)} tilt={(1 - p) * -3} />
      </>
    );
  }
  const p = E.outCubic(t);
  return (
    <>
      {children}
      <Sheet y={lerp(p, 0, -SHEET - 80)} tilt={p * 2} />
    </>
  );
};

/** Страница перелистывается вокруг левого края: старая уходит, её оборот ложится на новую. */
const PageFlip: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  const p = E.inOutCubic(t);
  const angle = phase === 'out' ? -90 * p : -90 - 90 * p;
  const page = (face: React.ReactNode, shade: number) => (
    <AbsoluteFill style={{ perspective: 2200, perspectiveOrigin: '0% 50%', pointerEvents: 'none' }}>
      <AbsoluteFill style={{ transformOrigin: '0% 50%', transform: `rotateY(${angle}deg)` }}>
        {face}
        <AbsoluteFill style={{ background: `linear-gradient(90deg, rgba(0,0,0,0) 35%, rgba(40,28,14,${shade}))` }} />
      </AbsoluteFill>
    </AbsoluteFill>
  );
  if (phase === 'out') return page(children, p * 0.45);
  // Приход: под листом уже новый кадр, сверху докручивается оборот старой страницы.
  return (
    <>
      {children}
      {page(<PaperTexture tone="#ece5d8" />, (1 - p) * 0.4)}
      <AbsoluteFill style={{ background: 'rgba(30,20,10,1)', opacity: (1 - p) * 0.12, pointerEvents: 'none' }} />
    </>
  );
};

/** Лист шлёпают поверх кадра, и в нём рвётся дыра, которая раскрывается до нового кадра. */
const TornOpen: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  if (phase === 'out') {
    const p = E.press(t);
    return (
      <>
        {children}
        <AbsoluteFill
          style={{
            opacity: Math.min(1, t * 2.2),
            transform: `scale(${lerp(p, 1.08, 1)}) rotate(${lerp(p, 2, 0)}deg)`,
            filter: `drop-shadow(0 ${lerp(p, 40, 8)}px 40px rgba(40,28,14,0.35))`,
          }}
        >
          <PaperTexture tone={C.paper} />
        </AbsoluteFill>
      </>
    );
  }
  return (
    <>
      {children}
      <TornWindow f={t * 14} at={0} len={14} from={0.04} to={1.3} cy={900} tone={C.paper} />
    </>
  );
};

/** Лист рвётся пополам и разлетается; под ним — следующий. Сильный ход, к финалу. */
const PaperTear: React.FC<StyleSeamProps> = ({ phase, t, children }) => {
  if (phase === 'out') {
    return (
      <Tear f={t * 16} at={0} len={16}>
        {children}
      </Tear>
    );
  }
  const p = E.outCubic(t);
  return <AbsoluteFill style={{ transform: `scale(${lerp(p, 1.02, 1)})` }}>{children}</AbsoluteFill>;
};

export const transitions: Record<string, TransitionSpec> = {
  'paper-wipe': {
    what: 'лист с рваным краем проезжает снизу вверх: накрывает старый кадр, открывает новый',
    character: 'move',
    enter: 12,
    exit: 12,
    render: PaperWipe,
  },
  'page-flip': {
    what: 'страница перелистывается вокруг левого края',
    character: 'move',
    enter: 10,
    exit: 10,
    render: PageFlip,
    sound: 'open',
  },
  'torn-window': {
    what: 'лист шлёпают поверх, в нём рвётся дыра и открывает новый кадр',
    character: 'open',
    enter: 14,
    exit: 6,
    render: TornOpen,
    sound: 'close',
  },
  'paper-tear': {
    what: 'лист рвётся пополам и разлетается, под ним следующий',
    character: 'close',
    enter: 6,
    exit: 16,
    render: PaperTear,
  },
};

/**
 * Очередь «сам подбери»: бумажные склейки и прямые сдвиги листа. Растворений
 * нет — в этом мире ничего не тает. Разрыв пополам ставится руками, к финалу.
 */
export const autoTransitions = ['paper-wipe', 'page-flip', 'push-left', 'torn-window', 'push-up'];
