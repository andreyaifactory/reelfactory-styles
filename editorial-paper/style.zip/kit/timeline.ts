// Кривые и сегменты времени (30fps). Единый источник для всего кита «Бумажная печать».
export const FPS = 30;
export const sf = (sec: number) => Math.round(sec * FPS);

export const E = {
  outCubic: (t: number) => 1 - Math.pow(1 - t, 3),
  inCubic: (t: number) => t * t * t,
  inOutCubic: (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  outQuint: (t: number) => 1 - Math.pow(1 - t, 5),
  // «оттиск»: быстрый прижим и долгое оседание — bezier(0.2, 0.75, 0.3, 1) из Ink Press
  press: (t: number) => bez(0.2, 0.75, 0.3, 1)(t),
  // линейки и подчёркивания: bezier(0.3, 0, 0.2, 1)
  rule: (t: number) => bez(0.3, 0, 0.2, 1)(t),
};

export const lerp = (t: number, a: number, b: number) => a + (b - a) * t;
export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
export const seg = (f: number, f0: number, f1: number, ease: (x: number) => number = (x) => x) =>
  ease(clamp01((f - f0) / (f1 - f0)));

// cubic-bezier(x1,y1,x2,y2) → y(x), решение Ньютоном (детерминированно)
export function bez(x1: number, y1: number, x2: number, y2: number) {
  const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx;
  const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
  const X = (t: number) => ((ax * t + bx) * t + cx) * t;
  const Y = (t: number) => ((ay * t + by) * t + cy) * t;
  const dX = (t: number) => (3 * ax * t + 2 * bx) * t + cx;
  return (x: number) => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const d = dX(t);
      if (Math.abs(d) < 1e-6) break;
      t -= (X(t) - x) / d;
    }
    return Y(clamp01(t));
  };
}
