import React from 'react';
import { AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame } from 'remotion';
import {
  Arrow,
  Bars,
  Brackets,
  Burst,
  C,
  Cut,
  Echo,
  Flash,
  Footage,
  Graphic,
  NumberSlam,
  Plus,
  PunchCam,
  PunchThrough,
  Shutter,
  Slam,
  Slice,
  Smash,
  SpeedLines,
  Stage,
  Starburst,
  Stretch,
  Tag,
  Tape,
  TEXT,
  Zigzag,
} from './kit';
import { GZY, grid } from './timeline';

// Шоурил «Удара»: ~17 с моушн-графики на долях g-eazy-nba-type (86.6 BPM).
// Ролик начинается за 3 доли до дропа: хук — три слова на трёх долях, дроп — «УДАР».
// Сцены по 3–4 доли, переходы не повторяются подряд: разрез → вспышка → плита → жалюзи → насквозь → инверсия → плита → разрез.

const PRE = 3; // долей до дропа
const START_SEC = GZY.dropSec - (PRE * GZY.T) / 30; // начало ролика в треке
const B = grid(PRE * GZY.T, GZY.T); // B(0) — дроп
export const REEL_DURATION = B(22);

const hitsOf = (...ks: number[]) => ks.map(B);

// ── Сцены ───────────────────────────────────────────────────────────────────
const Hook: React.FC<{ f: number }> = ({ f }) => {
  if (f < B(-2))
    return (
      <AbsoluteFill style={{ background: C.black }}>
        <SpeedLines f={f} at={0} color={C.lime} inner={460} />
        <Slam f={f} at={0} text="ХВАТИТ" color={C.white} />
        <Plus f={f} at={4} x={160} y={420} color={C.lime} />
        <Plus f={f} at={8} x={910} y={1260} color={C.red} size={48} />
      </AbsoluteFill>
    );
  if (f < B(-1))
    return (
      <AbsoluteFill style={{ background: '#5c5c5e' }}>
        <Stretch f={f} at={B(-2)} text="СКУЧНЫХ" mode="sag" color={C.gray} />
      </AbsoluteFill>
    );
  return (
    <AbsoluteFill style={{ background: f >= B(-0.5) + 3 ? C.red : C.white }}>
      <Slice f={f} at={B(-1)} cut={B(-0.5)} text="РОЛИКОВ" color={C.black} blade={C.red} from="left" />
    </AbsoluteFill>
  );
};

const Drop: React.FC<{ f: number }> = ({ f }) => {
  const look = f < B(1) ? { bg: C.red, fg: C.black, star: C.lime, it: false } : f < B(2) ? { bg: C.black, fg: C.white, star: C.red, it: false } : { bg: C.lime, fg: C.black, star: C.blue, it: true };
  const at = f < B(1) ? B(0) : f < B(2) ? B(1) : B(2);
  return (
    <AbsoluteFill style={{ background: look.bg }}>
      <Starburst f={f} at={B(0)} r={600} color={look.star} hits={hitsOf(0.5, 1, 2, 2.5)} />
      <SpeedLines f={f} at={B(0)} color={C.white} inner={560} len={420} />
      {at === B(0) ? <Echo f={f} at={B(0)} text="УДАР" color={look.fg} echo={C.white} maxSize={600} /> : <Slam f={f} at={at} text="УДАР" color={look.fg} italic={look.it} from="cut" maxSize={600} />}
      <Plus f={f} at={B(1)} x={170} y={400} color={look.fg} />
      <Plus f={f} at={B(2)} x={900} y={1270} color={look.fg} size={44} />
    </AbsoluteFill>
  );
};

const Montage: React.FC<{ f: number; at: number }> = ({ f, at }) => {
  const items = [
    <Footage key="a" name="orbA" duo="lime" fit="cover" zoom={1.15} />,
    <Graphic key="b" f={f} kind="rays" a={C.blue} b={C.lime} />,
    <Footage key="c" name="tilt" duo="red" fit="cover" />,
    <Graphic key="d" f={f} kind="halftone" a={C.black} b={C.red} />,
    <Footage key="e" name="trio" duo="blue" fit="cover" zoom={1.3} />,
    <Graphic key="f" f={f} kind="checker" a={C.black} b={C.white} />,
    <Footage key="g" name="orbC" duo="acid" fit="cover" />,
    <Graphic key="h" f={f} kind="circle" a={C.lime} b={C.blue} />,
    <Footage key="i" name="orbA" duo="hot" fit="cover" zoom={1.8} x={60} />,
    <Graphic key="j" f={f} kind="stripes" a={C.black} b={C.lime} />,
    <Footage key="k" name="tilt" duo="lime" fit="cover" zoom={1.4} y={-120} />,
    <Graphic key="l" f={f} kind="rays" a={C.red} b={C.black} />,
    <Footage key="m" name="trio" duo="ink" fit="cover" zoom={2.2} x={-200} />,
    <Graphic key="n" f={f} kind="halftone" a={C.blue} b={C.white} />,
    <Footage key="o" name="orbC" duo="red" fit="cover" zoom={1.3} />,
    <Graphic key="p" f={f} kind="circle" a={C.black} b={C.red} />,
  ];
  const words: [number, string, boolean][] = [
    [3, 'КАДР', false],
    [4, 'ЦВЕТ', true],
    [5, 'СЛОВО', false],
    [6, 'РИТМ', true],
  ];
  return (
    <PunchCam f={f} hits={hitsOf(3, 4, 5, 5.5, 6)} amp={0.05}>
      <Burst f={f} at={at} every={5} items={items} />
      {words.map(([k, w, it], i) => (
        <Slam key={w} f={f} at={i === 0 ? Math.max(at, B(k)) : B(k)} out={i < 3 ? B(words[i + 1][0]) : undefined} text={w} italic={it} color={C.white} blend="difference" from={i === 0 ? 'zoom' : 'cut'} maxSize={560} />
      ))}
    </PunchCam>
  );
};

const BarsScene: React.FC<{ f: number; at: number }> = ({ f, at }) => {
  // в каждой полосе объект уведён к краю, слово стоит на чистом поле своей полосы
  const rows: { name: 'orbA' | 'tilt'; duo: 'lime' | 'blue' | 'red'; word: string; cx: number; x: number; color: string }[] = [
    { name: 'orbA', duo: 'lime', word: 'ВСЁ', cx: 300, x: 300, color: C.lime },
    { name: 'tilt', duo: 'blue', word: 'СТРОГО', cx: 700, x: -330, color: C.lime },
    { name: 'orbA', duo: 'red', word: 'В БИТ', cx: 330, x: 330, color: C.black },
  ];
  const st = Math.round(GZY.T / 2);
  return (
    <AbsoluteFill style={{ background: C.black }}>
      <Graphic f={f} kind="halftone" a={C.black} b="#262628" />
      <Bars
        f={f}
        at={at}
        stagger={st}
        shift={B(9)}
        top={230}
        height={1210}
        items={rows.map((r, i) => (
          <AbsoluteFill key={i} style={{ background: r.duo === 'lime' ? C.black : r.duo === 'blue' ? C.blue : C.red, borderTop: i ? undefined : `10px solid ${C.lime}` }}>
            <AbsoluteFill style={{ left: r.x, right: -r.x }}>
              <Footage name={r.name} duo={r.duo} zoom={1.0} />
            </AbsoluteFill>
            <Slam f={f} at={at + i * st + 2} text={r.word} cx={r.cx} cy={202} size={r.word.length > 4 ? 250 : 300} color={r.color} from="cut" />
          </AbsoluteFill>
        ))}
      />
      <Plus f={f} at={B(9)} x={960} y={300} color={C.white} size={50} />
    </AbsoluteFill>
  );
};

const TapeScene: React.FC<{ f: number; at: number }> = ({ f, at }) => (
  <AbsoluteFill style={{ background: C.blue }}>
    <PunchCam f={f} hits={hitsOf(11, 12, 12.5, 13)} amp={0.035}>
      <Cut f={f} at={at} x={100} y={540} w={880} h={660} rot={-3} plate={C.lime} from="zoom" hits={hitsOf(11, 12, 13)}>
        <Footage name="orbA" duo="ink" fit="cover" zoom={1.05} />
      </Cut>
      <Tape f={f} at={B(10.5)} text="НЕ ЛИСТАЙ" y={470} angle={-8} bg={C.lime} fg={C.black} h={140} />
      <Tape f={f} at={B(11)} text="СМОТРИ ДО КОНЦА" y={1290} angle={6} bg={C.white} fg={C.black} h={130} dir={-1} speed={11} />
      <Tag f={f} at={B(12)} text="залипательно" x={120} y={1090} rot={-6} bg={C.red} fg={C.black} size={84} />
      <Arrow f={f} at={B(12.5)} x={880} y={1060} angle={-140} len={260} color={C.white} hits={hitsOf(13)} />
    </PunchCam>
  </AbsoluteFill>
);

const NumberScene: React.FC<{ f: number; at: number }> = ({ f, at }) => {
  const inv = f >= B(16);
  return (
    <AbsoluteFill style={{ background: inv ? C.lime : C.black }}>
      <PunchCam f={f} hits={hitsOf(14, 15, 16)} amp={0.04}>
        {inv && <Starburst f={f} at={B(16)} r={460} y={720} color={C.blue} />}
        <NumberSlam f={f} at={at} lock={B(14)} value="×3" cy={720} color={inv ? C.black : C.white} maxSize={700} />
        <Slam f={f} at={B(15)} text="досматривают" cy={1110} size={118} family={TEXT} color={inv ? C.black : C.lime} from="left" />
        <Slam f={f} at={B(15.5)} text="до конца" cy={1240} size={118} family={TEXT} color={inv ? C.blue : C.white} from="right" />
        <Zigzag f={f} at={B(15.5) + 4} x={330} y={1320} w={420} color={inv ? C.black : C.red} />
      </PunchCam>
    </AbsoluteFill>
  );
};

const LoudScene: React.FC<{ f: number }> = ({ f }) => {
  if (f < B(18))
    return (
      <AbsoluteFill style={{ background: C.lime }}>
        <Stretch f={f} at={B(17)} text="ГРОМЧЕ" color={C.black} maxSize={560} />
      </AbsoluteFill>
    );
  if (f < B(19))
    return (
      <AbsoluteFill style={{ background: C.blue }}>
        <Echo f={f} at={B(18)} text="ЯРЧЕ" color={C.white} echo={C.lime} maxSize={600} />
      </AbsoluteFill>
    );
  return (
    <AbsoluteFill style={{ background: C.red }}>
      <SpeedLines f={f} at={B(19)} color={C.black} inner={520} />
      <Slice f={f} at={B(19)} cut={B(19.5)} text="БЫСТРЕЕ" color={C.black} blade={C.white} from="right" angle={10} />
    </AbsoluteFill>
  );
};

const Final: React.FC<{ f: number }> = ({ f }) => (
  <AbsoluteFill style={{ background: C.white }}>
    <PunchCam f={f} hits={hitsOf(20, 21, 21.5)} amp={0.05}>
      <Starburst f={f} at={B(20)} r={560} y={760} color={C.red} hits={hitsOf(21, 21.5)} />
      <Echo f={f} at={B(20)} text="УДАР" cy={760} color={C.black} echo={C.blue} maxSize={620} />
      <Tag f={f} at={B(21)} text="стиль для ваших рилсов" x={540} y={1180} rot={-3} bg={C.blue} fg={C.white} size={70} from="up" anchor="center" />
      <Brackets f={f} at={B(21.5)} x={110} y={330} w={860} h={1000} color={C.black} thick={12} len={80} />
    </PunchCam>
  </AbsoluteFill>
);

// ── Звук ────────────────────────────────────────────────────────────────────
const SFX: [number, string, number][] = [
  [0, 'hit-weak', 0.5],
  [B(-2), 'vinyl-scratch-small', 0.28],
  [B(-1), 'hit-blow', 0.45],
  [B(-0.5), 'sweep-short', 0.4],
  [B(0), 'bass-hit-short', 0.55],
  [B(0), 'camera-shutter-hard', 0.35],
  [B(1), 'switch-click-quick', 0.35],
  [B(2), 'switch-click-quick', 0.35],
  [B(2.5), 'air-whoosh-powerful', 0.4],
  [B(3), 'click-camera', 0.3],
  [B(4), 'click-camera', 0.3],
  [B(5), 'click-camera', 0.3],
  [B(6), 'click-camera', 0.3],
  [B(6.5), 'sweep-short', 0.4],
  [B(6.75), 'transition-snap', 0.4],
  [B(7.25), 'transition-snap', 0.4],
  [B(7.75), 'transition-snap', 0.4],
  [B(9), 'switch-click-quick', 0.35],
  [B(10), 'impact-zoom-quick', 0.4],
  [B(10.5), 'whoosh-fast', 0.25],
  [B(12), 'pop-electric', 0.4],
  [B(13.5), 'camera-shutter-hard', 0.35],
  [B(14), 'hit-blow', 0.45],
  [B(15), 'transition-snap', 0.35],
  [B(16), 'switch-click-quick', 0.35],
  [B(16.75), 'air-whoosh-powerful', 0.4],
  [B(17), 'zoom-swipe-fast', 0.3],
  [B(18), 'hit-blow', 0.4],
  [B(19), 'whoosh-fast', 0.3],
  [B(19.5), 'sweep-short', 0.4],
  [B(20), 'stomp-apocalyptic', 0.45],
  [B(21), 'pop-electric', 0.35],
];

export const KineticReel: React.FC<{ bgm?: boolean }> = ({ bgm = true }) => {
  const f = useCurrentFrame();
  const S2 = B(2.5) + 4; // середина плиты
  const S3 = B(6.5) + 5; // середина жалюзи
  const S4 = B(10); // удар насквозь
  const S5 = B(13.5); // инверсия + склейка
  const S6 = B(16.75) + 4; // середина плиты
  const S7 = B(19.5) + 8; // разрез «БЫСТРЕЕ»

  let scene: React.ReactNode;
  if (f < B(0)) scene = <Hook f={f} />;
  else if (f < S2) scene = <Drop f={f} />;
  else if (f < S3) scene = <Montage f={f} at={S2} />;
  else if (f < S4) scene = <BarsScene f={f} at={S3} />;
  else if (f < S4 + 12) scene = <PunchThrough f={f} at={S4} a={<BarsScene f={f} at={S3} />} b={<TapeScene f={f} at={S4 + 5} />} />;
  else if (f < S5) scene = <TapeScene f={f} at={S4 + 5} />;
  else if (f < S6) scene = <NumberScene f={f} at={S5} />;
  else if (f < S7) scene = <LoudScene f={f} />;
  else scene = <Final f={f} />;

  return (
    <Stage>
      {scene}
      {/* переходы */}
      <Flash f={f} at={B(0)} len={2} />
      <Smash f={f} at={B(2.5)} color={C.lime} angle={-18} />
      <Shutter f={f} at={B(6.5)} color={C.black} />
      <Flash f={f} at={B(9)} len={2} mode="invert" />
      <Flash f={f} at={S5} len={2} mode="invert" />
      <Smash f={f} at={B(16.75)} color={C.red} angle={14} dir={-1} />
      <Flash f={f} at={B(20)} len={1} />
      {bgm && (
        <>
          <Audio
            src={staticFile('kinetic/g-eazy-nba-type.mp3')}
            startFrom={Math.round(START_SEC * 30)}
            volume={(fr) => interpolate(fr, [0, 3, REEL_DURATION - 8, REEL_DURATION], [0, 0.9, 0.9, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })}
          />
          {SFX.map(([at, id, v], i) => (
            <Sequence key={i} from={at} durationInFrames={45}>
              <Audio src={staticFile(`kinetic/${id}.mp3`)} volume={v} />
            </Sequence>
          ))}
        </>
      )}
    </Stage>
  );
};
