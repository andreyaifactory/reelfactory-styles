import React, { useEffect, useState } from 'react';
import { AbsoluteFill, Freeze, Loop, OffthreadVideo, continueRender, delayRender, staticFile } from 'remotion';
// Кит пака «Удар». Мир — плоские цветовые поля, огромный шрифт и кадр, которым бьют.
// Ничего не плывёт: вещи врезаются за 2–4 кадра, отдача, стоп до следующей доли.
// Всё детерминированно (без Math.random/Date.now). Кадр 1080×1920.
import { E, clamp01, kick, kicks, lerp, rnd, seg, stepF } from './timeline';

export { E, kick, kicks, lerp, rnd, seg, stepF, clamp01 };

// ── Шрифты (OFL, лежат в public/kinetic/fonts) ───────────────────────────────
// Загрузка — компонентом, а не при импорте модуля: delayRender на уровне модуля
// в многопоточном рендере не снимается и роняет его по таймауту. Stage оборачивает
// себя сам; композицию без Stage обернуть в KineticFonts.
const CYR = 'U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116';
const LAT = 'U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD';
const g = (typeof window !== 'undefined' ? window : {}) as unknown as { __kinFonts?: Promise<void> };
const loadFonts = (): Promise<void> => {
  if (typeof window === 'undefined' || typeof FontFace === 'undefined') return Promise.resolve();
  if (g.__kinFonts) return g.__kinFonts;
  const fs = (file: string) => `url(${staticFile(`kinetic/fonts/${file}.woff2`)}) format('woff2')`;
  const faces: FontFace[] = [];
  for (const [sub, range] of [['cyrillic', CYR], ['latin', LAT]] as const) {
    faces.push(new FontFace('Udar Display', fs(`fira-sans-extra-condensed-${sub}-900-normal`), { weight: '900', style: 'normal', unicodeRange: range }));
    faces.push(new FontFace('Udar Display', fs(`fira-sans-extra-condensed-${sub}-900-italic`), { weight: '900', style: 'italic', unicodeRange: range }));
    faces.push(new FontFace('Udar Display', fs(`fira-sans-extra-condensed-${sub}-800-normal`), { weight: '800', style: 'normal', unicodeRange: range }));
    faces.push(new FontFace('Udar Text', fs(`rubik-${sub}-800-normal`), { weight: '800', unicodeRange: range }));
    faces.push(new FontFace('Udar Text', fs(`rubik-${sub}-900-normal`), { weight: '900', unicodeRange: range }));
  }
  g.__kinFonts = Promise.all(faces.map((x) => x.load()))
    .then((loaded) => {
      loaded.forEach((x) => document.fonts.add(x));
    })
    .catch((e) => {
      console.error(e);
    });
  return g.__kinFonts;
};

/** Кадры ждут, пока шрифты «Удара» не загрузятся. */
export const KineticFonts: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [handle] = useState(() => delayRender('Шрифты «Удара»'));
  useEffect(() => {
    loadFonts().then(() => continueRender(handle));
  }, [handle]);
  return <>{children}</>;
};

/** Перерисовать после загрузки шрифтов: подгонка слов по ширине меряет реальный шрифт. */
export const useFonts = () => {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let alive = true;
    loadFonts().then(() => alive && setReady(true));
    return () => {
      alive = false;
    };
  }, []);
  return ready;
};

export const DISPLAY = '"Udar Display", "Arial Narrow", sans-serif';
export const TEXT = '"Udar Text", system-ui, sans-serif';

// ── Токены ──────────────────────────────────────────────────────────────────
export const C = {
  black: '#0c0c0d',
  white: '#f7f5f0',
  lime: '#c6ff1a',
  blue: '#2b2bff',
  red: '#ff2e1f',
  gray: '#8d8d8d',
  ink: '#0c0c0d',
};
export type FieldName = 'black' | 'lime' | 'blue' | 'red' | 'white';
/** Пары «поле → текст → акцент». В сцене одно поле, текст и не больше одного акцента. */
export const FIELDS: Record<FieldName, { bg: string; fg: string; acc: string }> = {
  black: { bg: C.black, fg: C.white, acc: C.lime },
  lime: { bg: C.lime, fg: C.black, acc: C.blue },
  blue: { bg: C.blue, fg: C.white, acc: C.lime },
  red: { bg: C.red, fg: C.black, acc: C.white },
  white: { bg: C.white, fg: C.black, acc: C.red },
};

// Безопасная зона Reels 1080×1920
export const SAFE = { top: 230, bottom: 1440, left: 60, right: 1020, buttonsX: 940, buttonsY: 1000, cy: 835, w: 960 } as const;

// ── Измерение слова (подгонка по ширине кадра) ────────────────────────────────
let ctx: CanvasRenderingContext2D | null = null;
const cache = new Map<string, number>();
export const measure = (text: string, family = DISPLAY, weight = 900, italic = false, ready = true) => {
  const key = `${family}|${weight}|${italic}|${text}`;
  if (cache.has(key)) return cache.get(key)!;
  if (typeof document === 'undefined') return text.length * 46;
  if (!ctx) ctx = document.createElement('canvas').getContext('2d');
  if (!ctx) return text.length * 46;
  ctx.font = `${italic ? 'italic ' : ''}${weight} 100px ${family}`;
  const w = ctx.measureText(text).width;
  if (ready) cache.set(key, w);
  return w;
};
/** Кегль, при котором слово занимает maxW (но не больше maxSize). */
export const fit = (text: string, maxW: number, maxSize: number, ready: boolean, italic = false, family = DISPLAY, weight = 900) =>
  Math.min(maxSize, (maxW / Math.max(1, measure(text, family, weight, italic, ready))) * 100);

// ── Мир: поле, сцена, камера ─────────────────────────────────────────────────
export const Stage: React.FC<{ bg?: string; children?: React.ReactNode }> = ({ bg = C.black, children }) => (
  <KineticFonts>
    <AbsoluteFill style={{ background: bg, overflow: 'hidden' }}>
      <DuoDefs />
      {children}
    </AbsoluteFill>
  </KineticFonts>
);

/** Цветовое поле: меняется жёстко, в кадр доли. flips — [{at, field}] по возрастанию. */
export const fieldAt = (f: number, flips: { at: number; field: FieldName }[]) => {
  let cur = flips[0]?.field ?? 'black';
  for (const x of flips) if (f >= x.at) cur = x.field;
  return FIELDS[cur];
};
export const Field: React.FC<{ f: number; flips: { at: number; field: FieldName }[] }> = ({ f, flips }) => (
  <AbsoluteFill style={{ background: fieldAt(f, flips).bg }} />
);

/**
 * Камера-удар: на каждой доле — рывок наезда за 1 кадр и отдача за 6–8, лёгкий доворот,
 * между долями — дрожь руки ступенькой раз в 3 кадра. Плавного дрейфа нет.
 */
export const PunchCam: React.FC<{ f: number; hits: number[]; amp?: number; rot?: number; jitter?: number; ox?: number; oy?: number; children: React.ReactNode }> = ({
  f,
  hits,
  amp = 0.07,
  rot = 1.4,
  jitter = 3,
  ox = 540,
  oy = 835,
  children,
}) => {
  let k = 0;
  let idx = -1;
  hits.forEach((h, i) => {
    const v = kick(f, h, 7);
    if (v > k) {
      k = v;
      idx = i;
    }
  });
  const s = 1 + amp * k;
  const r = (idx % 2 === 0 ? 1 : -1) * rot * k;
  const st = stepF(f, 3);
  const dx = (rnd(st * 1.3) - 0.5) * 2 * jitter;
  const dy = (rnd(st * 2.7 + 9) - 0.5) * 2 * jitter;
  return (
    <AbsoluteFill style={{ transform: `translate(${dx}px, ${dy}px) rotate(${r}deg) scale(${s})`, transformOrigin: `${ox}px ${oy}px` }}>{children}</AbsoluteFill>
  );
};

// ── Слово ───────────────────────────────────────────────────────────────────
type From = 'zoom' | 'left' | 'right' | 'up' | 'down' | 'cut';
/** Положение врезки за t кадров от удара: проскок за цель (2–3 кадра), возврат, стоп. */
const enter = (t: number, from: From) => {
  const a = seg(t, 0, 3, E.outExpo);
  const b = seg(t, 3, 6, E.outCubic);
  if (from === 'cut') return { x: 0, y: 0, s: 1, blur: 0, skew: 0 };
  if (from === 'zoom') return { x: 0, y: 0, s: lerp(b, lerp(a, 2.6, 0.92), 1), blur: (1 - a) * 16, skew: 0 };
  const d = from === 'left' ? [-1, 0] : from === 'right' ? [1, 0] : from === 'up' ? [0, -1] : [0, 1];
  const over = t < 3 ? lerp(a, 1, -0.035) : lerp(b, -0.035, 0); // 1 → проскок −3.5% → 0
  return { x: d[0] * over * 1300, y: d[1] * over * 1300, s: 1, blur: 0, skew: d[0] * (1 - a) * -18 };
};

export type SlamProps = {
  f: number;
  at: number;
  text: string;
  cx?: number;
  cy?: number;
  maxW?: number;
  maxSize?: number;
  size?: number;
  color?: string;
  from?: From;
  italic?: boolean;
  outline?: string;
  out?: number;
  weight?: number;
  family?: string;
  tracking?: number;
  blend?: 'difference';
};
/** Слово-удар: врезается за 3 кадра с проскоком, стоит намертво. out — кадр, где слово вырезается (исчезает склейкой). */
export const Slam: React.FC<SlamProps> = ({ f, at, text, cx = 540, cy = SAFE.cy, maxW = SAFE.w, maxSize = 520, size, color = C.white, from = 'zoom', italic = false, outline, out, weight = 900, family = DISPLAY, tracking = 0, blend }) => {
  const ready = useFonts();
  if (f < at || (out !== undefined && f >= out)) return null;
  const fs = size ?? fit(text, maxW, maxSize, ready, italic, family, weight);
  const p = enter(f - at, from);
  return (
    <div
      style={{
        position: 'absolute',
        left: cx,
        top: cy,
        transform: `translate(-50%, -50%) translate(${p.x}px, ${p.y}px) scale(${p.s}) skewX(${p.skew}deg)`,
        fontFamily: family,
        fontWeight: weight,
        fontStyle: italic ? 'italic' : 'normal',
        fontSize: fs,
        lineHeight: 0.84,
        letterSpacing: `${tracking}em`,
        whiteSpace: 'nowrap',
        textTransform: 'uppercase',
        color: outline ? 'transparent' : color,
        WebkitTextStroke: outline ? `${Math.max(3, fs * 0.018)}px ${outline}` : undefined,
        filter: p.blur > 0.5 ? `blur(${p.blur}px)` : undefined,
        mixBlendMode: blend,
      }}
    >
      {text}
    </div>
  );
};

/** Слово по доле: одно слово на весь кадр, каждое со своим полем. Сердце стиля. */
export const WordHits: React.FC<{
  f: number;
  words: { at: number; text: string; field: FieldName; from?: From; italic?: boolean; accent?: boolean }[];
  cy?: number;
  maxSize?: number;
  bg?: boolean;
}> = ({ f, words, cy = SAFE.cy, maxSize = 560, bg = true }) => {
  let cur = -1;
  words.forEach((w, i) => {
    if (f >= w.at) cur = i;
  });
  if (cur < 0) return null;
  const w = words[cur];
  const P = FIELDS[w.field];
  return (
    <AbsoluteFill>
      {bg && <AbsoluteFill style={{ background: P.bg }} />}
      <Slam f={f} at={w.at} text={w.text} cy={cy} maxSize={maxSize} color={w.accent ? P.acc : P.fg} from={w.from ?? 'zoom'} italic={w.italic} />
    </AbsoluteFill>
  );
};

/** Стопка строк во всю ширину: каждая строка врезается на свою долю. */
export const Stack: React.FC<{
  f: number;
  lines: { at: number; text: string; color?: string; from?: From; italic?: boolean; outline?: string }[];
  cy?: number;
  maxW?: number;
  maxSize?: number;
  gap?: number;
  color?: string;
}> = ({ f, lines, cy = SAFE.cy, maxW = SAFE.w, maxSize = 400, gap = 0.04, color = C.white }) => {
  const ready = useFonts();
  const sizes = lines.map((l) => fit(l.text, maxW, maxSize, ready, l.italic));
  const total = sizes.reduce((a, s) => a + s * 0.84, 0) + gap * (lines.length - 1) * 200;
  let y = cy - total / 2;
  return (
    <>
      {lines.map((l, i) => {
        const h = sizes[i] * 0.84;
        const my = y + h / 2;
        y += h + gap * 200;
        return <Slam key={i} f={f} at={l.at} text={l.text} cy={my} size={sizes[i]} color={l.color ?? color} from={l.from ?? (i % 2 ? 'right' : 'left')} italic={l.italic} outline={l.outline} />;
      })}
    </>
  );
};

/**
 * Резина: слово рождается сплющенным, вытягивается выше роста и садится (rubber),
 * или наоборот — обмякает и проседает (sag, «скучно»). Анимация на двойках.
 */
export const Stretch: React.FC<{ f: number; at: number; text: string; mode?: 'rubber' | 'sag'; cy?: number; color?: string; maxSize?: number }> = ({
  f,
  at,
  text,
  mode = 'rubber',
  cy = SAFE.cy,
  color = C.white,
  maxSize = 480,
}) => {
  const ready = useFonts();
  if (f < at) return null;
  const t = stepF(f - at, 2);
  const fs = fit(text, SAFE.w, maxSize, ready);
  let sy = 1;
  let ty = 0;
  if (mode === 'rubber') {
    sy = t < 2 ? lerp(t / 2, 0.12, 1.75) : t < 6 ? lerp(seg(t, 2, 6, E.outCubic), 1.75, 0.82) : lerp(seg(t, 6, 10, E.outCubic), 0.82, 1);
  } else {
    sy = lerp(seg(t, 2, 16, E.outCubic), 1, 0.42);
    ty = lerp(seg(t, 2, 16, E.outCubic), 0, fs * 0.3);
  }
  const sx = mode === 'rubber' ? 1 / Math.sqrt(sy) : lerp(seg(t, 2, 16), 1, 1.04);
  return (
    <div
      style={{
        position: 'absolute',
        left: 540,
        top: cy + ty,
        transform: `translate(-50%, -50%) scale(${Math.min(sx, 1.25)}, ${sy})`,
        transformOrigin: mode === 'sag' ? '50% 100%' : '50% 50%',
        fontFamily: DISPLAY,
        fontWeight: 900,
        fontSize: fs,
        lineHeight: 0.84,
        whiteSpace: 'nowrap',
        textTransform: 'uppercase',
        color,
      }}
    >
      {text}
    </div>
  );
};

/** Разрез: лезвие проходит по слову за 2 кадра, половины разъезжаются вдоль разреза и улетают. */
export const Slice: React.FC<{ f: number; at: number; cut: number; text: string; cy?: number; color?: string; blade?: string; angle?: number; maxSize?: number; from?: From }> = ({
  f,
  at,
  cut,
  text,
  cy = SAFE.cy,
  color = C.white,
  blade = C.red,
  angle = -14,
  maxSize = 520,
  from = 'zoom',
}) => {
  const ready = useFonts();
  if (f < at) return null;
  const fs = fit(text, SAFE.w, maxSize, ready);
  const t = f - cut;
  const p = enter(f - at, from);
  const sep = t < 2 ? 0 : seg(t, 2, 4, E.outExpo) * 40 + seg(t, 5, 10, E.inExpo) * 1600;
  const rad = (angle * Math.PI) / 180;
  const ux = Math.cos(rad);
  const uy = Math.sin(rad);
  // линия разреза через центр блока под углом angle → две полуплоскости
  const H = fs * 1.2;
  const dy = (540 * Math.tan(-rad) * 100) / H;
  const yL = 50 + dy;
  const yR = 50 - dy;
  const half = (top: boolean): React.CSSProperties => ({
    position: 'absolute',
    inset: 0,
    clipPath: top ? `polygon(0% -50%, 100% -50%, 100% ${yR}%, 0% ${yL}%)` : `polygon(0% ${yL}%, 100% ${yR}%, 100% 150%, 0% 150%)`,
    transform: `translate(${(top ? 1 : -1) * ux * sep}px, ${(top ? 1 : -1) * uy * sep - (top ? 1 : -1) * sep * 0.12}px)`,
  });
  const word = (
    <div style={{ fontFamily: DISPLAY, fontWeight: 900, fontSize: fs, lineHeight: 0.84, whiteSpace: 'nowrap', textTransform: 'uppercase', color, textAlign: 'center' }}>{text}</div>
  );
  const bladeOn = t >= 0 && t < 3;
  return (
    <AbsoluteFill>
      <div style={{ position: 'absolute', left: 0, right: 0, top: cy - fs * 0.6, height: fs * 1.2, transform: `translate(${p.x}px, ${p.y}px) scale(${p.s})`, filter: p.blur > 0.5 ? `blur(${p.blur}px)` : undefined }}>
        <div style={{ ...half(true), display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{word}</div>
        <div style={{ ...half(false), display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{word}</div>
      </div>
      {bladeOn && (
        <div
          style={{
            position: 'absolute',
            left: -200,
            width: 1480,
            top: cy - 9,
            height: 18,
            background: blade,
            transform: `rotate(${angle}deg) scaleX(${t === 0 ? 0.5 : 1})`,
            transformOrigin: t === 0 ? '0% 50%' : '50% 50%',
          }}
        />
      )}
    </AbsoluteFill>
  );
};

/** Эхо: на ударе за словом вспыхивают 4 контурные копии и за 10 кадров схлопываются в него. */
export const Echo: React.FC<SlamProps & { echo?: string; n?: number }> = (props) => {
  const { f, at, echo = C.lime, n = 4 } = props;
  const ready = useFonts();
  if (f < at) return null;
  const fs = props.size ?? fit(props.text, props.maxW ?? SAFE.w, props.maxSize ?? 520, ready, props.italic);
  const t = f - at;
  const c = seg(t, 3, 12, E.outCubic);
  return (
    <>
      {t < 12 &&
        Array.from({ length: n }, (_, i) => {
          const k = (i + 1) * (1 - c);
          return (
            <div
              key={i}
              style={{
                position: 'absolute',
                left: props.cx ?? 540,
                top: (props.cy ?? SAFE.cy) - k * fs * 0.22,
                transform: `translate(-50%, -50%) scale(${1 + k * 0.06})`,
                fontFamily: DISPLAY,
                fontWeight: 900,
                fontSize: fs,
                lineHeight: 0.84,
                whiteSpace: 'nowrap',
                textTransform: 'uppercase',
                fontStyle: props.italic ? 'italic' : 'normal',
                color: 'transparent',
                WebkitTextStroke: `${Math.max(3, fs * 0.012)}px ${echo}`,
                opacity: t < 2 ? 0 : 1 - i * 0.18,
              }}
            >
              {props.text}
            </div>
          );
        })}
      <Slam {...props} size={fs} />
    </>
  );
};

// ── Чужой кадр: дуотон, врезка, полосы, вспышка-монтаж ───────────────────────
const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16) / 255);
/** Дуотоны: любое видео перекрашивается в два цвета пака. Тень → первый цвет, свет → второй. */
export const DUO: Record<string, [string, string]> = {
  lime: [C.black, C.lime],
  blue: [C.blue, C.white],
  red: [C.red, C.white],
  ink: [C.black, C.white],
  acid: [C.blue, C.lime],
  hot: [C.black, C.red],
};
export const DuoDefs: React.FC = () => (
  <svg width={0} height={0} style={{ position: 'absolute' }}>
    <defs>
      {Object.entries(DUO).map(([k, [a, b]]) => {
        const A = hex(a);
        const B = hex(b);
        return (
          <filter key={k} id={`duo-${k}`} colorInterpolationFilters="sRGB">
            <feColorMatrix type="matrix" values="0.3 0.59 0.11 0 0  0.3 0.59 0.11 0 0  0.3 0.59 0.11 0 0  0 0 0 1 0" />
            <feComponentTransfer>
              <feFuncR type="linear" slope={2.1} intercept={-0.12} />
              <feFuncG type="linear" slope={2.1} intercept={-0.12} />
              <feFuncB type="linear" slope={2.1} intercept={-0.12} />
            </feComponentTransfer>
            <feComponentTransfer>
              <feFuncR type="table" tableValues={`${A[0]} ${B[0]}`} />
              <feFuncG type="table" tableValues={`${A[1]} ${B[1]}`} />
              <feFuncB type="table" tableValues={`${A[2]} ${B[2]}`} />
            </feComponentTransfer>
          </filter>
        );
      })}
    </defs>
  </svg>
);

/** Видео-исходники шоурила и демо (кадры без текста). Длительность — в кадрах 30 fps. */
export const FOOT = {
  orbA: { src: 'kinetic/footage/orb-a.mp4', dur: 93 },
  trio: { src: 'kinetic/footage/orb-trio.mp4', dur: 78 },
  tilt: { src: 'kinetic/footage/orb-tilt.mp4', dur: 117 },
  orbC: { src: 'kinetic/footage/orb-c.mp4', dur: 70 },
} as const;
export type FootName = keyof typeof FOOT;

/** Видео на всю площадь родителя (contain — поле дуотона продолжает тёмный фон кадра; cover — обрез), опционально в дуотоне, с кадрированием zoom/x/y. */
export const Footage: React.FC<{ name?: FootName; src?: string; dur?: number; duo?: keyof typeof DUO; zoom?: number; x?: number; y?: number; from?: number; fit?: 'contain' | 'cover' }> = ({
  name = 'orbA',
  src,
  dur,
  duo,
  zoom = 1,
  x = 0,
  y = 0,
  from = 0,
  fit = 'contain',
}) => {
  const s = src ?? FOOT[name].src;
  const d = dur ?? FOOT[name].dur;
  return (
    <AbsoluteFill style={{ overflow: 'hidden', background: duo ? DUO[duo][0] : C.black }}>
      <Loop durationInFrames={Math.max(1, d - from)}>
        <OffthreadVideo
          src={staticFile(s)}
          muted
          startFrom={from}
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: fit, transform: `translate(${x}px, ${y}px) scale(${zoom})`, filter: duo ? `url(#duo-${duo})` : undefined }}
        />
      </Loop>
    </AbsoluteFill>
  );
};

/**
 * Врезка: чужой кадр в жёстком прямоугольнике, без рамки, с плоской цветной «тенью»-плитой.
 * Врезается с края за 3 кадра, на долях (hits) вздрагивает, уходит склейкой в out.
 */
export const Cut: React.FC<{ f: number; at: number; out?: number; x: number; y: number; w: number; h: number; rot?: number; plate?: string; from?: From; hits?: number[]; children: React.ReactNode }> = ({
  f,
  at,
  out,
  x,
  y,
  w,
  h,
  rot = -3,
  plate = C.lime,
  from = 'left',
  hits = [],
  children,
}) => {
  if (f < at || (out !== undefined && f >= out)) return null;
  const p = enter(f - at, from);
  const k = kicks(f, hits, 6);
  const plateIn = seg(f - at, 2, 5, E.outExpo);
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: w, height: h, transform: `translate(${p.x}px, ${p.y}px) rotate(${rot + k * 1.5}deg) scale(${p.s * (1 + k * 0.04)}) skewX(${p.skew}deg)` }}>
      <div style={{ position: 'absolute', inset: 0, background: plate, transform: `translate(${plateIn * 24}px, ${plateIn * 24}px)` }} />
      <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>{children}</div>
    </div>
  );
};

/** Полосы: кадр режется на n полос, каждая влетает со своей стороны (через 2 кадра), в каждой — свой кадр. */
export const Bars: React.FC<{ f: number; at: number; items: React.ReactNode[]; dir?: 'h' | 'v'; stagger?: number; shift?: number; top?: number; height?: number }> = ({
  f,
  at,
  items,
  dir = 'h',
  stagger = 3,
  shift,
  top = 0,
  height = 1920,
}) => {
  const n = items.length;
  return (
    <AbsoluteFill>
      {items.map((it, i) => {
        const a = at + i * stagger;
        if (f < a) return null;
        const p = enter(f - a, dir === 'h' ? (i % 2 ? 'right' : 'left') : i % 2 ? 'down' : 'up');
        const sh = shift !== undefined && f >= shift ? seg(f - shift, 0, 4, E.outExpo) * (i % 2 ? -1 : 1) * 120 : 0;
        const style: React.CSSProperties =
          dir === 'h'
            ? { left: 0, width: 1080, top: top + (height / n) * i, height: height / n + 1 }
            : { top, height, left: (1080 / n) * i, width: 1080 / n + 1 };
        return (
          <div key={i} style={{ position: 'absolute', ...style, overflow: 'hidden', transform: `translate(${p.x + (dir === 'h' ? sh : 0)}px, ${p.y + (dir === 'v' ? sh : 0)}px)` }}>
            {it}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

/** Вспышка-монтаж: каждые `every` кадров новая картинка; на каждой смене — кадр-вспышка через раз. */
export const Burst: React.FC<{ f: number; at: number; every?: number; items: React.ReactNode[]; flash?: string; out?: number }> = ({ f, at, every = 3, items, flash = C.white, out }) => {
  if (f < at || (out !== undefined && f >= out)) return null;
  const i = Math.min(items.length - 1, Math.floor((f - at) / every));
  const local = (f - at) % every;
  return (
    <AbsoluteFill>
      {items[i]}
      {local === 0 && i % 2 === 1 && <AbsoluteFill style={{ background: flash, opacity: 0.85 }} />}
    </AbsoluteFill>
  );
};

/** Плоская графика-картинка без видео: лучи, полутон, шахматка, полосы, круг. Для монтажа и фона. */
export const Graphic: React.FC<{ f: number; kind: 'rays' | 'halftone' | 'checker' | 'stripes' | 'circle'; a?: string; b?: string }> = ({ f, kind, a = C.black, b = C.lime }) => {
  const st = stepF(f, 3);
  if (kind === 'rays') {
    const n = 18;
    const rot = st * 2;
    const path = Array.from({ length: n }, (_, i) => {
      const a0 = ((i * 2) / (n * 2)) * Math.PI * 2;
      const a1 = ((i * 2 + 1) / (n * 2)) * Math.PI * 2;
      return `M540 835 L${540 + Math.cos(a0) * 2400} ${835 + Math.sin(a0) * 2400} L${540 + Math.cos(a1) * 2400} ${835 + Math.sin(a1) * 2400} Z`;
    }).join(' ');
    return (
      <AbsoluteFill style={{ background: a }}>
        <svg width={1080} height={1920} style={{ transform: `rotate(${rot}deg)`, transformOrigin: '540px 835px' }}>
          <path d={path} fill={b} />
        </svg>
      </AbsoluteFill>
    );
  }
  if (kind === 'halftone') {
    const off = (st * 4) % 60;
    return <AbsoluteFill style={{ background: a, backgroundImage: `radial-gradient(${b} 34%, transparent 36%)`, backgroundSize: '60px 60px', backgroundPosition: `${off}px ${off}px` }} />;
  }
  if (kind === 'checker') {
    const off = (st * 6) % 240;
    return <AbsoluteFill style={{ background: `repeating-conic-gradient(${a} 0 25%, ${b} 0 50%)`, backgroundSize: '240px 240px', backgroundPosition: `${off}px 0px` }} />;
  }
  if (kind === 'stripes') {
    const off = (st * 10) % 160;
    return <AbsoluteFill style={{ background: `repeating-linear-gradient(-30deg, ${a} 0 80px, ${b} 80px 160px)`, backgroundPosition: `${off}px 0` }} />;
  }
  const r = 300 + (stepF(f, 4) % 8) * 6;
  return (
    <AbsoluteFill style={{ background: a }}>
      <div style={{ position: 'absolute', left: 540 - r, top: 835 - r, width: r * 2, height: r * 2, borderRadius: '50%', background: b }} />
    </AbsoluteFill>
  );
};

// ── Переходы ────────────────────────────────────────────────────────────────
/** Плита: косой цветной блок пробивает кадр за `dur` кадров; на середине (at+dur/2) — смена сцены. */
export const Smash: React.FC<{ f: number; at: number; color?: string; angle?: number; dur?: number; dir?: 1 | -1 }> = ({ f, at, color = C.lime, angle = -18, dur = 8, dir = 1 }) => {
  const t = f - at;
  if (t < 0 || t > dur) return null;
  const h = dur / 2;
  const x = t <= h ? lerp(seg(t, 0, h, E.inCubic), -1, 0) : lerp(seg(t, h, dur, E.outExpo), 0, 1);
  return (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      <div style={{ position: 'absolute', left: -1100, top: -600, width: 3300, height: 3100, background: color, transform: `rotate(${angle}deg) translateX(${dir * x * 3400}px)`, transformOrigin: '50% 50%' }} />
    </AbsoluteFill>
  );
};

/** Жалюзи: n горизонтальных полос захлопываются через кадр и раскрываются в другую сторону. Смена сцены на at+5. */
export const Shutter: React.FC<{ f: number; at: number; n?: number; color?: string; dur?: number }> = ({ f, at, n = 8, color = C.black, dur = 11 }) => {
  const t = f - at;
  if (t < 0 || t > dur + n * 0.5) return null;
  return (
    <AbsoluteFill style={{ pointerEvents: 'none' }}>
      {Array.from({ length: n }, (_, i) => {
        const d = i * 0.5;
        const close = seg(t - d, 0, 3, E.outExpo);
        const open = seg(t - d, 6, 9, E.inExpo);
        const sx = close * (1 - open);
        return (
          <div
            key={i}
            style={{ position: 'absolute', left: 0, width: 1080, top: (1920 / n) * i, height: 1920 / n + 1, background: color, transform: `scaleX(${sx})`, transformOrigin: open > 0 ? (i % 2 ? '0% 50%' : '100% 50%') : i % 2 ? '100% 50%' : '0% 50%' }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/** Вспышка: 1–2 кадра белого (flash) или инверсия кадра (invert) — на ударе или вместо склейки. */
export const Flash: React.FC<{ f: number; at: number; len?: number; color?: string; mode?: 'flash' | 'invert' }> = ({ f, at, len = 2, color = C.white, mode = 'flash' }) => {
  if (f < at || f >= at + len) return null;
  return <AbsoluteFill style={{ background: mode === 'invert' ? C.white : color, mixBlendMode: mode === 'invert' ? 'difference' : 'normal', pointerEvents: 'none' }} />;
};

/** Удар насквозь: старая сцена за 5 кадров влетает в камеру через точку (ox, oy), новая выбивается из глубины с проскоком. */
export const PunchThrough: React.FC<{ f: number; at: number; a: React.ReactNode; b: React.ReactNode; ox?: number; oy?: number }> = ({ f, at, a, b, ox = 540, oy = 835 }) => {
  const t = f - at;
  if (t < 0) return <AbsoluteFill>{a}</AbsoluteFill>;
  if (t < 5) {
    const s = lerp(seg(t, 0, 5, E.inExpo), 1, 9);
    return <AbsoluteFill style={{ transform: `scale(${s})`, transformOrigin: `${ox}px ${oy}px`, filter: `blur(${t * 3}px)` }}>{a}</AbsoluteFill>;
  }
  const u = t - 5;
  const s = u < 3 ? lerp(seg(u, 0, 3, E.outExpo), 0.55, 1.05) : lerp(seg(u, 3, 7, E.outCubic), 1.05, 1);
  return <AbsoluteFill style={{ transform: `scale(${s})`, transformOrigin: `${ox}px ${oy}px` }}>{b}</AbsoluteFill>;
};

// ── Инфо: число, ярлык ───────────────────────────────────────────────────────
/** Число-удар: до lock цифры перебираются каждые 2 кадра, на lock итог врезается и стоит. */
export const NumberSlam: React.FC<{ f: number; at: number; lock: number; value: string; cy?: number; color?: string; maxSize?: number; italic?: boolean }> = ({
  f,
  at,
  lock,
  value,
  cy = SAFE.cy,
  color = C.white,
  maxSize = 760,
  italic = true,
}) => {
  if (f < at) return null;
  if (f < lock) {
    const st = stepF(f, 2);
    const fake = value.replace(/\d/g, (_, i: number) => String(Math.floor(rnd(st * 7.1 + i * 3.3) * 10)));
    return <Slam f={f} at={st} text={fake} cy={cy} maxSize={maxSize} color={color} from="cut" italic={italic} />;
  }
  return <Echo f={f} at={lock} text={value} cy={cy} maxSize={maxSize} color={color} italic={italic} echo={C.lime} />;
};

/** Ярлык: плашка акцентного цвета с чёрным текстом, врезается сбоку, живёт ступенчатым покачиванием. */
export const Tag: React.FC<{ f: number; at: number; text: string; x: number; y: number; rot?: number; bg?: string; fg?: string; size?: number; from?: From; out?: number; anchor?: 'left' | 'right' | 'center' }> = ({
  f,
  at,
  text,
  x,
  y,
  rot = -4,
  bg = C.lime,
  fg = C.black,
  size = 76,
  from = 'left',
  out,
  anchor = 'left',
}) => {
  if (f < at || (out !== undefined && f >= out)) return null;
  const p = enter(f - at, from);
  const wob = (Math.floor((f - at) / 6) % 2 ? 1 : -1) * 0.8;
  const tx = anchor === 'left' ? '0' : anchor === 'right' ? '-100%' : '-50%';
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(${tx}, -50%) translate(${p.x}px, ${p.y}px) rotate(${rot + (f - at > 6 ? wob : 0)}deg) skewX(${p.skew}deg)`,
        background: bg,
        color: fg,
        fontFamily: TEXT,
        fontWeight: 900,
        fontSize: size,
        lineHeight: 1,
        padding: `${size * 0.22}px ${size * 0.34}px ${size * 0.26}px`,
        textTransform: 'uppercase',
        whiteSpace: 'nowrap',
      }}
    >
      {text}
    </div>
  );
};

// ── Декор поверх: звезда, стрелка, скобки, молния, лучи, крест ───────────────
const pop = (t: number) => (t < 0 ? 0 : t < 2 ? lerp(t / 2, 0.2, 1.2) : lerp(seg(t, 2, 5, E.outCubic), 1.2, 1));

/** Звезда-вспышка: острая звезда за словом, появляется рывком, поворачивается ступеньками. */
export const Starburst: React.FC<{ f: number; at: number; x?: number; y?: number; r?: number; color?: string; points?: number; out?: number; hits?: number[] }> = ({
  f,
  at,
  x = 540,
  y = SAFE.cy,
  r = 520,
  color = C.lime,
  points = 16,
  out,
  hits = [],
}) => {
  if (f < at || (out !== undefined && f >= out)) return null;
  const s = pop(f - at) * (1 + kicks(f, hits, 6) * 0.12);
  const rot = stepF(f - at, 4) * 1.6;
  const d = Array.from({ length: points * 2 }, (_, i) => {
    const a = (i / (points * 2)) * Math.PI * 2;
    const rr = i % 2 ? r * 0.62 : r;
    return `${i ? 'L' : 'M'}${(Math.cos(a) * rr).toFixed(1)} ${(Math.sin(a) * rr).toFixed(1)}`;
  }).join(' ');
  return (
    <svg style={{ position: 'absolute', left: x - r, top: y - r, overflow: 'visible' }} width={r * 2} height={r * 2}>
      <g transform={`translate(${r} ${r}) rotate(${rot}) scale(${s})`}>
        <path d={`${d} Z`} fill={color} />
      </g>
    </svg>
  );
};

/** Стрелка: толстая, врезается вдоль своей оси, на долях тычет вперёд. */
export const Arrow: React.FC<{ f: number; at: number; x: number; y: number; angle?: number; len?: number; color?: string; hits?: number[]; out?: number }> = ({
  f,
  at,
  x,
  y,
  angle = 0,
  len = 260,
  color = C.lime,
  hits = [],
  out,
}) => {
  if (f < at || (out !== undefined && f >= out)) return null;
  const t = f - at;
  const back = (1 - seg(t, 0, 3, E.outExpo)) * -500 + kicks(f, hits, 6) * 30;
  const w = len * 0.22;
  return (
    <div style={{ position: 'absolute', left: x, top: y, transform: `rotate(${angle}deg) translateX(${back}px)`, transformOrigin: '0 0' }}>
      <svg width={len} height={w * 2.4} style={{ position: 'absolute', left: -len, top: -w * 1.2, overflow: 'visible' }}>
        <path d={`M0 ${w * 0.75} L${len - w * 1.3} ${w * 0.75} L${len - w * 1.3} 0 L${len} ${w * 1.2} L${len - w * 1.3} ${w * 2.4} L${len - w * 1.3} ${w * 1.65} L0 ${w * 1.65} Z`} fill={color} />
      </svg>
    </div>
  );
};

/** Скобки-прицел: четыре угла защёлкиваются вокруг цели снаружи внутрь. */
export const Brackets: React.FC<{ f: number; at: number; x: number; y: number; w: number; h: number; color?: string; thick?: number; len?: number; out?: number }> = ({
  f,
  at,
  x,
  y,
  w,
  h,
  color = C.lime,
  thick = 14,
  len = 90,
  out,
}) => {
  if (f < at || (out !== undefined && f >= out)) return null;
  const o = (1 - seg(f - at, 0, 3, E.outExpo)) * 80 - kick(f, at + 3, 5) * -10;
  const corner = (cx: number, cy: number, sx: number, sy: number, k: number) => (
    <div key={k} style={{ position: 'absolute', left: cx + sx * -o - (sx < 0 ? 0 : len), top: cy + sy * -o - (sy < 0 ? 0 : len), width: len, height: len }}>
      <div style={{ position: 'absolute', [sy < 0 ? 'top' : 'bottom']: 0, [sx < 0 ? 'left' : 'right']: 0, width: len, height: thick, background: color }} />
      <div style={{ position: 'absolute', [sy < 0 ? 'top' : 'bottom']: 0, [sx < 0 ? 'left' : 'right']: 0, width: thick, height: len, background: color }} />
    </div>
  );
  return (
    <>
      {corner(x, y, -1, -1, 0)}
      {corner(x + w, y, 1, -1, 1)}
      {corner(x, y + h, -1, 1, 2)}
      {corner(x + w, y + h, 1, 1, 3)}
    </>
  );
};

/** Молния-подчёркивание: зигзаг прорисовывается за 3 кадра под словом. */
export const Zigzag: React.FC<{ f: number; at: number; x: number; y: number; w: number; color?: string; thick?: number; out?: number }> = ({ f, at, x, y, w, color = C.lime, thick = 16, out }) => {
  if (f < at || (out !== undefined && f >= out)) return null;
  const p = seg(stepF(f - at, 1), 0, 3);
  const n = 9;
  const pts = Array.from({ length: n + 1 }, (_, i) => `${((i / n) * w).toFixed(1)},${i % 2 ? 26 : 0}`).join(' ');
  return (
    <svg style={{ position: 'absolute', left: x, top: y, overflow: 'visible' }} width={w} height={30}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth={thick} strokeLinejoin="miter" strokeDasharray={w * 1.6} strokeDashoffset={w * 1.6 * (1 - p)} />
    </svg>
  );
};

/** Лучи скорости: радиальные штрихи из точки удара, 6 кадров, перерисовка через кадр. */
export const SpeedLines: React.FC<{ f: number; at: number; x?: number; y?: number; color?: string; n?: number; inner?: number; len?: number; dur?: number }> = ({
  f,
  at,
  x = 540,
  y = SAFE.cy,
  color = C.white,
  n = 26,
  inner = 420,
  len = 360,
  dur = 7,
}) => {
  const t = f - at;
  if (t < 0 || t >= dur) return null;
  const st = stepF(t, 2);
  return (
    <svg style={{ position: 'absolute', inset: 0 }} width={1080} height={1920}>
      {Array.from({ length: n }, (_, i) => {
        const a = (i / n) * Math.PI * 2 + rnd(i + st) * 0.12;
        const r0 = inner + rnd(i * 3 + st) * 80 + t * 30;
        const r1 = r0 + len * (0.5 + rnd(i * 7 + st) * 0.6);
        return <line key={i} x1={x + Math.cos(a) * r0} y1={y + Math.sin(a) * r0} x2={x + Math.cos(a) * r1} y2={y + Math.sin(a) * r1} stroke={color} strokeWidth={10 - t} strokeLinecap="butt" />;
      })}
    </svg>
  );
};

/** Крест-искра: маленький «+» выстреливает на доле. */
export const Plus: React.FC<{ f: number; at: number; x: number; y: number; size?: number; color?: string; out?: number }> = ({ f, at, x, y, size = 60, color = C.lime, out }) => {
  if (f < at || (out !== undefined && f >= out)) return null;
  const s = pop(f - at);
  const r = stepF(f - at, 4) * 5;
  return (
    <div style={{ position: 'absolute', left: x - size / 2, top: y - size / 2, width: size, height: size, transform: `scale(${s}) rotate(${r}deg)` }}>
      <div style={{ position: 'absolute', left: size * 0.38, top: 0, width: size * 0.24, height: size, background: color }} />
      <div style={{ position: 'absolute', top: size * 0.38, left: 0, height: size * 0.24, width: size, background: color }} />
    </div>
  );
};

/** Лента: наклонная полоса с бегущим капсом. Раскатывается за 4 кадра, бежит непрерывно. */
export const Tape: React.FC<{ f: number; at: number; text: string; y: number; angle?: number; bg?: string; fg?: string; h?: number; speed?: number; dir?: 1 | -1; out?: number }> = ({
  f,
  at,
  text,
  y,
  angle = -8,
  bg = C.lime,
  fg = C.black,
  h = 150,
  speed = 9,
  dir = 1,
  out,
}) => {
  const ready = useFonts();
  if (f < at || (out !== undefined && f >= out)) return null;
  const unit = `${text} ✶ `;
  const fs = h * 0.78;
  const uw = (measure(unit, DISPLAY, 900, false, ready) / 100) * fs;
  const reps = Math.ceil(3200 / Math.max(50, uw)) + 2;
  const off = ((f - at) * speed) % uw;
  const open = seg(f - at, 0, 4, E.outExpo);
  return (
    <div style={{ position: 'absolute', left: -800, width: 2680, top: y - h / 2, height: h, background: bg, transform: `rotate(${angle}deg) scaleX(${open})`, transformOrigin: dir > 0 ? '30% 50%' : '70% 50%', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 0, height: h, left: dir > 0 ? -off : off - uw, display: 'flex', alignItems: 'center', whiteSpace: 'nowrap', fontFamily: DISPLAY, fontWeight: 900, fontSize: fs, color: fg, textTransform: 'uppercase', lineHeight: 1 }}>
        {Array.from({ length: reps }, () => unit).join('')}
      </div>
    </div>
  );
};

// ── Режим «говорящая голова» ──────────────────────────────────────────────────
export type CapWord = { text: string; s: number; e?: number; key?: boolean };
/**
 * Субтитры «Удара»: всегда на одном месте внизу (низ блока y=1440), 1–3 слова, белый Rubik 900
 * с чёрной обводкой, без плашки. Слово появляется в кадр, когда сказано (рывок 1.25→1 за 3 кадра).
 * Ключевое слово — акцентным цветом и чуть крупнее. hide — интервалы, где на экране слово-удар (не дублировать).
 */
export const Captions: React.FC<{ f: number; words: CapWord[]; per?: number; size?: number; accent?: string; hide?: [number, number][]; bottom?: number }> = ({
  f,
  words,
  per = 3,
  size = 88,
  accent = C.lime,
  hide = [],
  bottom = SAFE.bottom,
}) => {
  if (hide.some(([a, b]) => f >= a && f < b)) return null;
  // разбивка на группы: до per слов, точка/вопрос/восклицание закрывают группу
  const chunks: CapWord[][] = [];
  let cur: CapWord[] = [];
  words.forEach((w) => {
    cur.push(w);
    if (cur.length >= per || /[.!?…,:]$/.test(w.text)) {
      chunks.push(cur);
      cur = [];
    }
  });
  if (cur.length) chunks.push(cur);
  const idx = chunks.findIndex((c, i) => f >= c[0].s && (i === chunks.length - 1 ? f < (c[c.length - 1].e ?? c[c.length - 1].s + 20) : f < chunks[i + 1][0].s));
  if (idx < 0) return null;
  return (
    <div style={{ position: 'absolute', left: 140, width: 800, bottom: 1920 - bottom }}>
      <CaptionGroup f={f} words={chunks[idx]} size={size} accent={accent} />
    </div>
  );
};

/**
 * Одна группа субтитров «Удара» — только вид: строка слов по центру, с переносом.
 * Что показывать и когда, решает тот, кто её ставит (`Captions` или субтитры фабрики).
 */
export const CaptionGroup: React.FC<{ f: number; words: CapWord[]; size?: number; accent?: string }> = ({ f, words, size = 88, accent = C.lime }) => {
  const sw = Math.round(size * 0.1);
  const shadow = Array.from({ length: 16 }, (_, i) => {
    const a = (i / 16) * Math.PI * 2;
    return `${(Math.cos(a) * sw).toFixed(1)}px ${(Math.sin(a) * sw).toFixed(1)}px 0 #000`;
  }).join(', ');
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'flex-end', columnGap: size * 0.3, rowGap: 0 }}>
      {words.map((w, i) => {
        if (f < w.s) return null;
        const t = f - w.s;
        const s = t < 3 ? lerp(seg(t, 0, 3, E.outExpo), 1.12, 1) : 1;
        const ty = t < 3 ? lerp(seg(t, 0, 3, E.outExpo), 14, 0) : 0;
        return (
          <span
            key={i}
            style={{
              display: 'inline-block',
              fontFamily: TEXT,
              fontWeight: 900,
              fontSize: w.key ? size * 1.14 : size,
              lineHeight: 1.08,
              textTransform: 'uppercase',
              color: w.key ? accent : C.white,
              textShadow: `${shadow}, 0 ${sw * 0.8}px 0 #000`,
              transform: `translateY(${ty}px) scale(${s})`,
              transformOrigin: '50% 100%',
            }}
          >
            {w.text.replace(/[,]$/, '')}
          </span>
        );
      })}
    </div>
  );
};

/**
 * Камера говорящей головы: джамп-каты по крупности. cuts — [{at, z, x, y}]: на каждой смене мысли
 * крупность меняется мгновенно (1.0 ↔ 1.18 ↔ 1.32) + рывок отдачи 3%. Лицо держать в ox/oy.
 */
export const HeadCam: React.FC<{ f: number; cuts: { at: number; z: number; x?: number; y?: number }[]; ox?: number; oy?: number; hits?: number[]; children: React.ReactNode }> = ({
  f,
  cuts,
  ox = 540,
  oy = 700,
  hits = [],
  children,
}) => {
  let c = { at: 0, z: 1, x: 0, y: 0 } as { at: number; z: number; x?: number; y?: number };
  for (const x of cuts) if (f >= x.at) c = x;
  const k = Math.max(kick(f, c.at, 6), kicks(f, hits, 6));
  const s = c.z * (1 + 0.03 * k);
  return <AbsoluteFill style={{ transform: `translate(${c.x ?? 0}px, ${c.y ?? 0}px) scale(${s})`, transformOrigin: `${ox}px ${oy}px` }}>{children}</AbsoluteFill>;
};

/**
 * Верхняя врезка: сверху вбивается панель (y 0…960) с примером/видео, голова уезжает вниз.
 * Уходит обратно склейкой в out. Субтитры остаются на своём месте.
 */
export const SplitTop: React.FC<{ f: number; at: number; out?: number; panel: React.ReactNode; plate?: string; children: React.ReactNode }> = ({ f, at, out, panel, plate = C.lime, children }) => {
  const on = f >= at && (out === undefined || f < out);
  const p = on ? seg(f - at, 0, 3, E.outExpo) : 0;
  const over = on ? lerp(seg(f - at, 3, 6, E.outCubic), 1.03, 1) : 1;
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ transform: `translateY(${p * 420}px)` }}>{children}</AbsoluteFill>
      {on && (
        <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 960, transform: `translateY(${(p * over - 1) * 960}px)`, overflow: 'hidden' }}>
          {panel}
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 22, background: plate }} />
        </div>
      )}
    </AbsoluteFill>
  );
};

/**
 * Стоп-кадр-дуотон: на панчлайне кадр замирает, перекрашивается в два цвета и толкается наезд 6%.
 * Поверх обычно — слово-удар. Внутри Freeze останавливается и видео.
 */
export const FreezeDuo: React.FC<{ f: number; at: number; out: number; duo?: keyof typeof DUO; children: React.ReactNode }> = ({ f, at, out, duo = 'lime', children }) => {
  if (f < at || f >= out) return <AbsoluteFill>{children}</AbsoluteFill>;
  const s = 1.06 + kick(f, at, 6) * 0.04;
  return (
    <AbsoluteFill style={{ transform: `scale(${s})`, transformOrigin: '540px 760px', filter: `url(#duo-${duo})` }}>
      <Freeze frame={at}>{children}</Freeze>
    </AbsoluteFill>
  );
};

/** Заглушка говорящего для демо режима (только демо кита, не шоурил): плоский силуэт на сером. */
export const SpeakerStub: React.FC<{ f: number; tone?: string }> = ({ f, tone = '#3a3a40' }) => {
  const b = Math.sin(f * 0.08) * 4;
  return (
    <AbsoluteFill style={{ background: 'linear-gradient(180deg, #6d6f76 0%, #4b4d55 100%)' }}>
      <div style={{ position: 'absolute', left: 540 - 400, top: 1080 + b, width: 800, height: 1100, borderRadius: '400px 400px 0 0', background: tone }} />
      <div style={{ position: 'absolute', left: 540 - 175, top: 520 + b, width: 350, height: 440, borderRadius: '50%', background: tone }} />
      <div style={{ position: 'absolute', left: 540 - 75, top: 900 + b, width: 150, height: 220, background: tone }} />
    </AbsoluteFill>
  );
};

/** Линии безопасной зоны для проверки кадров (в рендер ролика не включать). */
export const SafeGuides: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: 'none' }}>
    <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE.top, height: 2, background: 'magenta' }} />
    <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE.bottom, height: 2, background: 'magenta' }} />
    <div style={{ position: 'absolute', left: SAFE.buttonsX, top: SAFE.buttonsY, right: 0, bottom: 0, border: '2px dashed magenta' }} />
  </AbsoluteFill>
);
