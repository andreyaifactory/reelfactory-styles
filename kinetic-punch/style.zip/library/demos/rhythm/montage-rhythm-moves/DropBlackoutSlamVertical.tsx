// drop-blackout-slam · 竖版 9:16（1080×1920）。
// 保留：0–49 正常播放（呼吸 1.0↔1.02、节拍点每 12f）、50–61 纯黑 12f、62 标题 1.35→1（5f）、10px 震屏 τ≈2.5f（t≥14 归零）、亮环 16f。
// 竖版：FakeDashboard → FakeDashboardV；节拍点从右下角（按钮栏）移到安全区内左上 (90, 300)；
// "DROP" 340→330px（宽约 920，竖画宽内），对准安全区中心 y 835；亮环中心随之、半径 80→900 改 80→1000。
// 以下为横版原注释：
// EDM concert blackout 的节奏手法：假面板正常"播放"+节拍点闪；一帧切纯黑 12f 死寂；
// 白色大标题 "DROP" 撞入，同帧整屏 10px 震屏指数衰减，底色变 G.ink 并从中心泛出一圈快速消散的亮环；之后全静止。
import React from 'react';
import { useCurrentFrame, interpolate, Easing } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const DROP_BLACKOUT_SLAM_VERTICAL_DURATION = 130;
const h = (n: number) => {
  const s = Math.sin(n * 127.3) * 43758.5453;
  return s - Math.floor(s);
};
const BLACK_IN = 50;
const SLAM = 62;
const cl = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;

export const DropBlackoutSlamVertical: React.FC = () => {
  const f = useCurrentFrame();
  if (f < BLACK_IN) {
    const breathe = 1.01 + 0.01 * Math.sin((f / 48) * Math.PI * 2);
    const ph = f % 12;
    return (
      <div style={{ width: 1080, height: 1920, background: G.bg, overflow: 'hidden', position: 'relative' }}>
        <div style={{ width: 1080, height: 1920, transform: `scale(${breathe})`, transformOrigin: `50% ${SAFE_CY}px` }}>
          <FakeDashboardV variant="B" />
        </div>
        <div style={{ position: 'absolute', left: 72, top: 282, width: 36, height: 36, borderRadius: 18, background: G.ink, opacity: interpolate(ph, [0, 1, 5], [0.25, 1, 0.25], cl), transform: `scale(${interpolate(ph, [0, 1, 5], [1, 1.5, 1], cl)})` }} />
      </div>
    );
  }
  if (f < SLAM) return <div style={{ width: 1080, height: 1920, background: '#0c0c0c' }} />;
  const t = f - SLAM;
  const slamScale = interpolate(t, [0, 5], [1.35, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const amp = t >= 14 ? 0 : 10 * Math.exp(-t / 2.5);
  const shakeX = amp === 0 ? 0 : (h(f * 3.7 + 1) - 0.5) * 2 * amp;
  const shakeY = amp === 0 ? 0 : (h(f * 7.1 + 2) - 0.5) * 2 * amp;
  const ringR = interpolate(t, [0, 16], [80, 1000], { ...cl, easing: Easing.out(Easing.cubic) });
  const ringOpacity = interpolate(t, [0, 3, 16], [0.85, 0.55, 0], cl);
  return (
    <div style={{ width: 1080, height: 1920, background: G.ink, overflow: 'hidden', position: 'relative' }}>
      <div style={{ position: 'absolute', inset: 0, transform: `translate(${shakeX}px, ${shakeY}px)` }}>
        {t < 16 && <div style={{ position: 'absolute', left: 540 - ringR, top: SAFE_CY - ringR, width: ringR * 2, height: ringR * 2, borderRadius: '50%', border: '12px solid #ffffff', opacity: ringOpacity }} />}
        <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE_CY, transform: 'translateY(-50%)', display: 'flex', justifyContent: 'center' }}>
          <div style={{ fontFamily: 'Helvetica, Arial, sans-serif', fontWeight: 800, fontSize: 330, color: '#ffffff', letterSpacing: -6, transform: `scale(${slamScale})`, lineHeight: 1 }}>DROP</div>
        </div>
      </div>
    </div>
  );
};
