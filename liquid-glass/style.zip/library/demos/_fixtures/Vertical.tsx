// Vertical 9:16 —— 竖版（Reels / Shorts / TikTok，1080×1920）demo 的公共件。
// 竖版不是横版裁切：元素重新排布（横排→竖排、字号相对画宽放大），
// 时间轴与缓动参数保持原卡标定值不变。
//
// 安全区（平台界面会盖住的区域，竖版 demo 一律遵守）：
//   - 文字、贴纸、字幕、细节只放在 y 230…1440；
//   - 右下按钮栏：x > 940 且 y > 1000 不放任何东西；
//   - 1440 以下只允许背景与纯动画（纹理/风景），不放字和细节；
//   - 相机推近不能把字推出画面：字贴边时推近 ≤ 1.05。
import React from 'react';
import { AbsoluteFill } from 'remotion';
import { Card, G } from './Fixtures';

export const VW = 1080;
export const VH = 1920;
export const SAFE = { top: 230, bottom: 1440, left: 60, right: 1020, buttonsX: 940, buttonsY: 1000 } as const;
// 安全区的视觉中心：竖版主体默认对准这里，而不是画面几何中心 960
export const SAFE_CY = (SAFE.top + SAFE.bottom) / 2; // 835
export const SAFE_H = SAFE.bottom - SAFE.top; // 1210

// 内容层：一个正好覆盖安全区的绝对定位盒子（子元素按安全区坐标排版）
export const SafeArea: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE.top, height: SAFE_H, ...style }}>{children}</div>
);

// 居中到安全区中心的内容层（替代横版 AbsoluteFill 的 alignItems/justifyContent:center）
export const SafeCenter: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({ children, style }) => (
  <SafeArea style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', ...style }}>
    {children}
  </SafeArea>
);

// 调试：画出安全区线（只在开发时打开，成片不渲染）
export const SafeGuides: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: 'none' }}>
    <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE.top, height: 2, background: 'rgba(255,0,80,0.7)' }} />
    <div style={{ position: 'absolute', left: 0, right: 0, top: SAFE.bottom, height: 2, background: 'rgba(255,0,80,0.7)' }} />
    <div style={{ position: 'absolute', left: SAFE.buttonsX, top: SAFE.buttonsY, right: 0, bottom: 0, background: 'rgba(255,0,80,0.12)' }} />
  </AbsoluteFill>
);

// 竖版假页面（手机 App 形态，1080×1920）：横版 FakeDashboard 的竖版对应物，同一灰阶 G。
// A = 2 列卡片网格（3 行），B = 单列列表行（ROWS_V 行）。顶栏 160（含状态栏），底部 tab 栏 150。

export const FAKE_V = {
  top: 160,
  tab: 150,
  pad: 36,
  gap: 22,
  rows: 7,
};
// B 变体行几何（供相机对准某一行）
export const fakeRowH = () => (VH - FAKE_V.top - FAKE_V.tab - FAKE_V.pad * 2 - (FAKE_V.rows - 1) * FAKE_V.gap) / FAKE_V.rows;
export const fakeRowTop = (i: number) => FAKE_V.top + FAKE_V.pad + i * (fakeRowH() + FAKE_V.gap);

export const FakeDashboardV: React.FC<{ variant?: 'A' | 'B' }> = ({ variant = 'A' }) => (
  <div style={{ width: VW, height: VH, background: G.bg, display: 'flex', flexDirection: 'column' }}>
    <div style={{ height: FAKE_V.top, background: G.panel, borderBottom: `2px solid ${G.line}`, display: 'flex', alignItems: 'flex-end', padding: '0 40px 30px', gap: 22, boxSizing: 'border-box' }}>
      <div style={{ width: 52, height: 52, borderRadius: 14, background: G.side }} />
      <div style={{ height: 22, width: 260, background: G.bar, borderRadius: 11, marginBottom: 15 }} />
      <div style={{ marginLeft: 'auto', width: 52, height: 52, borderRadius: 26, background: G.mid }} />
    </div>
    {variant === 'A' ? (
      <div style={{ flex: 1, padding: FAKE_V.pad, display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gridAutoRows: '1fr', gap: 28, boxSizing: 'border-box' }}>
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i} w={0} h={0} seed={i + 1} style={{ width: '100%', height: '100%' }} />
        ))}
      </div>
    ) : (
      <div style={{ flex: 1, padding: FAKE_V.pad, display: 'flex', flexDirection: 'column', gap: FAKE_V.gap, boxSizing: 'border-box' }}>
        {Array.from({ length: FAKE_V.rows }).map((_, i) => (
          <div key={i} style={{ flex: 1, background: G.card, border: `2px solid ${G.border}`, borderRadius: 18, display: 'flex', alignItems: 'center', gap: 26, padding: '0 30px', boxSizing: 'border-box' }}>
            <div style={{ width: 64, height: 64, borderRadius: 14, background: G.mid }} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 14, flex: 1 }}>
              <div style={{ height: 18, width: `${45 + ((i * 23) % 35)}%`, background: G.bar, borderRadius: 9 }} />
              <div style={{ height: 13, width: `${30 + ((i * 17) % 30)}%`, background: G.line, borderRadius: 7 }} />
            </div>
          </div>
        ))}
      </div>
    )}
    <div style={{ height: FAKE_V.tab, background: G.panel, borderTop: `2px solid ${G.line}`, display: 'flex', justifyContent: 'space-around', alignItems: 'center' }}>
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} style={{ width: 44, height: 44, borderRadius: 12, background: i === 0 ? G.ink : G.bar }} />
      ))}
    </div>
  </div>
);
