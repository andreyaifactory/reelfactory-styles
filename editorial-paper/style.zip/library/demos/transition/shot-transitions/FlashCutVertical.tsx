// A 式 推进流白 flash-cut · 竖版 9:16（1080×1920）。
// 横版没有独立 demo（组件 assets/lib/FlashCut.tsx + template aifl/Main.tsx 用法），这里给出竖版完整示范：
// 前镜相机推进 → 切点跨骑一层暖白闪（from = 切点 − 5，两侧各 5f，峰值 0.85）盖住换页 → 后镜从 1.06 落回 1.0。
// 闪光径向中心对准安全区中心（y≈43%）。白闪只盖硬切，不当装饰光效。
import React from 'react';
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from 'remotion';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const FLASH_CUT_VERTICAL_DURATION = 60;
const CUT = 28;
const FLASH = 10; // 闪光总长，from = CUT - 5

export const FlashCutVertical: React.FC = () => {
  const f = useCurrentFrame();
  const push = interpolate(f, [0, CUT], [1, 1.18], { easing: Easing.in(Easing.quad), extrapolateRight: 'clamp' });
  const land = interpolate(f, [CUT, CUT + 14], [1.06, 1], { easing: Easing.out(Easing.cubic), extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const lf = f - (CUT - 5);
  const o = interpolate(lf, [0, FLASH * 0.4, FLASH], [0, 0.85, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
  const cyPct = ((SAFE_CY / 1920) * 100).toFixed(1);
  return (
    <AbsoluteFill style={{ overflow: 'hidden' }}>
      <AbsoluteFill style={{ transform: `scale(${f < CUT ? push : land})`, transformOrigin: `50% ${cyPct}%` }}>
        {f < CUT ? <FakeDashboardV variant="A" /> : <FakeDashboardV variant="B" />}
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          pointerEvents: 'none',
          opacity: o,
          background: `radial-gradient(ellipse at 50% ${cyPct}%, rgba(255,248,235,0.98), rgba(255,244,224,0.55) 55%, transparent 80%)`,
        }}
      />
    </AbsoluteFill>
  );
};
