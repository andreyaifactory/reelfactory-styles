import type { StyleTokens } from '../../../core/style-contract';
import { T } from '../kit/kit';

/**
 * «Слои» в словаре ядра фабрики. Белый текст поверх живого видео, один
 * акцент — голубо-синий, его меняют под бренд одним значением `T.accent` в ките.
 * Заголовки — узкий жирный Oswald капсом, подписи — рукописный Bad Script,
 * субтитры и мелкое — Montserrat. Свечений нет, мягкая тень только под вставкой.
 */
export const tokens: StyleTokens = {
  name: 'Слои',

  color: {
    text: T.text,
    textMuted: 'rgba(255,255,255,0.72)',
    textFaint: 'rgba(255,255,255,0.45)',
    bg: '#0d0f14',
    bgTop: '#14171e',
    accent: T.accent,
    accentSoft: T.accentLight,
    accentDeep: T.accentDeep,
    surface: '#ffffff',
    surfaceBorder: 'rgba(255,255,255,0.6)',
    white: '#ffffff',
    black: '#0b0b0d',
  },

  type: {
    hero: { size: 130, weight: 650, lh: 0.98, ls: '0.005em', family: T.head, uppercase: true },
    heroTight: { size: 100, weight: 650, lh: 0.98, ls: '0.005em', family: T.head, uppercase: true },
    title: { size: 112, weight: 650, lh: 0.98, ls: '0.005em', family: T.head, uppercase: true },
    stat: { size: 480, weight: 700, lh: 1, ls: '0em', family: T.head },
    label: { size: 60, weight: 400, lh: 1.05, ls: '0em', family: T.script },
    body: { size: 46, weight: 500, lh: 1.2, ls: '0.01em', family: T.body },
    script: { size: 60, weight: 400, lh: 1.05, ls: '0em', family: T.script },
  },

  radius: { card: 34, capsule: 34, pill: 999, bar: 12, phone: 0.16 },

  space: { gap: 24 },

  extra: {
    /** Тень под вставкой и телефоном — единственный свет стиля. */
    cardShadow: '0 26px 50px rgba(6,10,22,0.35)',
    glow: 'none',
  },
};
