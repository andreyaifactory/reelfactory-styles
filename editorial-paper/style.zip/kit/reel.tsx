import React from 'react';
import { AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame } from 'remotion';
import { C, HatchFill, CutWords, Cutout, DOODLE, Desk, Diorama, Doodle, E, HandCam, VideoBand, PageFlip, PaperTexture, PaperWipe, Press, Rule, Stamp, Sticker, Strips, Tear, TornWindow, bump, lerp, seg } from './kit';
import { InkCaptions, type Word } from './InkCaptions';
import { PaperFonts } from './fonts';

// Шоурил стиль-пака «Бумажная печать» (editorial-paper): 1080×1920, 30fps, 465f ≈ 15.5s. Ролик о самом стиле, без продукта и латиницы.
// Сцены: аппликация днём → полоса с вклеенным видео → слова-вырезки → разрыв в ночную аппликацию → лист рвётся пополам → финал.
// Ритм: сцена 2–3s, между ними бумажный переход (лист с рваным краем / перелистывание / разрыв в видео / разрыв пополам).
// На ночной сцене — субтитры-полоски: звучащее слово подчёркивает янтарная линейка.
// Шрифты — из fonts/ пака (PaperFonts, файлы в public/fonts/).
// Камера живая всегда: дрейф из рук + толчок на каждом шлепке + короткий проезд по полосе (18f).
// Рисовка поверх всего: обводки, стрелки, искры красным карандашом.
export const REEL_DURATION = 465;
const T = { wipe1: 64, flip: 176, tear: 268, wipe2: 372 } as const;

const V = (n: string) => staticFile(`editorial/${n}.mp4`);
const A = (n: string) => staticFile(`editorial/${n}.mp3`);

const SFX: { at: number; src: string; v: number; dur?: number }[] = [
  { at: 6, src: 'paper-slide', v: 0.4 },
  { at: 12, src: 'paper-slide', v: 0.3 },
  { at: 22, src: 'pencil-write-short', v: 1.4, dur: 16 },
  { at: 32, src: 'hit-weak', v: 0.45 },
  { at: T.wipe1, src: 'paper-move-quick', v: 0.5 },
  { at: T.wipe1 + 2, src: 'paper-slide', v: 0.35 },
  { at: 80, src: 'typewriter-hit-hard', v: 0.35 },
  { at: 102, src: 'marker-pen-line', v: 0.45, dur: 14 },
  { at: 108, src: 'paper-scissors-cut', v: 0.45, dur: 10 },
  { at: 118, src: 'paper-slide', v: 0.5 },
  { at: 127, src: 'paper-move-quick', v: 0.3 },
  { at: 138, src: 'hit-weak', v: 0.4 },
  { at: 148, src: 'pencil-write-short', v: 1.4, dur: 18 },
  { at: T.flip, src: 'paper-page-turn-big', v: 0.55 },
  { at: 198, src: 'typewriter-hit-hard', v: 0.4 },
  { at: 212, src: 'typewriter-hit-hard', v: 0.42 },
  { at: 226, src: 'typewriter-hit-hard', v: 0.45 },
  { at: 240, src: 'marker-pen-line', v: 0.45, dur: 14 },
  { at: T.tear, src: 'paper-slice-quick', v: 0.6 },
  { at: T.tear + 1, src: 'paper-crumple-quick', v: 0.3 },
  { at: 290, src: 'paper-slide', v: 0.35 },
  { at: 306, src: 'pencil-write-short', v: 1.4, dur: 18 },
  { at: 324, src: 'hit-weak', v: 0.4 },
  { at: 334, src: 'pencil-write-short', v: 1.2, dur: 10 },
  { at: T.wipe2, src: 'paper-slice-quick', v: 0.6 },
  { at: T.wipe2 + 3, src: 'paper-crumple-quick', v: 0.35 },
  { at: 388, src: 'typewriter-hit-soft', v: 0.4 },
  { at: 412, src: 'hit-blow', v: 0.55 },
  { at: 413, src: 'paper-staple', v: 0.5 },
  { at: 428, src: 'typewriter-return-bell', v: 0.4 },
];

// Субтитры ночной сцены: слова с таймкодами (секунды), две фразы-полоски.
const Wd = (arr: [string, number, number][]): Word[] => arr.map(([t, s, e]) => ({ t, s, e }));
const NIGHT_WORDS: Word[][] = [
  Wd([['Переходы', 9.7, 10.15], ['делаем', 10.15, 10.55], ['бумагой:', 10.55, 11.1]]),
  Wd([['рвём,', 11.3, 11.7], ['листаем,', 11.75, 12.2], ['накрываем.', 12.25, 12.9]]),
];

export const EditorialReel: React.FC<{ bgm?: boolean }> = ({ bgm = true }) => {
  const f = useCurrentFrame();
  return (
    <PaperFonts>
    <Desk>
      {/* ── 5. Финал: лежит под ночной сценой и открывается, когда её лист рвётся пополам ── */}
      {f >= T.wipe2 ? (
        <HandCam f={f} push={[T.wipe2, REEL_DURATION, 1, 1.04]} plus={bump(f, [412], 0.035)}>
          <PaperTexture tone={C.paperHi} />
          <div style={{ position: 'absolute', top: 560, left: 60, right: 60, textAlign: 'center' }}>
            <Rule f={f} at={T.wipe2 + 10} thick={6} double />
            <Press f={f} at={T.wipe2 + 14} text="Бумажный *стиль*" size={146} style={{ margin: '40px 0 34px' }} />
            <Rule f={f} at={T.wipe2 + 18} thick={2} />
          </div>
          <div style={{ position: 'absolute', top: 1130, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
            <Stamp f={f} at={412} text="Готово" sub="к публикации" rotate={-8} size={112} />
          </div>
          <Doodle f={f} at={420} d={DOODLE.spark(250, 1150, 80)} len={8} width={7} />
          <Doodle f={f} at={423} d={DOODLE.spark(840, 1330, 80)} len={8} width={7} style={{ transform: 'rotate(180deg)', transformOrigin: '840px 1330px' }} />
        </HandCam>
      ) : null}

      {/* ── 4. Ночная аппликация в разрыве бумаги; в конце лист рвётся пополам ── */}
      {f >= T.tear - 2 && f < T.wipe2 + 16 ? (
        <Tear f={f} at={T.wipe2} len={16} seed={23}>
          <HandCam f={f} push={[T.tear, T.wipe2, 1, 1.05]} plus={bump(f, [290, 324], 0.025)}>
            <Diorama f={f} at={T.tear + 2} night />
            <Strips f={f} at={288} x={90} y={270} lines={['Переходы —', '*рвём и листаем*']} size={66} accent={C.amber} />
            <HatchFill f={f} at={302} cx={750} cy={622} r={186} />
            <Sticker f={f} at={324} x={280} y={1000} text="ночная тема" d={210} rotate={-10} size={38} />
            <Doodle f={f} at={334} d={DOODLE.spark(440, 880, 64)} len={8} width={7} color={C.amber} />
          </HandCam>
          <InkCaptions chunks={NIGHT_WORDS} top={1250} size={58} />
        </Tear>
      ) : null}

      {/* ── 3. Слова-вырезки на крафте; в конце бумага рвётся и открывает видео ── */}
      {f >= T.flip - 2 && f < T.tear + 16 ? (
        <TornWindow f={f} at={T.tear} len={14} from={0} to={1.5} cx={540} cy={760} tone="#e4d7bd">
          <HandCam f={f} push={[T.flip, T.tear, 1, 1.06]} plus={bump(f, [198, 212, 226], 0.03)}>
            <CutWords f={f} at={192} words={['Вырезали.', 'Вклеили.', 'Обвели.']} step={14} size={150} x={70} y={400} />
            <Doodle f={f} at={238} d={DOODLE.swoosh(110, 1210, 760)} len={10} width={9} />
            <Doodle f={f} at={246} d={DOODLE.star(190, 1300, 44)} len={8} width={7} color={C.amber} />
            <Doodle f={f} at={250} d={DOODLE.spark(900, 1320, 60)} len={8} width={6} />
          </HandCam>
        </TornWindow>
      ) : null}

      {/* ── 1+2. Видео с бумажными вставками → лист с рваным краем → полоса; перелистывание ── */}
      {f < T.flip + 18 ? (
        <PageFlip f={f} at={T.flip} len={16}>
          {/* 1. Хук: ваше видео, на него наклеено бумажное */}
          <HandCam f={f} push={[0, T.wipe1 + 14, 1, 1.05]} plus={bump(f, [10, 16, 32], 0.03)}>
            <Diorama f={f} at={0} />
            <Strips f={f} at={10} x={90} y={270} lines={['Бумажный стиль —', '*для рилсов*']} size={72} step={6} accent={C.amber} />
            <Doodle f={f} at={24} d={DOODLE.circle(752, 624, 232, 222)} len={12} width={8} />
            <Sticker f={f} at={32} x={760} y={1170} text="новое!" d={220} rotate={12} />
            <Doodle f={f} at={40} d={DOODLE.spark(610, 1090, 70)} len={8} width={7} color={C.paperHi} />
          </HandCam>

          {/* 2. Полоса: заголовок → короткий проезд вниз → вырезка с видео на скотче */}
          <PaperWipe f={f} at={T.wipe1} len={14} seed={31}>
            <HandCam f={f} plus={bump(f, [80, 118, 138], 0.025)}>
              <AbsoluteFill style={{ transform: `translateY(${lerp(seg(f, 104, 122, E.inOutCubic), 0, -420)}px)` }}>
                <div style={{ position: 'absolute', top: 290, left: 80, right: 80 }}>
                  <Press f={f} at={80} text="Каждый кадр — *коллаж*." size={124} align="left" />
                </div>
                <Doodle f={f} at={100} d={DOODLE.swoosh(90, 735, 560)} len={8} width={9} color={C.amber} />
                <Rule f={f} at={96} thick={3} style={{ position: 'absolute', top: 900, left: 80, width: 920 }} />
                <Cutout f={f} at={116} x={60} y={1120} w={900} h={300} rotate={-3} seed={4}>
                  <Sequence from={116} layout="none">
                    <VideoBand src={V('insert-b')} w={900} h={300} x0={0.08} x1={0.92} y0={0.25} />
                  </Sequence>
                </Cutout>
                <Sticker f={f} at={136} x={900} y={1140} text="живое видео" d={200} rotate={14} size={38} />
                <Doodle f={f} at={146} d={DOODLE.arrow(300, 1640, 400, 1480)} len={10} width={7} />
                <div style={{ position: 'absolute', top: 1640, left: 330, fontFamily: '"PT Serif", Georgia, serif', fontStyle: 'italic', fontSize: 52, color: C.red, transform: 'rotate(-4deg)', clipPath: `inset(-20% ${(1 - seg(f, 150, 166)) * 100}% -20% 0)` }}>
                  видео вклеено в бумагу
                </div>
              </AbsoluteFill>
            </HandCam>
          </PaperWipe>
        </PageFlip>
      ) : null}

      {bgm ? (
        <Audio src={A('bgm-cat-walk-20s')} volume={(fr) => interpolate(fr, [0, 8, 400, 462], [0, 0.32, 0.32, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })} />
      ) : null}
      {SFX.map((s, i) => (
        <Sequence key={i} from={s.at} durationInFrames={s.dur ?? 90}>
          <Audio src={A(s.src)} volume={s.v} />
        </Sequence>
      ))}
    </Desk>
    </PaperFonts>
  );
};
