// typewriter-error-retype · 竖版 9:16（1080×1920）。
// 时间轴与横版逐帧一致（打 2f/字符 → 犹豫 16f 闪两下 → 删 1.5f/字符 → 重打 1.5f/字符 → 闪两周期后熄灭，160f）。
// 竖版：一句拆两行——"just" 固定在上行，删改与重打只发生在下行；下行最长 19 字符×48px=912px，
// 两行左缘同锚 x=84，打字过程不横移；整块对准安全区中心。
import React from 'react';
import { useCurrentFrame } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { SAFE_CY } from '../../_fixtures/Vertical';

export const TYPEWRITER_ERROR_RETYPE_VERTICAL_DURATION = 160;

const TEXT1 = 'just a dashboard'; // 16 chars
const KEEP = 5; // "just " 保留（上行 "just"，空格即换行）
const DEL = TEXT1.length - KEEP; // 11 chars 待删
const TEXT2 = 'your command center'; // 19 chars

const T1 = 2;
const PAUSE_START = T1 + (TEXT1.length - 1) * 2; // f32
const DS = PAUSE_START + 16; // f48
const RS = 68;
const TYPE2_END = RS + (TEXT2.length - 1) * 1.5; // f95
const CURSOR_OFF = 115;

const CHAR_W = 48; // fontSize 80 的等宽感字符宽
const FS = 80;
const LINE_H = 104;

const cursorOn = (f: number): boolean => {
  if (f >= CURSOR_OFF) return false;
  if (f >= TYPE2_END) return Math.floor((f - TYPE2_END) / 5) % 2 === 0;
  if (f >= DS) return true;
  if (f >= PAUSE_START) return Math.floor((f - PAUSE_START) / 4) % 2 === 0;
  return true;
};

const Row: React.FC<{ text: string; cursor: boolean }> = ({ text, cursor }) => (
  <div style={{ display: 'flex', alignItems: 'center', height: LINE_H }}>
    {text.split('').map((c, i) => (
      <span
        key={i}
        style={{
          display: 'inline-block',
          width: CHAR_W,
          textAlign: 'center',
          fontFamily: '"Courier New", Courier, monospace',
          fontSize: FS,
          fontWeight: 700,
          color: G.ink,
          lineHeight: 1.1,
        }}
      >
        {c === ' ' ? ' ' : c}
      </span>
    ))}
    {cursor && <span style={{ display: 'inline-block', width: 6, height: 86, marginLeft: 4, background: G.ink }} />}
  </div>
);

export const TypewriterErrorRetypeVertical: React.FC = () => {
  const f = useCurrentFrame();
  const n1 = f < T1 ? 0 : Math.min(TEXT1.length, Math.floor((f - T1) / 2) + 1);
  const removed = f < DS ? 0 : Math.min(DEL, Math.floor((f - DS) / 1.5) + 1);
  const n2 = f < RS ? 0 : Math.min(TEXT2.length, Math.floor((f - RS) / 1.5) + 1);
  const shown = TEXT1.slice(0, Math.max(KEEP, n1 - removed)).slice(0, n1) + TEXT2.slice(0, n2);

  // 上行 = 前 4 字符 "just"；第 5 个字符（空格）起进入下行
  const top = shown.slice(0, 4);
  const bottom = shown.length > KEEP ? shown.slice(KEEP) : '';
  const onBottom = shown.length >= KEEP;
  const cur = cursorOn(f);

  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, position: 'relative' }}>
      <div style={{ position: 'absolute', left: 84, top: SAFE_CY - LINE_H }}>
        <Row text={top} cursor={cur && !onBottom} />
        <Row text={bottom} cursor={cur && onBottom} />
      </div>
    </div>
  );
};
