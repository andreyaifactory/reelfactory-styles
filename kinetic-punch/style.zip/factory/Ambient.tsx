import React from 'react';
import { AbsoluteFill, useCurrentFrame } from 'remotion';
import { stepF } from '../kit/kit';

/**
 * Живой слой «Удара» — едва видимый полутон по чёрному полю, сдвигается
 * ступенькой раз в три кадра, «на тройках», как декор пака. Это воздух, а не
 * событие: правило «нет мёртвого кадра» выполняет сцена — удар слова, смена
 * поля, рывок камеры. Сцена со своим полем его закрывает, и это норма.
 */
export const Ambient: React.FC = () => {
  const frame = useCurrentFrame();
  const off = (stepF(frame, 3) * 4) % 60;
  return (
    <AbsoluteFill
      style={{
        backgroundImage: 'radial-gradient(#1b1b1d 30%, transparent 32%)',
        backgroundSize: '60px 60px',
        backgroundPosition: `${off}px ${off}px`,
        pointerEvents: 'none',
      }}
    />
  );
};
