// jump-cut-punch-in · 竖版 9:16（1080×1920）。
// 保留：三级零补间硬切 1.0 → 帧 35 直跳 1.6 → 帧 70 直跳 2.6、跳切帧 2f brightness 0.92 脉冲、72–134 全静止。
// 竖版：FakeDashboard → FakeDashboardV；落点 = 竖版网格中排左卡（中心 281, 960），虚线框随构图缩放；
// 放大时落点平移到安全区中心（y 835），2.6 倍时卡片 490→1274 宽，略溢出画宽，与横版"卡片撑满"的观感一致。删除 TitleBlock 标签。
// 以下为横版原注释：
// 三级跳切推近——节奏剪辑｜戈达尔跳切/纪录片 punch-in。固定构图，transform-origin 钉在目标卡中心，三次无补间硬切逐级放大：
// 刻意零 interpolate，切换帧一帧到位。每次跳切帧叠 2f 整画面 brightness 0.92 加深脉冲当 tick。
import React from 'react';
import { useCurrentFrame } from 'remotion';
import { G } from '../../_fixtures/Fixtures';
import { FakeDashboardV, SAFE_CY } from '../../_fixtures/Vertical';

export const JUMP_CUT_PUNCH_IN_VERTICAL_DURATION = 135;
const CARD = { l: 36, t: 196 + 494 + 28, w: 490, h: 494 };
const OX = CARD.l + CARD.w / 2;
const OY = CARD.t + CARD.h / 2;
const scaleAt = (f: number) => (f < 35 ? 1.0 : f < 70 ? 1.6 : 2.6);
const pulseAt = (f: number) => ((f >= 35 && f <= 36) || (f >= 70 && f <= 71) ? 0.92 : 1);

export const JumpCutPunchInVertical: React.FC = () => {
  const frame = useCurrentFrame();
  const s = scaleAt(frame);
  const ty = s === 1 ? 0 : SAFE_CY - OY;
  const tx = s === 1 ? 0 : 540 - OX;
  return (
    <div style={{ width: 1080, height: 1920, background: G.bg, position: 'relative', overflow: 'hidden', filter: `brightness(${pulseAt(frame)})` }}>
      <div style={{ position: 'absolute', inset: 0, transform: `translate(${tx}px, ${ty}px) scale(${s})`, transformOrigin: `${OX}px ${OY}px` }}>
        <FakeDashboardV variant="A" />
        <div style={{ position: 'absolute', left: CARD.l - 10, top: CARD.t - 10, width: CARD.w + 20, height: CARD.h + 20, border: `3px dashed ${G.mid}`, borderRadius: 20, boxSizing: 'border-box' }} />
      </div>
    </div>
  );
};
